/******************************************************************************************************
Copyright(c) < 2024 > <copyright holder : Kriszti�n Dezs� Feh�r, Hungary>
Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files(the "Software"),
to deal in the Software without restriction, except the commercial usage, including without limitation the rights to use, copy, modify, merge, publish, distribute copies of the Software,
and to permit persons to whom the Software is furnished to do so, subject to the following conditions :

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
******************************************************************************************************/
#pragma once
#define SCREEN_WIDTH 2500
#define SCREEN_HEIGHT 1400
#define GPX_SCREEN_WIDTH 300
#define GPX_SCREEN_HEIGHT 200
long long TERRAINTOMB_MAX_OBJ_NUM = 2200000000; //teszt: 2200000000, demo: 50000000

//*************** for DEM config change these ***********
// HGT_res in ZEUSZ_GIS.h
#define FILE_MAX_X (360*1201) //(360*1201)
#define FILE_MAX_Y (180*1201) //(180*1201)
#define TILEROW 1201 //1201

//#define FILE_MAX_X (360*3601) //(360*1201)
//#define FILE_MAX_Y (180*3601) //(180*1201)
//#define TILEROW 3601 //1201
//***************************************
#define ROTANGLE 5
//*******CUDA*************
#define BLOCKSIZE 384
//*********gui***********
#define IDC_STATIC -1
#define ID_PARANCSGOMB01 901
#define ID_PARANCSGOMB02 902
#define ID_PARANCSGOMB03 903
#define ID_PARANCSGOMB04 904
#define ID_PARANCSGOMB05 905
#define ID_PARANCSGOMB06 906
#define ID_PARANCSGOMB07 907
#define ID_PARANCSGOMB08 908
#define ID_PARANCSGOMB09 909
#define STARTID_TRACKBAR1 800
#define STARTID_CHECKBOX1 800
#define ID_RAMTRACKBAR 700

int CURRENT_DEVICE;

#define ID_TIMER1 999 //sensor apply update interval
#define ID_TIMER2 998 //PHP QUERY interval
#define ID_TIMER3 1000 //Render SLAVE mode command polling
#define ID_TIMER4 1001 //Render MASTER mode command polling
#define ID_TIMER5 1002 //Render eGPU mode command polling

#define OBJ_ID100 100 //render mode
#define OBJ_ID101 101
#define OBJ_ID102 102 //-111: GPU_onoff haszn�lja
#define OBJ_ID103 103 //render target screen/file
#define OBJ_ID104 104 //sensor select dropdown
#define OBJ_ID105 105 //sensor apply update interval
#define OBJ_ID106 106 //stop update interval
#define OBJ_ID107 107 //stop update interval
#define OBJ_ID149 149 //XM render mode on/off

//IP setup
#define OBJ_ID108 108 //Edit_IP_1
#define OBJ_ID109 109 //Button_IP_Val_1
#define OBJ_ID110 110 //Button_CleintServer_mode_1
#define OBJ_ID111 111 //Button_Send_GPS
#define OBJ_ID112 112 //Button_Render_Engine_mode

//General Settings Window
#define OBJ_ID113 113
#define OBJ_ID114 114
#define OBJ_ID115 115
#define OBJ_ID116 116
#define OBJ_ID117 117
#define OBJ_ID118 118
#define OBJ_ID119 119
#define OBJ_ID120 120
#define OBJ_ID121 121
#define OBJ_ID122 122
#define OBJ_ID125 125
#define OBJ_ID126 126
#define OBJ_ID127 127
#define OBJ_ID128 128
#define OBJ_ID129 129
#define OBJ_ID130 130
#define OBJ_ID131 131
#define OBJ_ID132 132
#define OBJ_ID133 133
#define OBJ_ID134 134

//Unit list window
#define OBJ_ID123 123
#define OBJ_ID124 124

//Farm Setup Dialog
#define OBJ_ID135 135
#define OBJ_ID136 136
#define OBJ_ID137 137
#define OBJ_ID138 138
#define OBJ_ID139 139
#define OBJ_ID140 140
#define OBJ_ID141 141
#define OBJ_ID142 142

//GPX Import Dialog
#define OBJ_ID143 143
#define OBJ_ID144 144
#define OBJ_ID145 145
#define OBJ_ID146 146
#define OBJ_ID147 147
#define OBJ_ID148 148
