/******************************************************************************************************
Copyright(c) < 2024 > <copyright holder : Kriszti�n Dezs� Feh�r, Hungary>
Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files(the "Software"),
to deal in the Software without restriction, except the commercial usage, including without limitation the rights to use, copy, modify, merge, publish, distribute copies of the Software,
and to permit persons to whom the Software is furnished to do so, subject to the following conditions :

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
******************************************************************************************************/
#pragma once
#include "naplozas.h"
#include "include\\PEGAZUS_GPU.h"
#include "include\\gpx_import.h"

void terrain_betolt_TRIANGLE(const char eleres[], long long akt_hgt_X, long long akt_hgt_Y, int terrain_width, int terrain_height);
void terrain_betolt_POINT(const char eleres[], long long akt_hgt_X, long long akt_hgt_Y, int terrain_width, int terrain_height);
void terrain_betolt_FIX(const char eleres[], long long akt_hgt_X, long long akt_hgt_Y, int terrain_width, int terrain_height);
void TER_betolt(char eleres[], const char tipus[]);
int get_height(float akt_long, float akt_lat);
__global__ void add_height(int maxitemcount, float* rawarrayY);
__global__ void lower_height(int maxitemcount, float* rawarrayY);
void data_load(void);
void init_before_dataload(void);
int get_height_color(int mag_ertek);

//*********HGT MEGJELENITES*****************************
#define HGT_res 0.00083263946711074104912572855953372
//#define HGT_res 0.000277700638711469

float TERKEP_NAGYITAS = 300; //1000
float terrainkocka_width, terrainkocka_height;
int vane_terrain = 0;//0-nincs, 1-van
int vane_teradat_betoltve = 0;//0-nincs, 1-van
int terrain_disable = 0;//0-nem, 1-igen
float altitude_ratio = 350.0;//1000.0
short int* terraintomb2;
int domb_width = 500, domb_height = 500;//76000x28000, 9000x3880
float terkepx = 19.55, terkepy = 47.25;// 19.04 46.45
long long terraintomb2_length, domb_start_long, domb_start_lat, domb_end_long, domb_end_lat;
float epulet_magassag = 0.1;
int PANX = 0;

void pre_D2D_drawing_TURBO_XM(void);
void D2D_drawing_TURBO_XM(void);
void post_D2D_drawing_TURBO_XM(void);

void cpu_data_load(void);

void terrain_betolt_TRIANGLE(const char eleres[], long long akt_hgt_X, long long akt_hgt_Y, int terrain_width, int terrain_height)
{
	int d3_meretezes = 1;
	long int szamlalo, szamlalo_triangle;
	long long fajlpos_startX = akt_hgt_X - (terrain_width / 2);
	long long fajlpos_endX = fajlpos_startX + terrain_width;
	char hibauzenet[256];

	if (fajlpos_startX < 0)
	{
		fajlpos_startX = 0;
		fajlpos_endX = terrain_width / 2;
	}
	else if (fajlpos_startX > FILE_MAX_X)
	{
		fajlpos_startX = FILE_MAX_X - (terrain_width / 2);
		fajlpos_endX = FILE_MAX_X;
	}
	long long fajlpos_startY = akt_hgt_Y - (terrain_height / 2);
	long long fajlpos_endY = fajlpos_startY + terrain_height;
	if (fajlpos_startY < 0)
	{
		fajlpos_startY = 0;
		fajlpos_endY = terrain_height / 2;
	}
	else if (fajlpos_startY > FILE_MAX_Y)
	{
		fajlpos_startY = FILE_MAX_Y - (terrain_height / 2);
		fajlpos_endY = FILE_MAX_Y;
	}

	domb_start_lat = fajlpos_startY;
	domb_start_long = fajlpos_startX;
	domb_end_long = fajlpos_endX;
	domb_end_lat = fajlpos_endY;

	FILE* file;
	long long i, j, fajlpoz, k, l;
	short int adat, akt_magassag;

	float lat1, long1;
	float startvertexx, startvertexy;

	// fajl megnyitasa
	file = fopen(eleres, "rb");
	if (file == NULL) return;
	else vane_terrain = 1;
	terraintomb2_length = 0;

	for (i = fajlpos_startY; i < fajlpos_endY - 1; ++i) //sorok
	{
		fajlpoz = ((i * FILE_MAX_X) + fajlpos_startX) * sizeof(short int);
		_fseeki64(file, (__int64)fajlpoz, SEEK_SET);
		for (j = fajlpos_startX; j < fajlpos_endX; ++j) //oszlopok
		{
			fread(&adat, sizeof(adat), 1, file);
			terraintomb2[terraintomb2_length++] = adat;
			//if (adat > max_magassag) max_magassag = adat;
		}
	}
	fclose(file);
	terrainkocka_width = SCREEN_WIDTH / terrain_width;
	terrainkocka_width = HGT_res * TERKEP_NAGYITAS;
	terrainkocka_height = SCREEN_HEIGHT / terrain_height * 2;
	terrainkocka_height = HGT_res * 2 * TERKEP_NAGYITAS;
	//if (terrainkocka_width < 1) terrainkocka_width = 1;
	//if (terrainkocka_height < 1) terrainkocka_height = 1;
	startvertexx = 0.0f - ((fajlpos_endX - fajlpos_startX) / 2.0f * terrainkocka_width);
	startvertexy = 0.0f - ((fajlpos_endY - fajlpos_startY) / 2.0f * terrainkocka_height);

	// ittv annak: init_before_dataload()
	/*CURRENT_GPU_INDEX = 0;
	CURRENT_DEVICE = active_GPU_list[CURRENT_GPU_INDEX];
	poly_szinek_length[active_GPU_list[CURRENT_GPU_INDEX]] = 0;
	objlista_length[active_GPU_list[CURRENT_GPU_INDEX]] = 0;
	raw_vertices_length[active_GPU_list[CURRENT_GPU_INDEX]] = 0;*/

	if (terrain_disable == 1) return;

	naplo("Adatbeolvasas es feltoltes - CURRENT_GPU_INDEX:");
	naplo_num(CURRENT_GPU_INDEX);
	naplo("max_allowed_vertex_count[CURRENT_DEVICE]:");
	naplo_num(max_allowed_vertex_count[CURRENT_DEVICE]);

	for (i = fajlpos_startY, k = 0; i < fajlpos_endY - 2; ++i, ++k) //sorok fajlpos_endY - 2
	{
		for (j = fajlpos_startX, l = 0; j < fajlpos_endX - 1; ++j, ++l) //oszlopok
		{
			//if ((raw_vertices_length[CURRENT_DEVICE] % 100000) == 0.0)
			//{
			//	//naplo("Beolvasott pontok szama (x 100.000):");
			//	//naplo_num(raw_vertices_length[CURRENT_DEVICE]);
			//	;
			//}

			raw_verticesX[raw_vertices_length[CURRENT_DEVICE]] = startvertexx + (l * terrainkocka_width);
			raw_verticesY[raw_vertices_length[CURRENT_DEVICE]] = terraintomb2[(k * (fajlpos_endX - fajlpos_startX)) + l] / altitude_ratio;
			raw_verticesZ[raw_vertices_length[CURRENT_DEVICE]++] = startvertexy + (k * terrainkocka_height);

			raw_verticesX[raw_vertices_length[CURRENT_DEVICE]] = startvertexx + (l * terrainkocka_width);
			raw_verticesY[raw_vertices_length[CURRENT_DEVICE]] = terraintomb2[((k + 1) * (fajlpos_endX - fajlpos_startX)) + l] / altitude_ratio;
			raw_verticesZ[raw_vertices_length[CURRENT_DEVICE]++] = startvertexy + ((k + 1) * terrainkocka_height);

			raw_verticesX[raw_vertices_length[CURRENT_DEVICE]] = startvertexx + (l * terrainkocka_width + terrainkocka_width);
			raw_verticesY[raw_vertices_length[CURRENT_DEVICE]] = terraintomb2[((k + 1) * (fajlpos_endX - fajlpos_startX)) + l + 1] / altitude_ratio;
			raw_verticesZ[raw_vertices_length[CURRENT_DEVICE]++] = startvertexy + ((k + 1) * terrainkocka_height);

			akt_magassag = ((terraintomb2[(k * (fajlpos_endX - fajlpos_startX)) + l]) +
				(terraintomb2[((k + 1) * (fajlpos_endX - fajlpos_startX)) + l]) +
				(terraintomb2[((k + 1) * (fajlpos_endX - fajlpos_startX)) + l + 1])) / 3;

			poly_szinek[poly_szinek_length[CURRENT_DEVICE]++] = akt_magassag;
			++poly_counter;
			obj_tipuslista[objlista_length[CURRENT_DEVICE]++] = 0;

			raw_verticesX[raw_vertices_length[CURRENT_DEVICE]] = startvertexx + (l * terrainkocka_width);
			raw_verticesY[raw_vertices_length[CURRENT_DEVICE]] = terraintomb2[(k * (fajlpos_endX - fajlpos_startX)) + l] / altitude_ratio;
			raw_verticesZ[raw_vertices_length[CURRENT_DEVICE]++] = startvertexy + (k * terrainkocka_height);

			raw_verticesX[raw_vertices_length[CURRENT_DEVICE]] = startvertexx + (l * terrainkocka_width + terrainkocka_width);
			raw_verticesY[raw_vertices_length[CURRENT_DEVICE]] = terraintomb2[((k + 1) * (fajlpos_endX - fajlpos_startX)) + l + 1] / altitude_ratio;
			raw_verticesZ[raw_vertices_length[CURRENT_DEVICE]++] = startvertexy + ((k + 1) * terrainkocka_height);

			raw_verticesX[raw_vertices_length[CURRENT_DEVICE]] = startvertexx + (l * terrainkocka_width + terrainkocka_width);
			raw_verticesY[raw_vertices_length[CURRENT_DEVICE]] = terraintomb2[(k * (fajlpos_endX - fajlpos_startX)) + l + 1] / altitude_ratio;
			raw_verticesZ[raw_vertices_length[CURRENT_DEVICE]++] = startvertexy + (k * terrainkocka_height);

			akt_magassag = ((terraintomb2[(k * (fajlpos_endX - fajlpos_startX)) + l]) +
				(terraintomb2[((k + 1) * (fajlpos_endX - fajlpos_startX)) + l]) +
				(terraintomb2[(k * (fajlpos_endX - fajlpos_startX)) + l + 1])) / 3;

			poly_szinek[poly_szinek_length[CURRENT_DEVICE]++] = akt_magassag;
			++poly_counter;
			obj_tipuslista[objlista_length[CURRENT_DEVICE]++] = 0;

			if (render_mode == 0)
			{
				if ((raw_vertices_length[0] + 6) > max_allowed_vertex_count[0])
				{
					naplo("megtelt a RAM");
					return;
				}				
			}
			else if (render_mode == 1)
			{
				if (xtreme_vram_onoff == 0)
				{
					if ((prev_raw_vertices_length[CURRENT_DEVICE] + raw_vertices_length[CURRENT_DEVICE] + 6) > max_allowed_vertex_count[CURRENT_DEVICE])
					{
						naplo("CURRENT_GPU_INDEX:");
						naplo_num(CURRENT_GPU_INDEX);

						//*******************************
						//ha ezt kivessz�k, akkor
						//extrem mem�ria kezel�st aktiv�lunk.  
						//*******************************
						data_transfer_to_GPU(CURRENT_DEVICE); return;
						//*******************************

						if ((ACTIVE_DEVICE_COUNT == 1) || ((CURRENT_GPU_INDEX + 1) == ACTIVE_DEVICE_COUNT))
						{//megtelt az �sszes GPU VRAM-ja
							naplo("megtelt az �sszes GPU VRAM-ja");
							data_transfer_to_GPU(CURRENT_DEVICE); return;
						}
						else if ((CURRENT_GPU_INDEX + 1) < ACTIVE_DEVICE_COUNT)
						{//�tv�lt�s a k�vetkez� GPU-ra
							naplo("Ennyi csucspont lett beolvasva:");
							naplo_num(raw_vertices_length[CURRENT_DEVICE]);
							naplo("Adatok �tvitele a GPU-ra");
							data_transfer_to_GPU(CURRENT_DEVICE);
							naplo("Adatok a GPU-n vannak");
							naplo("�tv�lt�s a k�vetkez� GPU-ra");
							poly_szinek_length[active_GPU_list[CURRENT_GPU_INDEX + 1]] = 0;
							objlista_length[active_GPU_list[CURRENT_GPU_INDEX + 1]] = 0;
							raw_vertices_length[active_GPU_list[CURRENT_GPU_INDEX + 1]] = 0;
							prev_poly_szinek_length[active_GPU_list[CURRENT_GPU_INDEX + 1]] = prev_raw_vertices_length[active_GPU_list[CURRENT_GPU_INDEX + 1]] = 0;
							prev_objlista_length[active_GPU_list[CURRENT_GPU_INDEX + 1]] = 0;
							naplo("Alap�rt�kek az �j GPU-hoz be�ll�tva");
						}

						if ((CURRENT_GPU_INDEX + 1) == ACTIVE_DEVICE_COUNT) return;
						CURRENT_DEVICE = active_GPU_list[++CURRENT_GPU_INDEX];
						naplo("CURRENT_GPU_INDEX:");
						naplo_num(CURRENT_GPU_INDEX);
						naplo("max_allowed_vertex_count[CURRENT_DEVICE]:");
						naplo_num(max_allowed_vertex_count[CURRENT_DEVICE]);
					}
				}
				else if (xtreme_vram_onoff == 1)
				{
					if ((prev_raw_vertices_length[CURRENT_DEVICE] + raw_vertices_length[CURRENT_DEVICE] + 6) > max_allowed_vertex_count[CURRENT_DEVICE])
					{//nincs t�bb hely a RAM-ban

						if ((ACTIVE_DEVICE_COUNT == 1) || ((CURRENT_GPU_INDEX + 1) == ACTIVE_DEVICE_COUNT))
						{//megtelt az �sszes GPU VRAM-ja
							data_transfer_to_GPU(CURRENT_DEVICE);
							D2D_drawing_TURBO_XM();
							init_before_dataload();
						}
						else if ((CURRENT_GPU_INDEX + 1) < ACTIVE_DEVICE_COUNT)
						{//�tv�lt�s a k�vetkez� GPU-ra
							data_transfer_to_GPU(CURRENT_DEVICE);
							poly_szinek_length[active_GPU_list[CURRENT_GPU_INDEX + 1]] = 0;
							objlista_length[active_GPU_list[CURRENT_GPU_INDEX + 1]] = 0;
							raw_vertices_length[active_GPU_list[CURRENT_GPU_INDEX + 1]] = 0;
							prev_poly_szinek_length[active_GPU_list[CURRENT_GPU_INDEX + 1]] = prev_raw_vertices_length[active_GPU_list[CURRENT_GPU_INDEX + 1]] = 0;
							prev_objlista_length[active_GPU_list[CURRENT_GPU_INDEX + 1]] = 0;
						}

						//if ((CURRENT_GPU_INDEX + 1) == ACTIVE_DEVICE_COUNT) return;
						CURRENT_DEVICE = active_GPU_list[++CURRENT_GPU_INDEX];
					}
				}
			}
			
			
		}
	}

	//ki�r�s f�jlba a demo apphoz
	/*file = fopen("terrain_height_map.ter", "wb");
	fwrite(&domb_start_lat, sizeof(domb_start_lat), 1, file);
	fwrite(&domb_start_long, sizeof(domb_start_long), 1, file);
	fwrite(&domb_end_long, sizeof(domb_end_long), 1, file);
	fwrite(&domb_end_lat, sizeof(domb_end_lat), 1, file);
	fwrite(&terraintomb2_length, sizeof(terraintomb2_length), 1, file);
	for (i = 0; i < terraintomb2_length; ++i) fwrite(&terraintomb2[i], sizeof(terraintomb2[0]), 1, file);
	fclose(file);
	file = fopen("terrain_hungary.ter", "wb");
	if (file == NULL) return;	
	fwrite(&poly_counter, sizeof(poly_counter), 1, file);	
	for (i = 0; i < poly_counter*3; ++i) fwrite(&raw_verticesX[i], sizeof(raw_verticesX[0]), 1, file);
	for (i = 0; i < poly_counter*3; ++i) fwrite(&raw_verticesY[i], sizeof(raw_verticesX[0]), 1, file);
	for (i = 0; i < poly_counter*3; ++i) fwrite(&raw_verticesZ[i], sizeof(raw_verticesX[0]), 1, file);
	for (i = 0; i < poly_counter; ++i) fwrite(&poly_szinek[i], sizeof(poly_szinek[0]), 1, file);
	for (i = 0; i < poly_counter; ++i) fwrite(&obj_tipuslista[i], sizeof(obj_tipuslista[0]), 1, file);
	fclose(file);*/
	//************************

	if (render_mode == 0)
	{
		;//itt nem kell csin�lni ilyenkor semmit
	}
	else if (render_mode == 1)
	{
		if (xtreme_vram_onoff == 0)
		{
			if ((raw_vertices_length[CURRENT_DEVICE]) > 0)
			{
				naplo("Ennyi csucspont lett beolvasva:");
				naplo_num(raw_vertices_length[CURRENT_DEVICE]);
				data_transfer_to_GPU(CURRENT_DEVICE);
			}
		}
		else if (xtreme_vram_onoff == 1)
		{
			if ((raw_vertices_length[CURRENT_DEVICE]) > 0)
			{
				data_transfer_to_GPU(CURRENT_DEVICE);
				D2D_drawing_TURBO_XM();
				init_before_dataload();
			}
		}
	}	
}

void terrain_betolt_POINT(const char eleres[], long long akt_hgt_X, long long akt_hgt_Y, int terrain_width, int terrain_height)
{
	int d3_meretezes = 1;
	long int szamlalo, szamlalo_triangle;
	long long fajlpos_startX = akt_hgt_X - (terrain_width / 2);
	long long fajlpos_endX = fajlpos_startX + terrain_width;
	char hibauzenet[256];

	if (fajlpos_startX < 0)
	{
		fajlpos_startX = 0;
		fajlpos_endX = terrain_width / 2;
	}
	else if (fajlpos_startX > FILE_MAX_X)
	{
		fajlpos_startX = FILE_MAX_X - (terrain_width / 2);
		fajlpos_endX = FILE_MAX_X;
	}
	long long fajlpos_startY = akt_hgt_Y - (terrain_height / 2);
	long long fajlpos_endY = fajlpos_startY + terrain_height;
	if (fajlpos_startY < 0)
	{
		fajlpos_startY = 0;
		fajlpos_endY = terrain_height / 2;
	}
	else if (fajlpos_startY > FILE_MAX_Y)
	{
		fajlpos_startY = FILE_MAX_Y - (terrain_height / 2);
		fajlpos_endY = FILE_MAX_Y;
	}

	domb_start_lat = fajlpos_startY;
	domb_start_long = fajlpos_startX;
	domb_end_long = fajlpos_endX;
	domb_end_lat = fajlpos_endY;

	FILE* file;
	long long i, j, fajlpoz, k, l;
	short int adat, max_magassag = -1, akt_magassag;

	float lat1, long1;
	float startvertexx, startvertexy;

	// fajl megnyitasa
	naplo("Terrain betoltes megkezdese");
	file = fopen(eleres, "rb");
	if (file == NULL) return;
	else vane_terrain = 1;
	terraintomb2_length = 0;

	for (i = fajlpos_startY; i < fajlpos_endY - 1; ++i) //sorok
	{
		fajlpoz = ((i * FILE_MAX_X) + fajlpos_startX) * sizeof(short int);
		_fseeki64(file, (__int64)fajlpoz, SEEK_SET);
		for (j = fajlpos_startX; j < fajlpos_endX; ++j) //oszlopok
		{
			fread(&adat, sizeof(adat), 1, file);
			if (terraintomb2_length % 1000000 == 0.0) { naplo("Bet�lt�tt elemek sz�ma: "); naplo_num(terraintomb2_length / 1000000); }
			terraintomb2[(long long)terraintomb2_length++] = adat;
			//if (adat > max_magassag) max_magassag = adat;
		}
		//if (terraintomb2_length > 529000000) break;
	}
	fclose(file);
	naplo("terraintomb2 betoltve OK");
	naplo("terraintomb2_length:");
	naplo_num(terraintomb2_length);
	max_magassag = 0;
	terrainkocka_width = SCREEN_WIDTH / terrain_width;
	terrainkocka_width = HGT_res * TERKEP_NAGYITAS;
	terrainkocka_height = SCREEN_HEIGHT / terrain_height * 2;
	terrainkocka_height = HGT_res * 2 * TERKEP_NAGYITAS;
	//if (terrainkocka_width < 1) terrainkocka_width = 1;
	//if (terrainkocka_height < 1) terrainkocka_height = 1;
	startvertexx = 0.0f - ((fajlpos_endX - fajlpos_startX) / 2.0f * terrainkocka_width);
	startvertexy = 0.0f - ((fajlpos_endY - fajlpos_startY) / 2.0f * terrainkocka_height);

	CURRENT_GPU_INDEX = 0;
	CURRENT_DEVICE = active_GPU_list[CURRENT_GPU_INDEX];
	poly_szinek_length[active_GPU_list[CURRENT_GPU_INDEX]] = 0;
	raw_vertices_length[active_GPU_list[CURRENT_GPU_INDEX]] = 0;
	naplo("Terrain feldolgozas elokeszitese OK");

	for (i = fajlpos_startY, k = 0; i < fajlpos_endY-2; ++i, ++k) //sorok fajlpos_endY - 2
	{
		for (j = fajlpos_startX, l = 0; j < fajlpos_endX-1; ++j, ++l) //oszlopok
		{
			raw_verticesX[raw_vertices_length[CURRENT_DEVICE]] = startvertexx + (l * terrainkocka_width);
			raw_verticesY[raw_vertices_length[CURRENT_DEVICE]] = terraintomb2[(k * (fajlpos_endX - fajlpos_startX)) + l] / altitude_ratio;
			raw_verticesZ[raw_vertices_length[CURRENT_DEVICE]++] = startvertexy + (k * terrainkocka_height);

			akt_magassag = terraintomb2[(k * (fajlpos_endX - fajlpos_startX)) + l];
			poly_szinek[poly_szinek_length[CURRENT_DEVICE]++] = akt_magassag;

			++poly_counter;

			if (xtreme_vram_onoff == 0)
			{
				if ((prev_raw_vertices_length[CURRENT_DEVICE] + raw_vertices_length[CURRENT_DEVICE] + 1) > max_allowed_vertex_count[CURRENT_DEVICE])
				{
					if ((ACTIVE_DEVICE_COUNT == 1) || ((CURRENT_GPU_INDEX + 1) == ACTIVE_DEVICE_COUNT))
					{//megtelt az �sszes GPU VRAM-ja
						naplo("Megtelt az �sszes GPU VRAM-ja");
						data_transfer_to_GPU(CURRENT_DEVICE); return;
					}
					else if ((CURRENT_GPU_INDEX + 1) < ACTIVE_DEVICE_COUNT)
					{//�tv�lt�s a k�vetkez� GPU-ra
						naplo("Ennyi csucspont lett beolvasva:");
						naplo_num(raw_vertices_length[CURRENT_DEVICE]);
						naplo("�tv�lt�s a k�vetkez� GPU-ra");
						data_transfer_to_GPU(CURRENT_DEVICE);
						poly_szinek_length[active_GPU_list[CURRENT_GPU_INDEX + 1]] = 0;
						raw_vertices_length[active_GPU_list[CURRENT_GPU_INDEX + 1]] = 0;
						prev_poly_szinek_length[active_GPU_list[CURRENT_GPU_INDEX + 1]] = prev_raw_vertices_length[active_GPU_list[CURRENT_GPU_INDEX + 1]] = 0;
					}

					if ((CURRENT_GPU_INDEX + 1) == ACTIVE_DEVICE_COUNT) return;
					CURRENT_DEVICE = active_GPU_list[++CURRENT_GPU_INDEX];
				}
			}
			else if (xtreme_vram_onoff == 1)
			{
				if ((prev_raw_vertices_length[CURRENT_DEVICE] + raw_vertices_length[CURRENT_DEVICE] + 1) > max_allowed_vertex_count[CURRENT_DEVICE])
				{//nincs t�bb hely a RAM-ban

					if ((ACTIVE_DEVICE_COUNT == 1) || ((CURRENT_GPU_INDEX + 1) == ACTIVE_DEVICE_COUNT))
					{//megtelt az �sszes GPU VRAM-ja
						data_transfer_to_GPU(CURRENT_DEVICE);
						D2D_drawing_TURBO_XM();
						init_before_dataload();
					}
					else if ((CURRENT_GPU_INDEX + 1) < ACTIVE_DEVICE_COUNT)
					{//�tv�lt�s a k�vetkez� GPU-ra
						data_transfer_to_GPU(CURRENT_DEVICE);
						poly_szinek_length[active_GPU_list[CURRENT_GPU_INDEX + 1]] = 0;
						raw_vertices_length[active_GPU_list[CURRENT_GPU_INDEX + 1]] = 0;
						prev_poly_szinek_length[active_GPU_list[CURRENT_GPU_INDEX + 1]] = prev_raw_vertices_length[active_GPU_list[CURRENT_GPU_INDEX + 1]] = 0;
					}

					//if ((CURRENT_GPU_INDEX + 1) == ACTIVE_DEVICE_COUNT) return;
					CURRENT_DEVICE = active_GPU_list[++CURRENT_GPU_INDEX];
				}
			}

		}
	}

	naplo("Utolso simitasok...");

	if (xtreme_vram_onoff == 0)
	{
		if ((raw_vertices_length[CURRENT_DEVICE]) > 0)
		{
			naplo("Ennyi csucspont lett beolvasva:");
			naplo_num(raw_vertices_length[CURRENT_DEVICE]);
			data_transfer_to_GPU(CURRENT_DEVICE);
		}
	}
	else if (xtreme_vram_onoff == 1)
	{
		if ((raw_vertices_length[CURRENT_DEVICE]) > 0)
		{
			data_transfer_to_GPU(CURRENT_DEVICE);
			D2D_drawing_TURBO_XM();
			init_before_dataload();
		}
	}
	naplo("Terrain pontadatok elokeszitese OK");
}


void terrain_betolt_FIX(const char eleres[], long long akt_hgt_X, long long akt_hgt_Y, int terrain_width, int terrain_height)
{
	FILE* file;
	long long i, j;

	//itt vannak: init_before_dataload()
	CURRENT_GPU_INDEX = 0;
	CURRENT_DEVICE = active_GPU_list[CURRENT_GPU_INDEX];
	poly_szinek_length[active_GPU_list[CURRENT_GPU_INDEX]] = 0;
	raw_vertices_length[active_GPU_list[CURRENT_GPU_INDEX]] = 0;

	//beolvasas f�jlb�l, a demo apphoz
	file = fopen("data\\terrain_height_map.ter", "rb");
	fread(&domb_start_lat, sizeof(domb_start_lat), 1, file);
	fread(&domb_start_long, sizeof(domb_start_long), 1, file);
	fread(&domb_end_long, sizeof(domb_end_long), 1, file);
	fread(&domb_end_lat, sizeof(domb_end_lat), 1, file);
	fread(&terraintomb2_length, sizeof(terraintomb2_length), 1, file);
	if (terraintomb2_length > TERRAINTOMB_MAX_OBJ_NUM)
	{
		fclose(file); return;
	}
	for (i = 0; i < terraintomb2_length; ++i) fread(&terraintomb2[i], sizeof(terraintomb2[0]), 1, file);
	fclose(file);
	if (terrain_disable == 0)
	{
		file = fopen("data\\terrain_hungary.ter", "rb");
		if (file == NULL) return;
		else vane_terrain = 1;
		fread(&poly_counter, sizeof(poly_counter), 1, file);
		if ((poly_counter * 3) > max_allowed_vertex_count[CURRENT_DEVICE])
		{
			fclose(file); return;
		}
		for (i = 0; i < poly_counter * 3; ++i) fread(&raw_verticesX[i], sizeof(raw_verticesX[0]), 1, file);
		for (i = 0; i < poly_counter * 3; ++i) fread(&raw_verticesY[i], sizeof(raw_verticesX[0]), 1, file);
		for (i = 0; i < poly_counter * 3; ++i) fread(&raw_verticesZ[i], sizeof(raw_verticesX[0]), 1, file);
		for (i = 0; i < poly_counter; ++i) fread(&poly_szinek[i], sizeof(poly_szinek[0]), 1, file);
		for (i = 0; i < poly_counter; ++i) fread(&obj_tipuslista[i], sizeof(obj_tipuslista[0]), 1, file);
		fclose(file);
		vertex_counter = poly_counter * 3;
		raw_vertices_length[CURRENT_DEVICE] = poly_counter * 3;
		//prev_raw_vertices_length[CURRENT_DEVICE] = poly_counter * 3;
		poly_szinek_length[CURRENT_DEVICE] = poly_counter;
		objlista_length[CURRENT_DEVICE] = poly_counter;
		//prev_poly_szinek_length[CURRENT_DEVICE] = poly_counter;
	}
	data_transfer_to_GPU(CURRENT_DEVICE);
	//************************
}

int get_height_2(float akt_long, float akt_lat)
{
	//ez csak Eur�p�ra m�k�dik
	/*long long indexpozX = ((akt_long + 180) * TILEROW);
	long long indexpozY = ((61 - akt_lat) * TILEROW),tmp;*/
	float X = terkepx - ((domb_width / 2) * HGT_res), Y = terkepy + ((domb_height / 2) * HGT_res), findexx, findexy;
	long long indexx, indexy;
	findexx = (akt_long - X) / HGT_res;
	findexy = (Y - akt_lat + 1) / HGT_res;
	indexx = findexx;
	indexy = findexy;
	long long tmp;

	if (vane_terrain == 0 || indexx < 0 || indexx >(domb_end_long - domb_start_long) || indexy < 0 || indexy >(domb_end_lat - domb_start_lat)) return 0;

	tmp = indexy * (domb_end_long - domb_start_long);
	tmp = tmp + indexx;

	return (terraintomb2[tmp] + 10);// / altitude_ratio;
}

int get_height(float akt_long, float akt_lat)
{
	if (vane_terrain == 0) return 0;
	if (vane_teradat_betoltve == 0) return 0;
	if (akt_long < (terkepx - ((domb_width / 2) * HGT_res))) return 0;
	if (akt_long > (terkepx + ((domb_width / 2) * HGT_res))) return 0;
	if (akt_lat < (terkepy - ((domb_height / 2) * HGT_res))) return 0;
	if (akt_lat > (terkepy + ((domb_height / 2) * HGT_res))) return 0;

	float startX = terkepx - ((domb_width / 2) * HGT_res), startY = terkepy + ((domb_height / 2) * HGT_res);
	long long indexx, indexy;

	indexx = (akt_long - startX) / HGT_res;
	indexy = (startY - akt_lat) / HGT_res;

	return (terraintomb2[(indexy * domb_width)+indexx] + 15);// / altitude_ratio;
}

void TER_betolt(char eleres[], const char tipus[])
{
	int i, j, k, l;
	int obj_tipus;// a tipus parametertol fugg
	int pontok_szama = 0;
	float lat1;
	float long1;
	float altitude;
	FILE* file;
	int view_check = 0; //0-ok,1-outofview
	int add_check = 0; //0-tobeadded,1-dont add
	int add_check2 = 1; //0-tobeadded,1-dont add
	float din_hatarX = (domb_end_long - domb_start_long) * HGT_res;
	float din_hatarY = (domb_end_lat - domb_start_lat) * HGT_res;
	UINT32 objszin;

	//raw_vertices_length[CURRENT_DEVICE] = poly_szinek_length[CURRENT_DEVICE] = 0;

	// fajl megnyitasa
	file = fopen(eleres, "rb");
	if (file == NULL) return;

	if (strcmp(tipus, "building") == 0) { obj_tipus = 1; objszin = RGB(50, 50, 50); }
	else if (strcmp(tipus, "water") == 0) { obj_tipus = 4; objszin = RGB(228, 96, 24); }
	else if (strcmp(tipus, "road") == 0) { obj_tipus = 2; objszin = RGB(190, 190, 190); }
	else if (strcmp(tipus, "primary") == 0) { obj_tipus = 21; objszin = RGB(142, 122, 26); }
	else if (strcmp(tipus, "motorway") == 0) { obj_tipus = 22; objszin = RGB(0, 179, 243); }
	else if (strcmp(tipus, "railway") == 0) { obj_tipus = 3; objszin = RGB(0, 0, 250); }
	else if (strcmp(tipus, "bicycle") == 0) { obj_tipus = 23; objszin = RGB(71, 188, 226); }
	else if (strcmp(tipus, "light_rail") == 0) { obj_tipus = 25; objszin = RGB(237, 61, 193); }
	else if (strcmp(tipus, "subway") == 0) { obj_tipus = 26; objszin = RGB(0, 0, 240); }
	else if (strcmp(tipus, "park") == 0) { obj_tipus = 30; objszin = RGB(137, 216, 145); }
	else if (strcmp(tipus, "forest") == 0) { obj_tipus = 31; objszin = RGB(62, 187, 74); }
	else if (strcmp(tipus, "stream") == 0) { obj_tipus = 32; objszin = RGB(235, 123, 63); }
	else if (strcmp(tipus, "lake") == 0) { obj_tipus = 33; objszin = RGB(242, 170, 132); }
	else if (strcmp(tipus, "river") == 0) { obj_tipus = 34; objszin = RGB(235, 123, 63); }
	else if (strcmp(tipus, "tram") == 0) { obj_tipus = 50; objszin = RGB(231, 52, 245); }
	else if (strcmp(tipus, "gpx") == 0) { obj_tipus = 90; objszin = RGB(231, 52, 25); }
	else obj_tipus = 999;

	vane_teradat_betoltve = 1;

	while (1)
	{
		fread(&pontok_szama, sizeof(pontok_szama), 1, file);
		if (pontok_szama == -1) break;
		if (pontok_szama > 19999)
		{
			break;
		}
		//if (ellenorzes == 90000) break;
		view_check = 0;
		add_check = 0;
		add_check2 = 1;

		beolvpont_cache_length = 0;
		for (i = pontok_szama; i > 0; --i)
		{
			fread(&long1, sizeof(long1), 1, file);
			fread(&lat1, sizeof(lat1), 1, file);

			//if ((view_check == 0) && ((long1 > (terkepx + din_hatarX)) || (long1 < (terkepx - din_hatarX)) || (lat1 > (terkepy + din_hatarY)) || (lat1 < (terkepy - din_hatarY)))) add_check = 1;
			add_check = 0;
			view_check = 1;

			if (add_check == 0)
			{
				add_check = 1; add_check2 = 0;
			}

			if (add_check2 == 0)
			{
				//altitude = 10;
				altitude = get_height(long1, lat1);
				altitude /= altitude_ratio;

				long1 = TERKEP_NAGYITAS * (long1 - terkepx);
				lat1 = TERKEP_NAGYITAS * 2 * (terkepy - lat1 );
				beolvpont_cacheX[beolvpont_cache_length] = long1;
				beolvpont_cacheY[beolvpont_cache_length] = altitude;
				beolvpont_cacheZ[beolvpont_cache_length++] = lat1;
				/*naplo("TERKEPADAT");
				naplo_float(long1);
				naplo_float(altitude);
				naplo_float(lat1);*/
			}
		}


		if (obj_tipus == 3) altitude = 0.1;
		else altitude = 0.2;
		altitude = 0.1;

		if (obj_tipus == 2 || obj_tipus == 3 || obj_tipus == 21 || obj_tipus == 22 || obj_tipus == 32 || obj_tipus == 33 || obj_tipus == 34 || obj_tipus == 90)//road,railway, primary, motorway,stream,lake,river
		{
			for (i = 0; i < beolvpont_cache_length - 1; ++i)
			{
				raw_verticesX[raw_vertices_length[CURRENT_DEVICE]] = beolvpont_cacheX[i];
				raw_verticesY[raw_vertices_length[CURRENT_DEVICE]] = beolvpont_cacheY[i] + altitude;
				raw_verticesZ[raw_vertices_length[CURRENT_DEVICE]++] = beolvpont_cacheZ[i];

				raw_verticesX[raw_vertices_length[CURRENT_DEVICE]] = beolvpont_cacheX[i + 1];
				raw_verticesY[raw_vertices_length[CURRENT_DEVICE]] = beolvpont_cacheY[i + 1] + altitude;
				raw_verticesZ[raw_vertices_length[CURRENT_DEVICE]++] = beolvpont_cacheZ[i + 1];

				raw_verticesX[raw_vertices_length[CURRENT_DEVICE]] = beolvpont_cacheX[i + 1];
				raw_verticesY[raw_vertices_length[CURRENT_DEVICE]] = beolvpont_cacheY[i + 1] + altitude;
				raw_verticesZ[raw_vertices_length[CURRENT_DEVICE]++] = beolvpont_cacheZ[i + 1];
				++poly_counter;
				poly_szinek[poly_szinek_length[CURRENT_DEVICE]++] = objszin;
				obj_tipuslista[objlista_length[CURRENT_DEVICE]++] = obj_tipus;

				if (render_mode == 0)
				{
					if ((raw_vertices_length[0] + 3) > max_allowed_vertex_count[0])
					{
						naplo("megtelt a RAM");
						return;
					}
				}
				else if (render_mode == 1)
				{
					if ((prev_raw_vertices_length[CURRENT_DEVICE] + raw_vertices_length[CURRENT_DEVICE] + 3) > max_allowed_vertex_count[CURRENT_DEVICE])
					{
						//*******************************
						//ha ezt kivessz�k, akkor
						//extrem mem�ria kezel�st aktiv�lunk.  
						//*******************************
						data_transfer_to_GPU(CURRENT_DEVICE); return;
						//*******************************

						if ((ACTIVE_DEVICE_COUNT == 1) || ((CURRENT_GPU_INDEX + 1) == ACTIVE_DEVICE_COUNT))
						{
							data_transfer_to_GPU(CURRENT_DEVICE);
							return;
						}
						else if ((CURRENT_GPU_INDEX + 1) < ACTIVE_DEVICE_COUNT)
						{
							data_transfer_to_GPU(CURRENT_DEVICE);
							poly_szinek_length[active_GPU_list[CURRENT_GPU_INDEX + 1]] = 0;
							objlista_length[active_GPU_list[CURRENT_GPU_INDEX + 1]] = 0;
							raw_vertices_length[active_GPU_list[CURRENT_GPU_INDEX + 1]] = 0;
							prev_poly_szinek_length[active_GPU_list[CURRENT_GPU_INDEX + 1]] = prev_raw_vertices_length[active_GPU_list[CURRENT_GPU_INDEX + 1]] = 0;
							prev_objlista_length[active_GPU_list[CURRENT_GPU_INDEX + 1]] = 0;
						}

						if ((CURRENT_GPU_INDEX + 1) == ACTIVE_DEVICE_COUNT)
						{
							fclose(file);
							return;
						}
						CURRENT_DEVICE = active_GPU_list[++CURRENT_GPU_INDEX];
					}
				}				
			}
		}
		else if (obj_tipus == 30 || obj_tipus == 4)//park, water
		{						
			if (beolvpont_cache_length < 3) continue;
			for (i = 0; i < beolvpont_cache_length -1;++i)
			{
				raw_verticesX[raw_vertices_length[CURRENT_DEVICE]] = beolvpont_cacheX[i];
				raw_verticesY[raw_vertices_length[CURRENT_DEVICE]] = beolvpont_cacheY[i] + altitude;
				raw_verticesZ[raw_vertices_length[CURRENT_DEVICE]++] = beolvpont_cacheZ[i];

				raw_verticesX[raw_vertices_length[CURRENT_DEVICE]] = beolvpont_cacheX[i + 1];
				raw_verticesY[raw_vertices_length[CURRENT_DEVICE]] = beolvpont_cacheY[i + 1] + altitude;
				raw_verticesZ[raw_vertices_length[CURRENT_DEVICE]++] = beolvpont_cacheZ[i + 1];

				raw_verticesX[raw_vertices_length[CURRENT_DEVICE]] = beolvpont_cacheX[i + 1];
				raw_verticesY[raw_vertices_length[CURRENT_DEVICE]] = beolvpont_cacheY[i + 1] + altitude;
				raw_verticesZ[raw_vertices_length[CURRENT_DEVICE]++] = beolvpont_cacheZ[i + 1];
				++poly_counter;
				poly_szinek[poly_szinek_length[CURRENT_DEVICE]++] = objszin;
				obj_tipuslista[objlista_length[CURRENT_DEVICE]++] = obj_tipus;

				if (render_mode == 0)
				{
					if ((raw_vertices_length[0] + 3) > max_allowed_vertex_count[0])
					{
						naplo("megtelt a RAM");
						return;
					}
				}
				else if (render_mode == 1)
				{
					if ((prev_raw_vertices_length[CURRENT_DEVICE] + raw_vertices_length[CURRENT_DEVICE] + 3) > max_allowed_vertex_count[CURRENT_DEVICE])
					{
						//*******************************
						//ha ezt kivessz�k, akkor
						//extrem mem�ria kezel�st aktiv�lunk.  
						//*******************************
						data_transfer_to_GPU(CURRENT_DEVICE); return;
						//*******************************

						if ((ACTIVE_DEVICE_COUNT == 1) || ((CURRENT_GPU_INDEX + 1) == ACTIVE_DEVICE_COUNT))
						{
							data_transfer_to_GPU(CURRENT_DEVICE);
							return;
						}
						else if ((CURRENT_GPU_INDEX + 1) < ACTIVE_DEVICE_COUNT)
						{
							data_transfer_to_GPU(CURRENT_DEVICE);
							poly_szinek_length[active_GPU_list[CURRENT_GPU_INDEX + 1]] = 0;
							objlista_length[active_GPU_list[CURRENT_GPU_INDEX + 1]] = 0;
							raw_vertices_length[active_GPU_list[CURRENT_GPU_INDEX + 1]] = 0;
							prev_poly_szinek_length[active_GPU_list[CURRENT_GPU_INDEX + 1]] = prev_raw_vertices_length[active_GPU_list[CURRENT_GPU_INDEX + 1]] = 0;
							prev_objlista_length[active_GPU_list[CURRENT_GPU_INDEX + 1]] = 0;
						}

						if ((CURRENT_GPU_INDEX + 1) == ACTIVE_DEVICE_COUNT)
						{
							fclose(file);
							return;
						}
						CURRENT_DEVICE = active_GPU_list[++CURRENT_GPU_INDEX];
					}
				}				
			}
		}
		else if (obj_tipus == 1)//building
		{
			for (i = 0; i < beolvpont_cache_length - 1; ++i)//falak
			{
				raw_verticesX[raw_vertices_length[CURRENT_DEVICE]] = beolvpont_cacheX[i];
				raw_verticesY[raw_vertices_length[CURRENT_DEVICE]] = beolvpont_cacheY[i] + epulet_magassag;
				raw_verticesZ[raw_vertices_length[CURRENT_DEVICE]++] = beolvpont_cacheZ[i];

				raw_verticesX[raw_vertices_length[CURRENT_DEVICE]] = beolvpont_cacheX[i + 1];
				raw_verticesY[raw_vertices_length[CURRENT_DEVICE]] = beolvpont_cacheY[i + 1] + epulet_magassag;
				raw_verticesZ[raw_vertices_length[CURRENT_DEVICE]++] = beolvpont_cacheZ[i + 1];

				raw_verticesX[raw_vertices_length[CURRENT_DEVICE]] = beolvpont_cacheX[i + 1];
				raw_verticesY[raw_vertices_length[CURRENT_DEVICE]] = beolvpont_cacheY[i + 1];
				raw_verticesZ[raw_vertices_length[CURRENT_DEVICE]++] = beolvpont_cacheZ[i + 1];

				++poly_counter;
				poly_szinek[poly_szinek_length[CURRENT_DEVICE]++] = RGB(200, 200, 200);
				obj_tipuslista[objlista_length[CURRENT_DEVICE]++] = obj_tipus;

				raw_verticesX[raw_vertices_length[CURRENT_DEVICE]] = beolvpont_cacheX[i];
				raw_verticesY[raw_vertices_length[CURRENT_DEVICE]] = beolvpont_cacheY[i];
				raw_verticesZ[raw_vertices_length[CURRENT_DEVICE]++] = beolvpont_cacheZ[i];

				raw_verticesX[raw_vertices_length[CURRENT_DEVICE]] = beolvpont_cacheX[i];
				raw_verticesY[raw_vertices_length[CURRENT_DEVICE]] = beolvpont_cacheY[i] + epulet_magassag;
				raw_verticesZ[raw_vertices_length[CURRENT_DEVICE]++] = beolvpont_cacheZ[i];

				raw_verticesX[raw_vertices_length[CURRENT_DEVICE]] = beolvpont_cacheX[i + 1];
				raw_verticesY[raw_vertices_length[CURRENT_DEVICE]] = beolvpont_cacheY[i + 1];
				raw_verticesZ[raw_vertices_length[CURRENT_DEVICE]++] = beolvpont_cacheZ[i + 1];

				++poly_counter;
				poly_szinek[poly_szinek_length[CURRENT_DEVICE]++] = RGB(200, 200, 200);
				obj_tipuslista[objlista_length[CURRENT_DEVICE]++] = obj_tipus;

				if (render_mode == 0)
				{
					if ((raw_vertices_length[0] + 24) > max_allowed_vertex_count[0])
					{
						naplo("megtelt a RAM");
						return;
					}
				}
				else if (render_mode == 1)
				{
					//if ((raw_vertices_length[CURRENT_DEVICE] + 3) > 1000000)
					{
						if (((prev_raw_vertices_length[CURRENT_DEVICE] + raw_vertices_length[CURRENT_DEVICE]) + 24) > max_allowed_vertex_count[CURRENT_DEVICE])
						{
							//*******************************
							//ha ezt kivessz�k, akkor
							//extrem mem�ria kezel�st aktiv�lunk.  
							//*******************************
							data_transfer_to_GPU(CURRENT_DEVICE); return;
							//*******************************

							if ((ACTIVE_DEVICE_COUNT == 1) || ((CURRENT_GPU_INDEX + 1) == ACTIVE_DEVICE_COUNT))
							{
								data_transfer_to_GPU(CURRENT_DEVICE);
								return;
							}
							else if ((CURRENT_GPU_INDEX + 1) < ACTIVE_DEVICE_COUNT)
							{
								data_transfer_to_GPU(CURRENT_DEVICE);
								poly_szinek_length[active_GPU_list[CURRENT_GPU_INDEX + 1]] = 0;
								objlista_length[active_GPU_list[CURRENT_GPU_INDEX + 1]] = 0;
								raw_vertices_length[active_GPU_list[CURRENT_GPU_INDEX + 1]] = 0;
								prev_poly_szinek_length[active_GPU_list[CURRENT_GPU_INDEX + 1]] = prev_raw_vertices_length[active_GPU_list[CURRENT_GPU_INDEX + 1]] = 0;
								prev_objlista_length[active_GPU_list[CURRENT_GPU_INDEX + 1]] = 0;
							}
							//if ((CURRENT_GPU_INDEX + 1) < ACTIVE_DEVICE_COUNT)
							//{
							//	poly_szinek_length[active_GPU_list[CURRENT_GPU_INDEX + 1]] = poly_szinek_length[CURRENT_DEVICE];
							//	objlista_length[active_GPU_list[CURRENT_GPU_INDEX + 1]] = objlista_length[CURRENT_DEVICE];
							//	raw_vertices_length[active_GPU_list[CURRENT_GPU_INDEX + 1]] = raw_vertices_length[CURRENT_DEVICE];
							//}
							//poly_szinek_length[active_GPU_list[CURRENT_DEVICE]] = prev_poly_szinek_length[active_GPU_list[CURRENT_DEVICE]];
							//objlista_length[active_GPU_list[CURRENT_DEVICE]] = prev_objlista_length[active_GPU_list[CURRENT_DEVICE]];
							//raw_vertices_length[active_GPU_list[CURRENT_DEVICE]] = prev_raw_vertices_length[active_GPU_list[CURRENT_DEVICE]];// ez fura

							if ((CURRENT_GPU_INDEX + 1) >= ACTIVE_DEVICE_COUNT)
							{
								fclose(file);
								return;
							}
							CURRENT_DEVICE = active_GPU_list[++CURRENT_GPU_INDEX];
						}
						//data_transfer_to_GPU(CURRENT_DEVICE);
						///*poly_szinek_length[CURRENT_DEVICE] = raw_vertices_length[CURRENT_DEVICE] = 0;
						//objlista_length[CURRENT_DEVICE] = 0;*/
					}
				}
				
			}

			for (i = 0; i < beolvpont_cache_length - 2; ++i)//tet�k
			{
				raw_verticesX[raw_vertices_length[CURRENT_DEVICE]] = beolvpont_cacheX[0];
				raw_verticesY[raw_vertices_length[CURRENT_DEVICE]] = beolvpont_cacheY[0] + epulet_magassag;
				raw_verticesZ[raw_vertices_length[CURRENT_DEVICE]++] = beolvpont_cacheZ[0];

				raw_verticesX[raw_vertices_length[CURRENT_DEVICE]] = beolvpont_cacheX[i + 2];
				raw_verticesY[raw_vertices_length[CURRENT_DEVICE]] = beolvpont_cacheY[i + 2] + epulet_magassag;
				raw_verticesZ[raw_vertices_length[CURRENT_DEVICE]++] = beolvpont_cacheZ[i + 2];

				raw_verticesX[raw_vertices_length[CURRENT_DEVICE]] = beolvpont_cacheX[i + 1];
				raw_verticesY[raw_vertices_length[CURRENT_DEVICE]] = beolvpont_cacheY[i + 1] + epulet_magassag;
				raw_verticesZ[raw_vertices_length[CURRENT_DEVICE]++] = beolvpont_cacheZ[i + 1];

				++poly_counter;
				poly_szinek[poly_szinek_length[CURRENT_DEVICE]++] = RGB(0, 0, 200);
				obj_tipuslista[objlista_length[CURRENT_DEVICE]++] = obj_tipus;

				if (render_mode == 0)
				{
					if ((raw_vertices_length[0] + 6) > max_allowed_vertex_count[0])
					{
						naplo("megtelt a RAM");
						return;
					}
				}
				else if (render_mode == 1)
				{
					//if ((raw_vertices_length[CURRENT_DEVICE] + 6) > 1000000)
					{
						if (((prev_raw_vertices_length[CURRENT_DEVICE] + raw_vertices_length[CURRENT_DEVICE]) + 6) > max_allowed_vertex_count[CURRENT_DEVICE])
						{
							if ((ACTIVE_DEVICE_COUNT == 1) || ((CURRENT_GPU_INDEX + 1) == ACTIVE_DEVICE_COUNT))
							{
								data_transfer_to_GPU(CURRENT_DEVICE);
								return;
							}
							else if ((CURRENT_GPU_INDEX + 1) < ACTIVE_DEVICE_COUNT)
							{
								data_transfer_to_GPU(CURRENT_DEVICE);
								poly_szinek_length[active_GPU_list[CURRENT_GPU_INDEX + 1]] = 0;
								objlista_length[active_GPU_list[CURRENT_GPU_INDEX + 1]] = 0;
								raw_vertices_length[active_GPU_list[CURRENT_GPU_INDEX + 1]] = 0;
								prev_poly_szinek_length[active_GPU_list[CURRENT_GPU_INDEX + 1]] = prev_raw_vertices_length[active_GPU_list[CURRENT_GPU_INDEX + 1]] = 0;
								prev_objlista_length[active_GPU_list[CURRENT_GPU_INDEX + 1]] = 0;
							}
							//if ((CURRENT_GPU_INDEX + 1) < ACTIVE_DEVICE_COUNT)
							//{
							//	poly_szinek_length[active_GPU_list[CURRENT_GPU_INDEX + 1]] = poly_szinek_length[CURRENT_DEVICE];
							//	objlista_length[active_GPU_list[CURRENT_GPU_INDEX + 1]] = objlista_length[CURRENT_DEVICE];
							//	raw_vertices_length[active_GPU_list[CURRENT_GPU_INDEX + 1]] = raw_vertices_length[CURRENT_DEVICE];
							//}
							////az utolso adag adatot ignoraljuk: nincs hov� elmenteni
							//poly_szinek_length[active_GPU_list[CURRENT_DEVICE]] = prev_poly_szinek_length[active_GPU_list[CURRENT_DEVICE]];
							//objlista_length[active_GPU_list[CURRENT_DEVICE]] = prev_objlista_length[active_GPU_list[CURRENT_DEVICE]];
							//raw_vertices_length[active_GPU_list[CURRENT_DEVICE]] = prev_raw_vertices_length[active_GPU_list[CURRENT_DEVICE]];// ez fura

							if ((CURRENT_GPU_INDEX + 1) >= ACTIVE_DEVICE_COUNT)
							{
								fclose(file);
								return;
							}
							CURRENT_DEVICE = active_GPU_list[++CURRENT_GPU_INDEX];
						}
						//data_transfer_to_GPU(CURRENT_DEVICE);
						///*poly_szinek_length[CURRENT_DEVICE] = raw_vertices_length[CURRENT_DEVICE] = 0;
						//objlista_length[CURRENT_DEVICE] = 0;*/
					}
				}
				
			}
		}

	}
	fclose(file);
	if (render_mode == 0)
	{
		;//it nem kell csin�lni semmit
	}
	else if (render_mode == 1)
	{
		if ((raw_vertices_length[CURRENT_DEVICE]) > 0)
		{
			data_transfer_to_GPU(CURRENT_DEVICE);
		}
	}
	
}

__global__ void add_height(int maxitemcount, float* rawarrayY)
{
	int i;
	int index = (blockIdx.x * blockDim.x) + (threadIdx.x * 1);
	int stride = blockDim.x * gridDim.x;
	for (i = index; i < maxitemcount; i += stride) rawarrayY[i] *= 1.1;
}

__global__ void lower_height(int maxitemcount, float* rawarrayY)
{
	int i;
	int index = (blockIdx.x * blockDim.x) + (threadIdx.x * 1);
	int stride = blockDim.x * gridDim.x;
	for (i = index; i < maxitemcount; i += stride) rawarrayY[i] /= 1.1;
}

void data_load(void)
{
	int i, j;
	char hibauzenet[256];
	int terrain_bevantoltve = 0;

	poly_counter = vertex_counter = 0;

	init_before_dataload();

	if(xtreme_vram_onoff == 1) pre_D2D_drawing_TURBO_XM();

	for (i = 0; i < ACTIVE_DEVICE_COUNT; ++i)
	{
		//prev_raw_vertices_length[active_GPU_list[i]] = prev_poly_szinek_length[active_GPU_list[i]] = 0;
		for (j = 0; j < 17; ++j)
		{
			if (layer_settings[active_GPU_list[i]][j] == 1)
			{
				CURRENT_DEVICE = active_GPU_list[i];//ezt a r�szt �thelyezni
				//raw_vertices_length[active_GPU_list[i]] = poly_szinek_length[active_GPU_list[i]] = 0;//ezt a r�szt �thelyezni

				if (j == 0 && terrain_bevantoltve == 0)
				{
					if (render_type > 0) terrain_betolt_TRIANGLE("data\\world_HGT.hgt", ((terkepx + 180) * TILEROW), ((60 - terkepy) * TILEROW), domb_width, domb_height);
					else terrain_betolt_POINT("data\\world_HGT.hgt", ((terkepx + 180) * TILEROW), ((60 - terkepy) * TILEROW), domb_width, domb_height);
					vane_teradat_betoltve = 1;

					naplo("Domborzat betoltes OK");
					terrain_bevantoltve = 1;
				}
				else if (j == 3) TER_betolt("data\\buildings.ter", "building");
				else if (j == 5) TER_betolt("data\\lake.ter", "lake");
				else if (j == 16) TER_betolt("data\\waterways.ter", "water");
				else if (j == 7) TER_betolt("data\\motorway.ter", "motorway");
				else if (j == 8) TER_betolt("data\\park.ter", "park");
				else if (j == 9) TER_betolt("data\\primary.ter", "primary");
				else if (j == 10) TER_betolt("data\\railway.ter", "railway");
				else if (j == 11) TER_betolt("data\\river.ter", "river");
				else if (j == 12) TER_betolt("data\\roads.ter", "road");
				else if (j == 13) TER_betolt("data\\stream.ter", "stream");
			}

		}
		//raw_vertices_length[active_GPU_list[i]] = prev_raw_vertices_length[active_GPU_list[i]] + raw_vertices_length[active_GPU_list[i]];
		//poly_szinek_length[active_GPU_list[i]] = prev_poly_szinek_length[active_GPU_list[i]] + poly_szinek_length[active_GPU_list[i]];
	}

	if (GXP_shall_be_loaded == 1)
	{
		TER_betolt("data\\gpx.ter", "gpx");
	}

	if (xtreme_vram_onoff == 1) post_D2D_drawing_TURBO_XM();
	naplo("Adatbet�lt�s lez�rult");
}

void init_before_dataload(void)
{
	int i, j;
	srand((unsigned)time(NULL));
	if (render_mode == 0)
	{
		poly_szinek_length[0] = 0;
		objlista_length[0] = 0;
		raw_vertices_length[0] = 0;
		prev_raw_vertices_length[0] = 0;
		prev_poly_szinek_length[0] = 0;
		prev_objlista_length[0] = 0;
	}
	else if (render_mode == 1)
	{
		for (i = 0; i < CUDA_DEVICE_COUNT; ++i)
		{
			poly_szinek_length[active_GPU_list[i]] = 0;
			objlista_length[active_GPU_list[i]] = 0;
			raw_vertices_length[active_GPU_list[i]] = 0;
			prev_raw_vertices_length[i] = 0;
			prev_poly_szinek_length[i] = 0;
			prev_objlista_length[i] = 0;
		}

		CURRENT_GPU_INDEX = 0;
		CURRENT_DEVICE = active_GPU_list[CURRENT_GPU_INDEX];
	}
	
	muvelet_length = 0;
}

void pre_D2D_drawing_TURBO_XM(void)
{
	if (drawing_in_progress == 1) return;
	drawing_in_progress = 1;

	int i;

	if (render_mode == 0)
	{
		CPU_CleanUp_Zbuffer(cpu_zbuffer);
	}
	else if (render_mode == 1)
	{
		for (i = 0; i < ACTIVE_DEVICE_COUNT; ++i)
		{
			cudaSetDevice(active_GPU_list[i]);
			CUDA_CleanUp_Zbuffer << < 128, BLOCKSIZE >> > (dev_zbuffer[active_GPU_list[i]]);
		}
		cudaDeviceSynchronize();

		for (i = 0; i < ACTIVE_DEVICE_COUNT; ++i)
		{
			cudaSetDevice(active_GPU_list[i]);
			cudaMemset(dev_image_data[active_GPU_list[i]], 0, SCREEN_HEIGHT * SCREEN_WIDTH * sizeof(unsigned int));
		}
		cudaDeviceSynchronize();
	}
	
}

void D2D_drawing_TURBO_XM(void)
{
	int i;

	rot_degree_x = rot_degree_x2 * Math_PI / 180;
	rot_degree_y = rot_degree_y2 * Math_PI / 180;
	rot_degree_z = rot_degree_z2 * Math_PI / 180;
	float degree_sinx = sin(rot_degree_x);
	float degree_cosx = cos(rot_degree_x);
	float degree_siny = sin(rot_degree_y);
	float degree_cosy = cos(rot_degree_y);
	float degree_sinz = sin(rot_degree_z);
	float degree_cosz = cos(rot_degree_z);

	for (i = 0; i < ACTIVE_DEVICE_COUNT; ++i)
	{
		if (prev_raw_vertices_length[i] < 1) continue;
		cudaSetDevice(active_GPU_list[i]);

		CUDA_render_TURBO << <128, BLOCKSIZE >> > (prev_raw_vertices_length[active_GPU_list[i]], dev_raw_verticesX[active_GPU_list[i]], dev_raw_verticesY[active_GPU_list[i]], dev_raw_verticesZ[active_GPU_list[i]], degree_cosx, degree_sinx, degree_cosy, degree_siny, degree_cosz, degree_sinz, dev_image_data[active_GPU_list[i]], dev_zbuffer[active_GPU_list[i]], vLight, dev_poly_szinek[active_GPU_list[i]], dev_obj_tipuslista[active_GPU_list[i]]);
		//CUDA_render_TURBO << <128, BLOCKSIZE >> > (33000, dev_raw_verticesX[active_GPU_list[i]], dev_raw_verticesY[active_GPU_list[i]], dev_raw_verticesZ[active_GPU_list[i]], degree_cosx, degree_sinx, degree_cosy, degree_siny, degree_cosz, degree_sinz, dev_image_data[active_GPU_list[i]], dev_zbuffer[active_GPU_list[i]], vLight, dev_poly_szinek[active_GPU_list[i]], terrain_vertexcount);
	}
	cudaDeviceSynchronize();

	//*************CUDA MERGE CACHE************
	cudaSetDevice(0);
	if (ACTIVE_DEVICE_COUNT > 1)
	{
		for (i = 1; i < ACTIVE_DEVICE_COUNT; ++i)
		{
			cudaMemcpyPeer(dev_secondary_zbuffer[active_GPU_list[0]], 0, dev_zbuffer[active_GPU_list[i]], i, SCREEN_WIDTH * SCREEN_HEIGHT * sizeof(float));
			cudaMemcpyPeer(dev_secondary_image_data[active_GPU_list[0]], 0, dev_image_data[active_GPU_list[i]], i, SCREEN_WIDTH * SCREEN_HEIGHT * sizeof(unsigned int));
			CUDA_Merge_Zbuffers << <128, 384 >> > (dev_zbuffer[active_GPU_list[0]], dev_secondary_zbuffer[active_GPU_list[0]], dev_image_data[active_GPU_list[0]], dev_secondary_image_data[active_GPU_list[0]]);
		}
		cudaDeviceSynchronize();
	}
	//*****************************************

	//strcpy(hibauzenet, cudaGetErrorString(cudaGetLastError()));
}

void post_D2D_drawing_TURBO_XM(void)
{
	swap_main_buffer();

	drawing_in_progress = 0;
}

int get_height_color(int mag_ertek)
{
	
	{
		return 0;
	}
}

//************************CPU ONLY RENDER ROUTINES**************
void cpu_data_load(void)
{
	int i, j;
	int terrain_bevantoltve = 0;

	poly_counter = vertex_counter = 0;

	init_before_dataload();

	if (xtreme_vram_onoff == 1) pre_D2D_drawing_TURBO_XM();

	for (j = 0; j < 17; ++j)
	{
		if (layer_settings[0][j] == 1)
		{
			if (j == 0 && terrain_bevantoltve == 0)
			{
				if (render_type > 0) terrain_betolt_TRIANGLE("data\\world_HGT.hgt", ((terkepx + 180) * TILEROW), ((60 - terkepy) * TILEROW), domb_width, domb_height);
				else terrain_betolt_POINT("data\\world_HGT.hgt", ((terkepx + 180) * TILEROW), ((60 - terkepy) * TILEROW), domb_width, domb_height);

				//***************DEMOHOZ******************
				//domb_width = 8600; domb_height = 3800;
				//terrain_betolt_FIX("data\\terrain_hungary.ter", ((terkepx + 180) * TILEROW), ((61 - terkepy) * TILEROW), domb_width, domb_height);
				//****************************************

				naplo("Domborzat betoltes OK");
				terrain_bevantoltve = 1;
			}
			else if (j == 3) TER_betolt("data\\buildings.ter", "building");
			else if (j == 5) TER_betolt("data\\lake.ter", "lake");
			else if (j == 7) TER_betolt("data\\motorway.ter", "motorway");
			else if (j == 8) TER_betolt("data\\park.ter", "park");
			else if (j == 9) TER_betolt("data\\primary.ter", "primary");
			else if (j == 10) TER_betolt("data\\railway.ter", "railway");
			else if (j == 12) TER_betolt("data\\roads.ter", "road");
		}
	}

	if (GXP_shall_be_loaded == 1)
	{
		TER_betolt("data\\gpx.ter", "gpx");
	}

	if (xtreme_vram_onoff == 1) post_D2D_drawing_TURBO_XM();
	naplo("Adatbet�lt�s lez�rult");
}
