/******************************************************************************************************
Copyright(c) < 2024 > <copyright holder : Kriszti�n Dezs� Feh�r, Hungary>
Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files(the "Software"),
to deal in the Software without restriction, except the commercial usage, including without limitation the rights to use, copy, modify, merge, publish, distribute copies of the Software,
and to permit persons to whom the Software is furnished to do so, subject to the following conditions :

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
******************************************************************************************************/
#pragma once
#include "include\\D2D_renderer.h"

typedef struct {
	int eredmeny;//-1: nincs talalat,0-van talalat
	int start_index;
	int end_index;
} xml_search_minta;
#define MAX_XML_SIZE 1024 * 1024

xml_search_minta xml_kereses;
char xml_data[MAX_XML_SIZE] = { "" };

typedef struct {
	int elevation;//-1: nincs talalat,0-van talalat
	float latitude;
	float longitude;
} GPX_content;
int GPX_adat_count;
GPX_content GPX_adatok[10000];

int GXP_shall_be_loaded = 0;//0-nem, 1-igen

void update_gpx_listbox(HWND listadoboz);
void import_gpx_data(void);
void select_tracking_data(void);
void select_waypoint_data(void);
void gpx_show_overview(HWND listadoboz, HWND szovegcimke);
double sajat_rad(double fok);
void gpx_show_heightmap(HWND szovegcimke);
xml_search_minta gpx_xml_search_next(char* searchstr, char* leftstr, char* rightstr, int startpoz);

void GPX_DrawLine(int x1, int y1, int x2, int y2, int color, COLORREF* puffer);

void gpx_cleanup_preview(void);

void update_gpx_listbox(HWND listadoboz)
{
	WIN32_FIND_DATAA FindFileData;
	HANDLE hFind;
	char fajlnev[256];

	SendMessageA(listadoboz, LB_RESETCONTENT, 0, 0);

	hFind = FindFirstFileA("gpx\\*.gpx", &FindFileData);
	if (hFind == INVALID_HANDLE_VALUE) return;

	do
	{
		int i;

		for (i = 0; i < strnlen_s(FindFileData.cFileName, 256); ++i)
			fajlnev[i] = FindFileData.cFileName[i];
		fajlnev[strnlen_s(FindFileData.cFileName, 256)] = 0;

		if (strcmp((const char*)FindFileData.cFileName, ".") == 0) continue;
		if (strcmp((const char*)FindFileData.cFileName, "..") == 0) continue;
		
		SendMessageA(listadoboz, LB_ADDSTRING, 0, (LPARAM)FindFileData.cFileName);

	} while (FindNextFileA(hFind, &FindFileData) != 0);

	FindClose(hFind);
}

void import_gpx_data(void)
{
	GXP_shall_be_loaded = 1;

	FILE* fajl;
	int i;
	fopen_s(&fajl, "data\\gpx.ter", "wb");
	if (fajl != NULL)
	{
		fwrite(&GPX_adat_count, sizeof(GPX_adat_count), 1, fajl);
		for (i = 0; i < GPX_adat_count; ++i)
		{
			fwrite(&GPX_adatok[i].longitude, sizeof(GPX_adatok[i].longitude), 1, fajl);
			fwrite(&GPX_adatok[i].latitude, sizeof(GPX_adatok[i].latitude), 1, fajl);
		}
	}
	i = -1;//end of TER file
	fwrite(&i, sizeof(i), 1, fajl);
	fclose(fajl);	
}

void select_tracking_data(void)
{
	;
}

void select_waypoint_data(void)
{
	;
}

void gpx_show_overview(HWND listadoboz, HWND szovegcimke)
{
	//************* adatok beolvasasa ***************
	FILE* fajl;
	char szoveg[256] = { "" }, szoveg2[256] = { "" },adat=0;
	int adathossz = 0;
	int sorszam = (int)SendMessage(listadoboz, LB_GETCURSEL, (WPARAM)0, (WPARAM)0);
	int hossz = (int)SendMessage(listadoboz, LB_GETTEXTLEN, (WPARAM)sorszam, (WPARAM)0);
	int i,j;
	float tavolsag = 0,magassag=0;

	SendMessage(listadoboz, LB_GETTEXT, (WPARAM)sorszam, (WPARAM)szoveg);
	SetWindowTextA(szovegcimke, "Analyzing...");

	for (i = 0; i < MAX_XML_SIZE; ++i) xml_data[i] = 0;

	strcpy_s(szoveg2,"gpx\\");
	strcat_s(szoveg2,szoveg);
	i = 0;
	fopen_s(&fajl, szoveg2, "rb");
	if (fajl != NULL)
	{
		while (!feof(fajl))
		{
			fread_s(&adat, sizeof(adat), sizeof(char), 1, fajl);
			xml_data[i++] = adat;
		}
		fclose(fajl);
	}

	xml_kereses.eredmeny = 0;
	xml_kereses.start_index = 0;
	xml_kereses.end_index = 0;

	GPX_adat_count = 0;
	
	while (xml_kereses.eredmeny != -1)
	{
		xml_kereses = gpx_xml_search_next(xml_data, "lat=\"", "\"", xml_kereses.end_index);
		//for (i = 0; i < 256; ++i) szoveg2[i] = 0;
		for (i = 0, j = xml_kereses.start_index; j < xml_kereses.end_index; ++j) szoveg2[i++] = xml_data[j];
		szoveg2[i] = 0;
		GPX_adatok[GPX_adat_count].latitude = atof(szoveg2);

		xml_kereses = gpx_xml_search_next(xml_data, "lon=\"", "\"", xml_kereses.end_index);
		//for (i = 0; i < 256; ++i) szoveg2[i] = 0;
		for (i = 0, j = xml_kereses.start_index; j < xml_kereses.end_index; ++j) szoveg2[i++] = xml_data[j];
		szoveg2[i] = 0;
		GPX_adatok[GPX_adat_count].longitude = atof(szoveg2);

		xml_kereses = gpx_xml_search_next(xml_data, "<ele>", "<", xml_kereses.end_index);
		//for (i = 0; i < 256; ++i) szoveg2[i] = 0;
		for (i = 0, j = xml_kereses.start_index; j < xml_kereses.end_index; ++j) szoveg2[i++] = xml_data[j];
		szoveg2[i] = 0;
		GPX_adatok[GPX_adat_count].elevation = atoi(szoveg2);

		if (xml_kereses.eredmeny == 0) ++GPX_adat_count;		

	}

	//************* szoveges adatok kiszamolasa ***************

	itoa(GPX_adat_count, szoveg2, 10);
	strcpy_s(szoveg,szoveg2);
	strcat_s(szoveg," waypoints\nDistance: ");

	float sajat_PI = 3.14159265358979323846;
	tavolsag = 0.0f;

	for (i = 0; i < GPX_adat_count-1; ++i)//teljes tavolsag kiszamitasa
	{
		//tavolsag += acosf(cosf(((90.0f - GPX_adatok[i].latitude) * (sajat_PI /180.0f))) * cosf(((90.0f - GPX_adatok[i+1].latitude) * (sajat_PI /180.0f))) + sinf(((90.0f- GPX_adatok[i].latitude) *
		//	(sajat_PI /180.0f))) * sinf(((90.0f- GPX_adatok[i+1].latitude) * (sajat_PI /180.0f))) * cosf(((GPX_adatok[i].longitude - GPX_adatok[i+1].longitude) * (sajat_PI /180.0f)))) * 6371.0f;

		tavolsag += acos(cos(sajat_rad(90.0f - GPX_adatok[i].latitude)) *
			cos(sajat_rad(90.0f - GPX_adatok[i + 1].latitude)) +
			sin(sajat_rad(90.0f - GPX_adatok[i].latitude)) *
			sin(sajat_rad(90.0f - GPX_adatok[i + 1].latitude)) *
			cos(sajat_rad(GPX_adatok[i].longitude - GPX_adatok[i + 1].longitude))) * 6371.0f;

		magassag += fabsf(GPX_adatok[i].elevation - GPX_adatok[i+1].elevation);
	}

	sprintf(szoveg2, "%f", tavolsag);	
	strcat_s(szoveg, szoveg2);
	strcat_s(szoveg, " km\nTotal elevation: ");
	sprintf(szoveg2, "%f", magassag);
	strcat_s(szoveg, szoveg2);
	strcat_s(szoveg, " m\n");
	SetWindowTextA(szovegcimke,szoveg);


	//************* utvonal kirajzolasa***************

	gpx_cleanup_preview();
		
	//*** a rajzolas dimenzi�inak meghat�roz�sa az ar�nyokhoz: c�l:320x200-as viewport*****
	float viewportwidth = 280, viewportheight = 180;
	float minlong=9999, minlat=9999, maxlong=-9999, maxlat=-9999;
	for (i = 0; i < GPX_adat_count; ++i)
	{
		if (GPX_adatok[i].longitude < minlong) minlong = GPX_adatok[i].longitude;
		if (GPX_adatok[i].latitude < minlat) minlat = GPX_adatok[i].latitude;
		if (GPX_adatok[i].longitude > maxlong) maxlong = GPX_adatok[i].longitude;
		if (GPX_adatok[i].latitude > maxlat) maxlat = GPX_adatok[i].latitude;
	}

	int tesztcolor = RGB(0, 0, 0);
	float x1, y1, x2, y2;
	float segedlong = viewportwidth / fabsf(maxlong-minlong), segedlat = viewportheight / fabsf(maxlat-minlat);

	for (i = 0; i < GPX_adat_count - 1; ++i)
	{
		x1 = (GPX_adatok[i].longitude - minlong) * segedlong;
		y1 = (maxlat - GPX_adatok[i].latitude) * segedlat;
		x2 = (GPX_adatok[i+1].longitude - minlong) * segedlong;
		y2 = (maxlat - GPX_adatok[i+1].latitude) * segedlat;
		GPX_DrawLine(x1,y1,x2,y2, tesztcolor, GPX_memkeptarolo);
	}

	hbitmapScreen = CreateBitmap(GPX_SCREEN_WIDTH, GPX_SCREEN_HEIGHT, 1, 8 * 4, (void*)GPX_memkeptarolo);
	SelectObject(hdcMemDC, hbitmapScreen);
	BitBlt(hdcWindow, 350, 50, GPX_SCREEN_WIDTH, GPX_SCREEN_HEIGHT, hdcMemDC, 0, 0, SRCCOPY);
	DeleteObject(hbitmapScreen);
}

double sajat_rad(double fok)
{//float-tal nem m�k�dik!
	double sajat_PI = 3.14159265358979323846;

	return fok * sajat_PI / 180.0l;
}

void gpx_show_heightmap(HWND szovegcimke)
{
	int i;
	char szoveg[256] = { "" }, szoveg2[256] = { "" };

	gpx_cleanup_preview();

	//*** a rajzolas dimenzi�inak meghat�roz�sa az ar�nyokhoz: c�l:320x200-as viewport*****
	float viewportwidth = 280, viewportheight = 180;
	float minelev = 99999, maxelev = -9999;
	for (i = 0; i < GPX_adat_count; ++i)
	{
		if (GPX_adatok[i].elevation < minelev) minelev = GPX_adatok[i].elevation;
		if (GPX_adatok[i].elevation > maxelev) maxelev = GPX_adatok[i].elevation;
	}

	int tesztcolor = RGB(0, 0, 0);
	float x1, y1, x2, y2;
	float segedelev = viewportheight / maxelev,segedlepeskoz=viewportwidth/(float)GPX_adat_count;

	for (i = 0; i < GPX_adat_count - 1; ++i)
	{
		x1 = (float)i * segedlepeskoz;
		y1 = viewportheight + 10 - (GPX_adatok[i].elevation * segedelev);
		x2 = (float)(i+1) * segedlepeskoz;
		y2 = viewportheight + 10 - (GPX_adatok[i + 1].elevation * segedelev);
		GPX_DrawLine(x1, y1, x2, y2, tesztcolor, GPX_memkeptarolo);
	}

	hbitmapScreen = CreateBitmap(GPX_SCREEN_WIDTH, GPX_SCREEN_HEIGHT, 1, 8 * 4, (void*)GPX_memkeptarolo);
	SelectObject(hdcMemDC, hbitmapScreen);
	BitBlt(hdcWindow, 350, 50, GPX_SCREEN_WIDTH, GPX_SCREEN_HEIGHT, hdcMemDC, 0, 0, SRCCOPY);
	DeleteObject(hbitmapScreen);

	strcpy_s(szoveg, "Min.altitude: ");	
	sprintf(szoveg2, "%f", minelev);
	strcat_s(szoveg, szoveg2);
	strcat_s(szoveg, " m\nMax. altitude: ");
	sprintf(szoveg2, "%f", maxelev);
	strcat_s(szoveg, szoveg2);
	strcat_s(szoveg, " m");
	SetWindowTextA(szovegcimke, szoveg);
}

xml_search_minta gpx_xml_search_next(char *searchstr,char *leftstr, char *rightstr, int startpoz)
{
	xml_search_minta akt_kereses;
	int i,j,lstr_hossz= strnlen_s(leftstr, 256), rstr_hossz = strnlen_s(rightstr, 256),teljes_xml_hossz= strnlen_s(searchstr, MAX_XML_SIZE);
	int egyezes = -1;//-1-nincsen,0-megvan

	akt_kereses.eredmeny = -1;
	akt_kereses.start_index = startpoz;
	akt_kereses.end_index = startpoz;

	for (i = startpoz; i < teljes_xml_hossz; ++i)
	{
		if (searchstr[i] == leftstr[0])
		{
			egyezes = -1;
			akt_kereses.start_index = i + lstr_hossz;
			for (j = 1; j < lstr_hossz; ++j)
			{
				if (searchstr[i + j] == leftstr[j]) egyezes = 0;
				else
				{
					egyezes = -1;
					akt_kereses.eredmeny = -1;
					break;
				}
			}

			if (egyezes == 0)
			{
				egyezes = -1;
				i += lstr_hossz;
				for (; i < teljes_xml_hossz; ++i)
				{
					if (searchstr[i] == rightstr[0])
					{
						egyezes = 0;
						akt_kereses.eredmeny = 0;
						akt_kereses.end_index = i;
						return akt_kereses;
					}
				}				
			}
		}
	}

	return akt_kereses;
}

void GPX_DrawLine(int x1, int y1, int x2, int y2, int color, COLORREF *puffer)
{
	int dx = abs(x2 - x1);
	int dy = abs(y2 - y1);
	int sx = (x1 < x2) ? 1 : -1;
	int sy = (y1 < y2) ? 1 : -1;
	int err = dx - dy;

	while (1) {
		puffer[(y1 * SCREEN_WIDTH) + x1] = color;
		if (x1 == x2 && y1 == y2) break;
		int e2 = err * 2;
		if (e2 > -dy) {
			err -= dy;
			x1 += sx;
		}
		if (e2 < dx) {
			err += dx;
			y1 += sy;
		}
	}
}

void gpx_cleanup_preview(void)
{
	memset(GPX_memkeptarolo, 255, GPX_SCREEN_HEIGHT * GPX_SCREEN_WIDTH * sizeof(unsigned int));
	hbitmapScreen = CreateBitmap(GPX_SCREEN_WIDTH, GPX_SCREEN_HEIGHT, 1, 8 * 4, (void*)GPX_memkeptarolo);
	SelectObject(hdcMemDC, hbitmapScreen);
	BitBlt(hdcWindow, 350, 50, GPX_SCREEN_WIDTH, GPX_SCREEN_HEIGHT, hdcMemDC, 0, 0, SRCCOPY);
	DeleteObject(hbitmapScreen);
}