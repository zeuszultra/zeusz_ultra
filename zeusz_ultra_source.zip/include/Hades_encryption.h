/******************************************************************************************************
Copyright(c) < 2024 > <copyright holder : Kriszti�n Dezs� Feh�r, Hungary>
Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files(the "Software"),
to deal in the Software without restriction, except the commercial usage, including without limitation the rights to use, copy, modify, merge, publish, distribute copies of the Software,
and to permit persons to whom the Software is furnished to do so, subject to the following conditions :

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
******************************************************************************************************/
#pragma once
#include <windows.h>
#include <stdio.h>

char Hades_onoff = 0; //0=ki, 1=be
char vankulcs = 0; //0=NINCS, 1=VAN
const char alapminta[] = "aA����bBcCd._|DeE��fFgGhHiI��jJkKlLmMnNoO����.0123456789._|pPqQrRsS�tTuU����vVwWxXyYzZ._|0123456789aA��bBcCdDeE��fFgGhHiI��j._|JkKlL0123456789mMnNoO����pPqQrRsStTuU����vVwWxXyYzZ._|0123456789._|";
#define MAX_MSG_LENGTH 768
#define KEY_LENGTH 64
unsigned int kulcs[KEY_LENGTH];
FILE* fajl;
char szeles_adatmezo[MAX_MSG_LENGTH];

void Hades_init(void);
void Hades_decrypt(char* dest, char* src);
void Hades_encrypt(char* dest, char* src);
void kulcsletrehoz(void);

void Hades_init(void)
{
	int s1, s2;
	s2 = strlen(alapminta) - 1;
	fopen_s(&fajl, "key.key", "rb");
	if (fajl == NULL) vankulcs = 0;
	else
	{
		vankulcs = 1;
		fread(kulcs, sizeof(unsigned int), KEY_LENGTH, fajl);
		fclose(fajl);
	}
	srand((int)GetTickCount64());
	for (s1 = 0; s1 < MAX_MSG_LENGTH; ++s1)
	{
		szeles_adatmezo[s1] = alapminta[(rand() % (s2 + 1))];
	}
}

void Hades_decrypt(char* dest, char* src)
{
	int s1, s2;
	int szoveghossz=0;
	char szoveg[KEY_LENGTH] = "";

	if (vankulcs == 0) return;//hibakezel�s

	for (s1 = 0; s1 < KEY_LENGTH; ++s1) { szoveg[s1] = 0; }
	for (s1 = 0; s1 < MAX_MSG_LENGTH; ++s1) { dest[s1] = 0; }
	for (s1 = 0; s1 < MAX_MSG_LENGTH; ++s1) { szeles_adatmezo[s1] = src[s1]; }

	//strcpy_s(szeles_adatmezo, sizeof(szeles_adatmezo), src);
	for (s1 = 0; s1 < KEY_LENGTH; ++s1) { szoveg[s1] = szeles_adatmezo[(kulcs[s1])]; }
	//strcpy_s(dest, sizeof(szoveg), szoveg);
	for (s1 = 0; s1 < KEY_LENGTH; ++s1) { dest[s1] = szoveg[s1]; }
}

void Hades_encrypt(char* dest, char* src)
{
	int s1;
	int szoveghossz;
	char szoveg[KEY_LENGTH] = "";

	if (vankulcs == 0) return;//hibakezel�s

	for (s1 = 0; s1 < KEY_LENGTH; ++s1) { szoveg[s1] = 0; }
	for (s1 = 0; s1 < MAX_MSG_LENGTH; ++s1) { dest[s1] = 0; }
	strcpy_s(szoveg, sizeof(szoveg), src);
	for (s1 = strlen(szoveg); s1 < KEY_LENGTH; ++s1)
	{
		szoveg[s1] = 65;
	}
	szoveghossz = strlen(src);
	if ((szoveghossz == 0) || (szoveghossz > KEY_LENGTH)) return;//hibakezel�s

	for (s1 = 0; s1 < szoveghossz; ++s1) { szeles_adatmezo[(kulcs[s1])] = szoveg[s1]; }
	for (s1 = 0; s1 < MAX_MSG_LENGTH; ++s1) { dest[s1] = szeles_adatmezo[s1]; }

	Hades_init();
}

void kulcsletrehoz(void)
{
	int s1, s2;
	unsigned int kulcs[KEY_LENGTH];
	int szoveghossz;
	char szoveg[KEY_LENGTH];

	for (s1 = 0; s1 < KEY_LENGTH; ++s1) { kulcs[s1] = 0; }
	fopen_s(&fajl, "new_key.key", "w+b");
	if (fajl == NULL) return;//hibakezel�s
	else
	{
		srand((int)GetTickCount64());
		for (s1 = 0; s1 < KEY_LENGTH; ++s1)
		{
			kulcs[s1] = rand() % MAX_MSG_LENGTH;
			for (s2 = 0; s2 < s1; ++s2)
			{
				if (s2 == 0)
				{
					if (kulcs[s2] == kulcs[s1]) { --s1; break; }
				}
				else
				{
					if ((abs((int)kulcs[s2 - 1] - (int)kulcs[s1])) < 3) { --s1; break; }
				}
			}
			s2 = s1;
			if ((abs((int)kulcs[s2 - 1] - (int)kulcs[s1])) < 2) { --s1; }
		}

		fwrite(kulcs, sizeof(unsigned int), KEY_LENGTH, fajl);
		fflush(fajl);
		fclose(fajl);
		vankulcs = 1;
		for (s1 = 0; s1 < KEY_LENGTH; ++s1) { kulcs[s1] = 0; }
		for (s1 = 0; s1 < KEY_LENGTH; ++s1) { szoveg[s1] = 0; }
	}
}