/******************************************************************************************************
Copyright(c) < 2024 > <copyright holder : Kriszti�n Dezs� Feh�r, Hungary>
Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files(the "Software"),
to deal in the Software without restriction, except the commercial usage, including without limitation the rights to use, copy, modify, merge, publish, distribute copies of the Software,
and to permit persons to whom the Software is furnished to do so, subject to the following conditions :

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
******************************************************************************************************/
#pragma once

ID2D1Factory* pD2DFactory = NULL;
ID2D1HwndRenderTarget* pRT = NULL;
ID2D1Bitmap* memkeptarolo = NULL;
unsigned int D2D_imagebuffer[SCREEN_WIDTH * SCREEN_HEIGHT];
unsigned int *prerender_D2D_imagebuffer[360 / ROTANGLE];

//ID2D1Factory* GPX_pD2DFactory = NULL;
//ID2D1HwndRenderTarget* GPX_pRT = NULL;
//ID2D1Bitmap* GPX_memkeptarolo = NULL;
//unsigned int GPX_D2D_imagebuffer[GPX_SCREEN_WIDTH * GPX_SCREEN_HEIGHT];

HDC hdcWindow = NULL;
HDC hdcMemDC = NULL;
COLORREF GPX_memkeptarolo[GPX_SCREEN_WIDTH * GPX_SCREEN_HEIGHT];
HBITMAP hbitmapScreen = NULL;