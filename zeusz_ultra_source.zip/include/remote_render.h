/******************************************************************************************************
Copyright(c) < 2024 > <copyright holder : Kriszti�n Dezs� Feh�r, Hungary>
Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files(the "Software"),
to deal in the Software without restriction, except the commercial usage, including without limitation the rights to use, copy, modify, merge, publish, distribute copies of the Software,
and to permit persons to whom the Software is furnished to do so, subject to the following conditions :

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
******************************************************************************************************/
#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <math.h>
#include <string.h>
#include "cuda_runtime.h"
#include "device_launch_parameters.h"

//***************
//For MASTER MODE
//***************
typedef struct {
    char name[12];
    char render_folder[256];
    char info[1024];
    int start_degree;
    int end_degree;
    char torolve;//1-torolve,0-foglalt
} farm_device;
#define MAXFARMDEVCOUNT 72
farm_device farm_device_list[MAXFARMDEVCOUNT];
int farm_device_count,farm_finished_device_count=0;
int farm_device_statuses[MAXFARMDEVCOUNT];//-2: start/ready, -1 finished, 0-100 percent
int remote_zoom_direction = 0;//0-nincs,-1-zoom_out,1-zoom_in

//***************
//SLAVE MODE
//***************
int command_processing = 0;//0-ready,1-busy
int slave_start_degree = 0, slave_end_degree = 0;;

void cleanup_farm_device_list(void);
void update_hardware_info(int mennyiseg, cudaDeviceProp* eszkozok_listaja, int RAM_mennyiseg,int render_uzemmod);
void select_farm_item(HWND target_text1, HWND target_text2, HWND target_listbox, HWND target_start_degree, HWND target_end_degree, HWND target_infotext);
void farm_start_remote_render(HWND target_listbox,HWND target_text1, HWND target_infotext);
void farm_start_egpu_render(void);
void farm_add(HWND source_text_pcname, HWND source_text_folder, HWND target_listbox);
void farm_remove(HWND source_text_pcname);
int farm_search_pcname(HWND source_text_pcname);
void farm_setup_SAVE(void);
void farm_setup_LOAD(HWND target_listbox);
int get_farm_device_index(int frameindex);

void cleanup_farm_device_list(void)
{
    int i;

    for (i = 0; i < MAXFARMDEVCOUNT; ++i)
    {
        strcpy_s(farm_device_list[i].name, _countof(farm_device_list[i].name),"");
        strcpy_s(farm_device_list[i].render_folder, _countof(farm_device_list[i].render_folder), "");
        strcpy_s(farm_device_list[i].info, _countof(farm_device_list[i].info), "");
        farm_device_list[i].start_degree = 0;
        farm_device_list[i].end_degree = 360;
        farm_device_list[i].torolve = 1;
    }

    farm_device_count = 0;
}

void update_hardware_info(int mennyiseg,cudaDeviceProp *eszkozok_listaja,int RAM_mennyiseg, int render_uzemmod)
{
    FILE* fajl;
    int i;
    
    fajl = fopen("hardware_info.txt", "wt");
    if (fajl == NULL) return;

    fprintf_s(fajl, "******* RENDER MODE *******\n");
    if(render_uzemmod == 0) fprintf_s(fajl, "Render device: CPU\n");
    else if (render_uzemmod == 1) fprintf_s(fajl, "Render device: CUDA GPU\n");

    fprintf_s(fajl, "******* PC RAM *******\n");
    fprintf_s(fajl, "%i MB\n", RAM_mennyiseg);
    
    for (i = 0; i < mennyiseg; ++i)
    {
        fprintf_s(fajl, "******* %i. GPU and VRAM *******\n",i);
        fprintf_s(fajl, "%s - %i MB\n", eszkozok_listaja[i].name, eszkozok_listaja[i].totalGlobalMem / 1024/1024);
        
    }

    fclose(fajl);
}

void select_farm_item(HWND target_text1, HWND target_text2, HWND target_listbox, HWND target_start_degree, HWND target_end_degree, HWND target_infotext)
{
    char szoveg[256] = { "" }, szoveg2[1024] = { "" };
    int adathossz = 0;
    int sorszam = (int)SendMessage(target_listbox, LB_GETCURSEL, (WPARAM)0, (WPARAM)0);
    int hossz = (int)SendMessage(target_listbox, LB_GETTEXTLEN, (WPARAM)sorszam, (WPARAM)0);
    SendMessage(target_listbox, LB_GETTEXT, (WPARAM)sorszam, (WPARAM)szoveg);
    SetWindowTextA(target_text1, szoveg);
    sorszam = farm_search_pcname(target_text1);

    //*******hardver info betoltese***************
    strcpy_s(szoveg, "\\\\");
    strcat_s(szoveg, farm_device_list[sorszam].name);
    strcat_s(szoveg, "\\");
    strcat_s(szoveg, farm_device_list[sorszam].render_folder);
    strcat_s(szoveg, "\\hardware_info.txt");

    fopen_s(&fajl, szoveg, "rb");
    if (fajl == NULL) return;//hibakezel�s
    while (!feof(fajl))
    {
        fread_s(&szoveg2[adathossz++], 1024, 1, 1, fajl);
    }
    fclose(fajl);
    SetWindowText(target_infotext, szoveg2);
    //**********************

    SetWindowTextA(target_text2, (LPCSTR)farm_device_list[sorszam].render_folder);

    _itoa_s(farm_device_list[sorszam].start_degree,szoveg,10);
    SetWindowTextA(target_start_degree, (LPCSTR)szoveg);

    _itoa_s(farm_device_list[sorszam].end_degree, szoveg, 10);
    SetWindowTextA(target_end_degree, (LPCSTR)szoveg);
}

void farm_start_remote_render(HWND target_listbox, HWND target_text1, HWND target_infotext)
{
    FILE* fajl;
    char szoveg[256] = { "" }, szoveg2[1024] = { "" };
    int adathossz = 0,i;
    
    farm_finished_device_count = 0;

    for (i = 0; i < MAXFARMDEVCOUNT; ++i)
    {
        if (farm_device_list[i].torolve == 0)
        {
            farm_device_statuses[i] = -2;

            strcpy_s(szoveg, "\\\\");
            strcat_s(szoveg, farm_device_list[i].name);
            strcat_s(szoveg, "\\");
            strcat_s(szoveg, farm_device_list[i].render_folder);
            strcat_s(szoveg, "\\master_command.txt");

            fajl = _fsopen(szoveg, "wt", _SH_DENYNO);
            if (fajl == NULL) return;//hibakezel�s
            fprintf_s(fajl, "START\n%i\n%i\n%f\n%f\n%f\n%i\nNORMAL\n", farm_device_list[i].start_degree, farm_device_list[i].end_degree, rot_degree_x2, rot_degree_y2, rot_degree_z2, remote_zoom_direction);
            fclose(fajl);

            strcpy_s(szoveg, "\\\\");
            strcat_s(szoveg, farm_device_list[i].name);
            strcat_s(szoveg, "\\");
            strcat_s(szoveg, farm_device_list[i].render_folder);
            strcat_s(szoveg, "\\render_progress.txt");

            /*fajl = _fsopen(szoveg, "wt", _SH_DENYNO);B
            if (fajl != NULL) fprintf_s(fajl, "%i", adathossz);
            fclose(fajl);*/
        }
    }
}

//**** egpu mindig a 0. index� g�p lesz **************
void farm_start_egpu_render(void)
{
    FILE* fajl;
    char szoveg[256] = { "" };
    int placeholder=0;

    farm_finished_device_count = 0;
    farm_device_statuses[0] = -2;

    strcpy_s(szoveg, "\\\\");
    strcat_s(szoveg, farm_device_list[0].name);
    strcat_s(szoveg, "\\");
    strcat_s(szoveg, farm_device_list[0].render_folder);
    strcat_s(szoveg, "\\master_command.txt");
 
    fajl = _fsopen(szoveg, "wt", _SH_DENYNO);
    if (fajl == NULL) return;//hibakezel�s
    fprintf_s(fajl, "START\n%i\n%i\n%f\n%f\n%f\n%i\nEGPU\n", placeholder, placeholder+5, rot_degree_x2, rot_degree_y2, rot_degree_z2, remote_zoom_direction);
    fclose(fajl);
}

void farm_add(HWND source_text_pcname, HWND source_text_folder, HWND target_listbox)
{    
    char szoveg[256] = { "" };
    int i;
    for (i = 0; i < MAXFARMDEVCOUNT; ++i)
    {
        if (farm_device_list[i].torolve == 1)
        {
            farm_device_list[i].torolve = 0;
            GetWindowTextA(source_text_pcname, szoveg, GetWindowTextLengthA(source_text_pcname) + 1);
            SendMessageA(target_listbox, LB_ADDSTRING, 0, (LPARAM)szoveg);
            strcpy_s(farm_device_list[i].name, szoveg);
            GetWindowTextA(source_text_folder, szoveg, GetWindowTextLengthA(source_text_folder) + 1);
            strcpy_s(farm_device_list[i].render_folder, szoveg);
            return;
        }
    }
    
}

void farm_remove(HWND source_text_pcname)
{
    int sorszam = farm_search_pcname(source_text_pcname);
    farm_device_list[sorszam].torolve = 1;
    --farm_device_count;
}

int farm_search_pcname(HWND source_text_pcname)
{
    int i;
    char szoveg[256] = { "" };
    GetWindowTextA(source_text_pcname, szoveg, GetWindowTextLengthA(source_text_pcname) + 1);

    for (i = 0; i < MAXFARMDEVCOUNT; ++i)
    {
        if (farm_device_list[i].torolve == 0)
        {
            if (strcmp(szoveg, farm_device_list[i].name) == 0) return i;
        }        
    }

    return -1;
}

void farm_setup_SAVE(void)
{
    int i;
    FILE* fajl;
    fopen_s(&fajl, "farm_setup.cfg", "wb");
    if (fajl == NULL) return;//hibakezel�s

    fwrite(&farm_device_count, sizeof(farm_device_count), 1, fajl);

    for (i = 0; i < MAXFARMDEVCOUNT; ++i)
    {
        if (farm_device_list[i].torolve == 0)
        {
            fwrite(&farm_device_list[i].name, 12, 1, fajl);
            fwrite(&farm_device_list[i].render_folder, 256, 1, fajl);
            fwrite(&farm_device_list[i].info, 1024, 1, fajl);
            fwrite(&farm_device_list[i].start_degree, sizeof(int), 1, fajl);
            fwrite(&farm_device_list[i].end_degree, sizeof(int), 1, fajl);
        }        
        //fwrite(&farm_device_list[i].torolve, sizeof(char), 1, fajl);
    }
    
    fflush(fajl);
    fclose(fajl);
}
void farm_setup_LOAD(HWND target_listbox)
{
    int i;
    FILE* fajl;
    char szoveg[256] = { "" };
    
    SendMessageA(target_listbox, LB_RESETCONTENT, 0, 0);
    cleanup_farm_device_list();

    fopen_s(&fajl, "farm_setup.cfg", "rb");
    if (fajl == NULL) return;//hibakezel�s

    fread(&farm_device_count, sizeof(farm_device_count), 1, fajl);

    for (i = 0; i < farm_device_count; ++i)
    {                
        fread(&farm_device_list[i].name, 12, 1, fajl);
        fread(&farm_device_list[i].render_folder, 256, 1, fajl);
        fread(&farm_device_list[i].info, 1024, 1, fajl);
        fread(&farm_device_list[i].start_degree, sizeof(int), 1, fajl);
        fread(&farm_device_list[i].end_degree, sizeof(int), 1, fajl);
        farm_device_list[i].torolve = 0;
        SendMessageA(target_listbox, LB_ADDSTRING, 0, (LPARAM)farm_device_list[i].name);
    }

    fclose(fajl);
}

int get_farm_device_index(int frameindex)
{
    int i;
    for (i = 0; i < MAXFARMDEVCOUNT; ++i)
    {
        if (farm_device_list[i].torolve != 1)
        {
            if ((frameindex >= farm_device_list[i].start_degree) && (frameindex < farm_device_list[i].end_degree)) return i;
        }
    }
}