/******************************************************************************************************
Copyright(c) < 2024 > <copyright holder : Kriszti�n Dezs� Feh�r, Hungary>
Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files(the "Software"),
to deal in the Software without restriction, except the commercial usage, including without limitation the rights to use, copy, modify, merge, publish, distribute copies of the Software,
and to permit persons to whom the Software is furnished to do so, subject to the following conditions :

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
******************************************************************************************************/
#pragma once

int render_type = 2;//0-point, 1-line, 2-polygon
int render_mode = 1;//0-cpu,1-GPU
int xtreme_vram_onoff = 0;//0-off,1-on
int client_server_mode=0;//0-client, 1-server
int render_masterslave = 0;//0-master,1-slave (controller or render farm)
//0++panx
//1--panx
//2++pany
//3--pany
//4++zoom
//5--zoom
char muveletsor[1000000];
unsigned int muvelet_length=0;


//int render_type = 0;//0-point, 1-line, 2-polygon
float zoom_value = 1.0f;
int zoom_in_value = 0, zoom_out_value = 0;
float height_zoom_value = 1.0;
float panx = 0;
float pany = 0;
float lepkedes_teszt = 0.01;

//0++panx
//1--panx
//2++pany
//3--pany
//4++zoom
//5--zoom
//char muveletsor[1000000];
//unsigned int muvelet_length = 0;