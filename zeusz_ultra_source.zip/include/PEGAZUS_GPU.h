/******************************************************************************************************
Copyright(c) < 2024 > <copyright holder : Kriszti�n Dezs� Feh�r, Hungary>
Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files(the "Software"),
to deal in the Software without restriction, except the commercial usage, including without limitation the rights to use, copy, modify, merge, publish, distribute copies of the Software,
and to permit persons to whom the Software is furnished to do so, subject to the following conditions :

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
******************************************************************************************************/
#pragma once
#include "include\\glob_config.h"
#include "include\\naplozas.h"

//*****offscreen buffering*****
int CUDA_DEVICE_COUNT, CURRENT_GPU_INDEX;
int ACTIVE_DEVICE_COUNT=0,active_GPU_list[10];

unsigned int *dev_image_data[10], *dev_secondary_image_data[10], image_data[SCREEN_WIDTH * SCREEN_HEIGHT];
float *dev_zbuffer[10], *dev_secondary_zbuffer[10];//ez int is volt/lehet
typedef struct Vec3f {
	float x, y, z;
};

//**cpu render*********
long long start_render[129];
long long end_render[129];
int render_finished,thread_counter;
//***************

int drawing_in_progress = 0;
float persp_degree, current_zoom;
float rot_degree_x;
float rot_degree_y;
float rot_degree_z;
float rot_degree_x2 = 0;
float rot_degree_y2 = 90.0f;
float rot_degree_z2 = 0;

float degree_sinx;
float degree_cosx;
float degree_siny;
float degree_cosy;
float degree_sinz;
float degree_cosz;

int render_target = 0;//0-screen,1-file,2-remote,3-eGPU
float Math_PI = 3.14159265358979323846;
float *raw_verticesX, *raw_verticesY, *raw_verticesZ;
long long raw_vertices_length[10], prev_raw_vertices_length[10];

struct VEKTOR {
	float x;
	float y;
	float z;
};
VEKTOR vLight;

float *dev_raw_verticesX[10], * dev_raw_verticesY[10], * dev_raw_verticesZ[10];
UINT32 *dev_poly_szinek[10];
UINT32 *poly_szinek;
int poly_szinek_length[10], prev_poly_szinek_length[10];

char *dev_obj_tipuslista[10], *obj_tipuslista;
int objlista_length[10], prev_objlista_length[10];

float beolvpont_cacheX[20000], beolvpont_cacheY[20000], beolvpont_cacheZ[20000];
int beolvpont_cache_length;

void create_main_buffer(void);
void CUDA_cleanup_main_buffer(void);
__global__ void CUDA_CleanUp_Zbuffer(float* zpuffer);
void swap_main_buffer(void);
void init_3D(void);
void cleanup_matrices(void);
void data_transfer_to_GPU(int devnum);
__device__ void CUDA_SetPixel(int x1, int y1, int color, unsigned int* puffer);
__device__ void CUDA_SetPixel_Zbuffer(int x1, int y1, int z1, int color, unsigned int* puffer, float* zpuffer);
__device__ void CUDA_DrawLine(int x1, int y1, int x2, int y2, int color, unsigned int* puffer);
__device__ void CUDA_DrawLine_Zbuffer(int x1, int y1, int z1, int x2, int y2, int z2, int color, unsigned int* puffer, float* zpuffer);
__device__ void CUDA_DrawTriangle(int x1, int y1, int x2, int y2, int x3, int y3, int color, unsigned int* puffer);
__device__ void CUDA_DrawTriangle_Zbuffer(int x1, int y1, int z1, int x2, int y2, int z2, int x3, int y3, int z3, int color, unsigned int* puffer, float* zpuffer);
__device__ void CUDA_FillTriangle(int x1, int y1, int x2, int y2, int x3, int y3, int color, unsigned int* puffer);
__device__ void CUDA_FillTriangle_Zbuffer(int x1, int y1, int z1, int x2, int y2, int z2, int x3, int y3, int z3, int color, unsigned int* puffer, float* zpuffer);
__device__ void CUDA_FillTriangle_Zbuffer_Goraud(int x1, int y1, int z1, int color1, int x2, int y2, int z2, int color2, int x3, int y3, int z3, int color3, unsigned int* puffer, float* zpuffer);
__global__ void zoom_in(int maxitemcount, float* rawarrayX, float* rawarrayY, float* rawarrayZ);
__global__ void zoom_out(int maxitemcount, float* rawarrayX, float* rawarrayY, float* rawarrayZ);
void CUDA_stepx_plus(void);
void CUDA_stepx_minus(void);
__global__ void stepx_in(int maxitemcount, float* rawarrayX,float xvalue);
void CUDA_stepy_plus(void);
void CUDA_stepy_minus(void);
__global__ void stepy_in(int maxitemcount, float* rawarrayY, float xvalue);
void CUDA_stepz_plus(void);
void CUDA_stepz_minus(void);
__global__ void stepz_in(int maxitemcount, float* rawarrayY, float xvalue);
__global__ void CUDA_Merge_Zbuffers(float* main_zpuffer, float* secondary_zpuffer, unsigned int* main_kepadat, unsigned int* secondary_kepadat);
__global__ void CUDA_render_TURBO(int maxitemcount, float* rawarrayX, float* rawarrayY, float* rawarrayZ, float degree_cosx, float degree_sinx, float degree_cosy, float degree_siny, float degree_cosz, float degree_sinz, unsigned int* puffer, float* zpuffer, VEKTOR fenyvektor, UINT32* szinek, char* objlista);
__global__ void CUDA_render_TURBO_POINT(int maxitemcount, float* rawarrayX, float* rawarrayY, float* rawarrayZ, float degree_cosx, float degree_sinx, float degree_cosy, float degree_siny, float degree_cosz, float degree_sinz, unsigned int* puffer, float* zpuffer, VEKTOR fenyvektor, UINT32* szinek);
__global__ void CUDA_render_TURBO_single_point(float rawarrayX, float rawarrayY, float rawarrayZ, float degree_cosx, float degree_sinx, float degree_cosy, float degree_siny, float degree_cosz, float degree_sinz, unsigned int* puffer, float* zpuffer);


void CPU_render_TURBO_POINT(int maxitemcount, float* rawarrayX, float* rawarrayY, float* rawarrayZ, float degree_cosx, float degree_sinx, float degree_cosy, float degree_siny, float degree_cosz, float degree_sinz, unsigned int* puffer, float* zpuffer, VEKTOR fenyvektor, UINT32* szinek);
void CPU_render_TURBO(int startitemcount, int enditemcount, float* rawarrayX, float* rawarrayY, float* rawarrayZ, float degree_cosx, float degree_sinx, float degree_cosy, float degree_siny, float degree_cosz, float degree_sinz, unsigned int* puffer, float* zpuffer, VEKTOR fenyvektor, UINT32* szinek, char* objlista);
void CPU_render_TURBO_single_point(float rawarrayX, float rawarrayY, float rawarrayZ, float degree_cosx, float degree_sinx, float degree_cosy, float degree_siny, float degree_cosz, float degree_sinz, unsigned int* puffer, float* zpuffer);
void CPU_SetPixel(int x1, int y1, int color, unsigned int* puffer);
void CPU_SetPixel_Zbuffer(int x1, int y1, int z1, int color, unsigned int* puffer, float* zpuffer);
void CPU_DrawLine(int x1, int y1, int x2, int y2, int color, unsigned int* puffer);
void CPU_DrawLine_Zbuffer(int x1, int y1, int z1, int x2, int y2, int z2, int color, unsigned int* puffer, float* zpuffer);
void CPU_FillTriangle(int x1, int y1, int x2, int y2, int x3, int y3, int color, unsigned int* puffer);
void CPU_FillTriangle_Zbuffer(int x1, int y1, int z1, int x2, int y2, int z2, int x3, int y3, int z3, int color, unsigned int* puffer, float* zpuffer);
void CPU_FillTriangle_Zbuffer_Goraud(int x1, int y1, int z1, int color1, int x2, int y2, int z2, int color2, int x3, int y3, int z3, int color3, unsigned int* puffer, float* zpuffer);
void CPU_zoom_in(void);
void CPU_zoom_out(void);
void CPU_zoom_in2(int maxitemcount, float* rawarrayX, float* rawarrayY, float* rawarrayZ);
void CPU_stepx_plus(void);
void CPU_stepx_minus(void);
void CPU_stepx_in(int maxitemcount, float* rawarrayX, float xvalue);
void CPU_stepy_plus(void);
void CPU_stepy_minus(void);
void CPU_stepy_in(int maxitemcount, float* rawarrayY, float xvalue);
void CPU_stepz_plus(void);
void CPU_stepz_minus(void);
void CPU_stepz_in(int maxitemcount, float* rawarrayY, float xvalue);
void CPU_zoom_out2(int maxitemcount, float* rawarrayX, float* rawarrayY, float* rawarrayZ);

void create_main_buffer(void)
{
	pRT->CreateBitmap(D2D1::SizeU(SCREEN_WIDTH, SCREEN_HEIGHT),
		D2D1::BitmapProperties(D2D1::PixelFormat(DXGI_FORMAT_B8G8R8A8_UNORM,
			D2D1_ALPHA_MODE_IGNORE)), &memkeptarolo);
	memset(D2D_imagebuffer, 0, SCREEN_WIDTH * SCREEN_HEIGHT * sizeof(unsigned int));
}

void CUDA_cleanup_main_buffer(void)
{
	int i;
	for (i = 0; i < ACTIVE_DEVICE_COUNT; ++i)
	{
		cudaSetDevice(active_GPU_list[i]);
		cudaMemset(dev_image_data[active_GPU_list[i]], 255, SCREEN_HEIGHT * SCREEN_WIDTH * sizeof(unsigned int));
	}
}

__global__ void CUDA_CleanUp_Zbuffer(float* zpuffer)
{	
	int i;
	int index = (blockIdx.x * blockDim.x) + threadIdx.x;
	int stride = blockDim.x * gridDim.x;

	for (i = index; i < SCREEN_HEIGHT * SCREEN_WIDTH; i += stride)
	{
		zpuffer[i] = 999999;
	}
}

void swap_main_buffer(void)
{
	D2D1_RECT_U terulet;
	if (render_mode == 1)
	{
		cudaSetDevice(0);
		cudaMemcpy(D2D_imagebuffer, dev_image_data[active_GPU_list[0]], SCREEN_WIDTH * SCREEN_HEIGHT * sizeof(unsigned int), cudaMemcpyDeviceToHost);
		//cudaMemcpy(D2D_imagebuffer, dev_image_data[active_GPU_list[0]], SCREEN_WIDTH * SCREEN_HEIGHT, cudaMemcpyDeviceToHost);
	}	

	terulet.left = 0;
	terulet.top = 0;
	terulet.right = SCREEN_WIDTH - 1;
	terulet.bottom = SCREEN_HEIGHT - 1;
	memkeptarolo->CopyFromMemory(&terulet, D2D_imagebuffer, SCREEN_WIDTH * sizeof(unsigned int));
	pRT->BeginDraw();
	pRT->DrawBitmap(memkeptarolo, D2D1::RectF(0.0f, 0.0f, SCREEN_WIDTH, SCREEN_HEIGHT), 1.0f, D2D1_BITMAP_INTERPOLATION_MODE_NEAREST_NEIGHBOR, NULL);
	pRT->EndDraw();
}

void init_3D(void)
{	
	persp_degree = Math_PI / 180;
	rot_degree_x = 270 * Math_PI / 180; rot_degree_x2 = 270;
	rot_degree_y = 10 * Math_PI / 180; rot_degree_y2 = 10;
	rot_degree_z = 0 * Math_PI / 180; rot_degree_z2 = 0;
	//vLight.x = SCREEN_WIDTH / 3; vLight.y = -400000; vLight.z = 0;
	vLight.x = -0.5; vLight.y = -0.5; vLight.z = -0.9;
	cleanup_matrices();	
}

void cleanup_matrices(void)
{
	int i;
	for (i = 1; i < 10; ++i) raw_vertices_length[i] = poly_szinek_length[i] = objlista_length[i] = 0;
	for (i = 1; i < 10; ++i) prev_raw_vertices_length[i] = prev_poly_szinek_length[i] = prev_objlista_length[i] = 0;
}

void data_transfer_to_GPU(int devnum)
{
	char hibauzenet[256];
	int i;
	naplo("******************");
	vertex_counter = poly_counter * 3;

	cudaSetDevice(devnum);
	cudaMemcpy(dev_raw_verticesX[devnum] + prev_raw_vertices_length[devnum], raw_verticesX, raw_vertices_length[devnum] * sizeof(float), cudaMemcpyHostToDevice);
	cudaMemcpy(dev_raw_verticesY[devnum] + prev_raw_vertices_length[devnum], raw_verticesY, raw_vertices_length[devnum] * sizeof(float), cudaMemcpyHostToDevice);
	cudaMemcpy(dev_raw_verticesZ[devnum] + prev_raw_vertices_length[devnum], raw_verticesZ, raw_vertices_length[devnum] * sizeof(float), cudaMemcpyHostToDevice);
	cudaMemcpy(dev_poly_szinek[devnum] + prev_poly_szinek_length[devnum], poly_szinek, poly_szinek_length[devnum] * sizeof(UINT32), cudaMemcpyHostToDevice);
	cudaMemcpy(dev_obj_tipuslista[devnum] + prev_objlista_length[devnum], obj_tipuslista, objlista_length[devnum] * sizeof(char), cudaMemcpyHostToDevice);
	//prev_raw_vertices_length[devnum] = raw_vertices_length[devnum];	
	//raw_vertices_length[devnum] = prev_raw_vertices_length[devnum] + raw_vertices_length[devnum];
	/*poly_szinek_length[devnum] = prev_poly_szinek_length[devnum] + poly_szinek_length[devnum];
	prev_poly_szinek_length[devnum] = poly_szinek_length[devnum];*/

	prev_raw_vertices_length[devnum] = prev_raw_vertices_length[devnum] + raw_vertices_length[devnum];
	raw_vertices_length[devnum] = 0;	

	prev_poly_szinek_length[devnum] = prev_poly_szinek_length[devnum] + poly_szinek_length[devnum];
	poly_szinek_length[devnum] = 0;

	prev_objlista_length[devnum] = prev_objlista_length[devnum] + objlista_length[devnum];
	objlista_length[devnum] = 0;
}
//********************************
//PEGAZUS 3D
//********************************


__device__ void CUDA_SetPixel(int x1, int y1, int color, unsigned int* puffer)
{
	puffer[(y1 * SCREEN_WIDTH) + x1] = color;
}

__device__ void CUDA_SetPixel_Zbuffer(int x1, int y1, int z1, int color, unsigned int* puffer, float* zpuffer)
{
	int offset = (y1 * SCREEN_WIDTH) + x1;
	if (zpuffer[offset] > z1)
	{
		zpuffer[offset] = z1;
		puffer[offset] = color;
	}
}

__device__ void CUDA_DrawLine(int x1, int y1, int x2, int y2, int color, unsigned int* puffer)
{
	int dx = abs(x2 - x1);
	int dy = abs(y2 - y1);
	int sx = (x1 < x2) ? 1 : -1;
	int sy = (y1 < y2) ? 1 : -1;
	int err = dx - dy;

	while (1) {
		puffer[(y1 * SCREEN_WIDTH) + x1] = color;
		if (x1 == x2 && y1 == y2) break;
		int e2 = err * 2;
		if (e2 > -dy) {
			err -= dy;
			x1 += sx;
		}
		if (e2 < dx) {
			err += dx;
			y1 += sy;
		}
	}
}

__device__ void CUDA_DrawLine_Zbuffer(int x1, int y1, int z1, int x2, int y2, int z2, int color, unsigned int* puffer, float* zpuffer)
{

	int dx = abs(x2 - x1);
	int dy = abs(y2 - y1);
	int sx = (x1 < x2) ? 1 : -1;
	int sy = (y1 < y2) ? 1 : -1;
	int err = dx - dy,e2;
	float dz = z2 - z1;
	float z = z1;
	int offset;

	if (abs(x2 - x1) < 2 && abs(y2 - y1) < 2) {
		puffer[(y2 * SCREEN_WIDTH) + x2] = color; return;
	}

	while (1) {
		// Friss�tj�k a Z-buffer �rt�k�t
		offset = (y1 * SCREEN_WIDTH) + x1;
		if (zpuffer[offset] > z)
		{
			zpuffer[offset] = z;
			puffer[offset] = color;
		}

		// Ellen�rizz�k, hogy el�rt�k-e a vonal v�g�t
		if (x1 == x2 && y1 == y2) break;
		
		e2 = err * 2;
		if (e2 > -dy) {
			err -= dy;
			x1 += sx;
		}
		if (e2 < dx) {
			err += dx;
			y1 += sy;
		}
		z += dz / (dx > dy ? dx : dy); // Friss�tj�k a Z-�rt�ket
	}
}

__device__ void CUDA_DrawTriangle(int x1, int y1, int x2, int y2, int x3, int y3, int color, unsigned int* puffer)
{
	// Vonal rajzol�sa (x1, y1) - (x2, y2)
	int dx = abs(x2 - x1);
	int dy = abs(y2 - y1);
	int sx = (x1 < x2) ? 1 : -1;
	int sy = (y1 < y2) ? 1 : -1;
	int err = dx - dy;
	int e2;

	while (1) {
		puffer[(y1 * SCREEN_WIDTH) + x1] = color;

		if (x1 == x2 && y1 == y2) break;
		e2 = 2 * err;
		if (e2 > -dy) {
			err -= dy;
			x1 += sx;
		}
		if (e2 < dx) {
			err += dx;
			y1 += sy;
		}
	}

	// Vonal rajzol�sa (x2, y2) - (x3, y3)
	dx = abs(x3 - x2);
	dy = abs(y3 - y2);
	sx = (x2 < x3) ? 1 : -1;
	sy = (y2 < y3) ? 1 : -1;
	err = dx - dy;

	while (1) {
		puffer[(y2 * SCREEN_WIDTH) + x2] = color;
		if (x2 == x3 && y2 == y3) break;
		e2 = 2 * err;
		if (e2 > -dy) {
			err -= dy;
			x2 += sx;
		}
		if (e2 < dx) {
			err += dx;
			y2 += sy;
		}
	}

	// Vonal rajzol�sa (x3, y3) - (x1, y1)
	dx = abs(x1 - x3);
	dy = abs(y1 - y3);
	sx = (x3 < x1) ? 1 : -1;
	sy = (y3 < y1) ? 1 : -1;
	err = dx - dy;

	while (1) {
		puffer[(y3 * SCREEN_WIDTH) + x3] = color;
		if (x3 == x1 && y3 == y1) break;
		e2 = 2 * err;
		if (e2 > -dy) {
			err -= dy;
			x3 += sx;
		}
		if (e2 < dx) {
			err += dx;
			y3 += sy;
		}
	}
}

__device__ void CUDA_DrawTriangle_Zbuffer(int x1, int y1, int z1, int x2, int y2, int z2, int x3, int y3, int z3, int color, unsigned int* puffer, float* zpuffer)
{
	int offset;
	// Az �lek rajzol�sa �s Z-buffer friss�t�se
	for (int i = 0; i < 3; i++) {
		int x_start, y_start, x_end, y_end;
		float z_start, z_end;

		if (i == 0) {
			x_start = x1; y_start = y1; x_end = x2; y_end = y2;
			z_start = z1; z_end = z2;
		}
		else if (i == 1) {
			x_start = x2; y_start = y2; x_end = x3; y_end = y3;
			z_start = z2; z_end = z3;
		}
		else {
			x_start = x3; y_start = y3; x_end = x1; y_end = y1;
			z_start = z3; z_end = z1;
		}

		int dx = abs(x_end - x_start);
		int dy = abs(y_end - y_start);
		int sx = (x_start < x_end) ? 1 : -1;
		int sy = (y_start < y_end) ? 1 : -1;
		int err = dx - dy;
		float dz = z_end - z_start;
		float z = z_start;

		while (1) {

			offset = (y_start * SCREEN_WIDTH) + x_start;
			if (zpuffer[offset] > z)
			{
				zpuffer[offset] = z;
				puffer[offset] = color;
			}

			if (x_start == x_end && y_start == y_end) break;
			int e2 = 2 * err;
			if (e2 > -dy) {
				err -= dy;
				x_start += sx;
			}
			if (e2 < dx) {
				err += dx;
				y_start += sy;
			}
			z += dz / (dx > dy ? dx : dy); // Z-�rt�k friss�t�se
		}
	}
}

__device__ void CUDA_FillTriangle(int x1, int y1, int x2, int y2, int x3, int y3, int color, unsigned int* puffer)
{
	if (y1 == y2 && y1 == y3) return;
	// Compute bounding box
	int minX = x1 < x2 ? (x1 < x3 ? x1 : x3) : (x2 < x3 ? x2 : x3);
	int maxX = x1 > x2 ? (x1 > x3 ? x1 : x3) : (x2 > x3 ? x2 : x3);
	int minY = y1 < y2 ? (y1 < y3 ? y1 : y3) : (y2 < y3 ? y2 : y3);
	int maxY = y1 > y2 ? (y1 > y3 ? y1 : y3) : (y2 > y3 ? y2 : y3);

	// Calculate edge functions
	int s1 = x2 - x1, s2 = x3 - x2, s3 = x1 - x3, s4 = y2 - y1, s5 = y3 - y2, s6 = y1 - y3;
	int edge1 = s1 * (y1 - minY) - (x1 - minX) * s4;
	int edge2 = s2 * (y2 - minY) - (x2 - minX) * s5;
	int edge3 = s3 * (y3 - minY) - (x3 - minX) * s6;
	int y, x, c1, c2, c3;

	// Loop through bounding box
	for (y = minY; y <= maxY; y++) {
		for (x = minX; x <= maxX; x++) {
			c1 = s1 * (y - y1) - (x - x1) * s4;
			c2 = s2 * (y - y2) - (x - x2) * s5;
			c3 = s3 * (y - y3) - (x - x3) * s6;

			if ((c1 >= 0 && c2 >= 0 && c3 >= 0) || (c1 <= 0 && c2 <= 0 && c3 <= 0)) {
				puffer[(y * SCREEN_WIDTH) + x] = color;
			}
		}
	}
}

__device__ void CUDA_FillTriangle_Zbuffer(int x1, int y1, int z1, int x2, int y2, int z2, int x3, int y3, int z3, int color, unsigned int* puffer, float* zpuffer)
{
	if (y1 == y2 && y1 == y3) return;
	int temp;

	// �lek rendez�se magass�g szerint
	if (y2 < y1) {
		temp = x1; x1 = x2; x2 = temp;
		temp = y1; y1 = y2; y2 = temp;
		temp = z1; z1 = z2; z2 = temp;
	}
	if (y3 < y1) {
		temp = x1; x1 = x3; x3 = temp;
		temp = y1; y1 = y3; y3 = temp;
		temp = z1; z1 = z3; z3 = temp;
	}
	if (y3 < y2) {
		temp = x2; x2 = x3; x3 = temp;
		temp = y2; y2 = y3; y3 = temp;
		temp = z2; z2 = z3; z3 = temp;
	}

	int totalHeight = y3 - y1;
	int i, j, ax, bx,az,bz,y,phi,z,offset, secondHalf, segmentHeight;

	for (i = 0; i < totalHeight; i++) {
		secondHalf = i > y2 - y1 || y2 == y1;
		segmentHeight = secondHalf ? (y3 - y2) : (y2 - y1);

		ax = x1 + (x3 - x1) * i / totalHeight;
		az = z1 + (z3 - z1) * i / totalHeight;

		bx = secondHalf ? (x2 + (x3 - x2) * (i - (y2 - y1)) / segmentHeight)
			: (x1 + (x2 - x1) * i / segmentHeight);
		bz = secondHalf ? (z2 + (z3 - z2) * (i - (y2 - y1)) / segmentHeight)
			: (z1 + (z2 - z1) * i / segmentHeight);

		if (ax > bx) {
			temp = ax; ax = bx; bx = temp;
			temp = az; az = bz; bz = temp;
		}

		y = y1 + i;
		for (j = ax; j <= bx; j++) {
			phi = bx == ax ? 0 : (j - ax) * 1000 / (bx - ax); // Fixpontos aritmetika helyett egyszer� sk�l�z�s
			 z = az + (bz - az) * phi / 1000;

			offset = (y * SCREEN_WIDTH) + j;
			if (zpuffer[offset] > z)
			{
				zpuffer[offset] = z;
				puffer[offset] = color;
			}
		}
	}
}

__device__ void CUDA_FillTriangle_Zbuffer_Goraud(int x1, int y1, int z1, int color1, int x2, int y2, int z2, int color2, int x3, int y3, int z3, int color3, unsigned int* puffer, float* zpuffer)
{
	if (y1 == y2 && y1 == y3) return;
	int temp;

	// �lek rendez�se magass�g szerint
	if (y2 < y1) {
		temp = x1; x1 = x2; x2 = temp;
		temp = y1; y1 = y2; y2 = temp;
		temp = z1; z1 = z2; z2 = temp;
		temp = color1; color1 = color2; color2 = temp;
	}
	if (y3 < y1) {
		temp = x1; x1 = x3; x3 = temp;
		temp = y1; y1 = y3; y3 = temp;
		temp = z1; z1 = z3; z3 = temp;
		temp = color1; color1 = color3; color3 = temp;
	}
	if (y3 < y2) {
		temp = x2; x2 = x3; x3 = temp;
		temp = y2; y2 = y3; y3 = temp;
		temp = z2; z2 = z3; z3 = temp;
		temp = color2; color2 = color3; color3 = temp;
	}

	int totalHeight = y3 - y1;
	int i, j, ax, bx, az, bz, y, phi, z, offset, secondHalf, segmentHeight;
	float r, g, b;
	float r1, g1, b1, r2, g2, b2, r3, g3, b3;

	// Cs�csok sz�n�nek komponensei (RGB)
	r1 = (color1 >> 16) & 0xFF;
	g1 = (color1 >> 8) & 0xFF;
	b1 = color1 & 0xFF;
	r2 = (color2 >> 16) & 0xFF;
	g2 = (color2 >> 8) & 0xFF;
	b2 = color2 & 0xFF;
	r3 = (color3 >> 16) & 0xFF;
	g3 = (color3 >> 8) & 0xFF;
	b3 = color3 & 0xFF;

	for (i = 0; i < totalHeight; i++) {
		secondHalf = i > y2 - y1 || y2 == y1;
		segmentHeight = secondHalf ? (y3 - y2) : (y2 - y1);

		ax = x1 + (x3 - x1) * i / totalHeight;
		az = z1 + (z3 - z1) * i / totalHeight;

		bx = secondHalf ? (x2 + (x3 - x2) * (i - (y2 - y1)) / segmentHeight)
			: (x1 + (x2 - x1) * i / segmentHeight);
		bz = secondHalf ? (z2 + (z3 - z2) * (i - (y2 - y1)) / segmentHeight)
			: (z1 + (z2 - z1) * i / segmentHeight);

		if (ax > bx) {
			temp = ax; ax = bx; bx = temp;
			temp = az; az = bz; bz = temp;
		}

		y = y1 + i;
		for (j = ax; j <= bx; j++) {
			phi = bx == ax ? 0 : (j - ax) * 1000 / (bx - ax); // Fixpontos aritmetika helyett egyszer� sk�l�z�s
			z = az + (bz - az) * phi / 1000;

			float r0 = r1 + (r3 - r1) * (i / (float)totalHeight);
			float g0 = g1 + (g3 - g1) * (i / (float)totalHeight);
			float b0 = b1 + (b3 - b1) * (i / (float)totalHeight);

			float r1r = r0 + (r2 - r0) * ((j - ax) / (float)(bx - ax));
			float g1r = g0 + (g2 - g0) * ((j - ax) / (float)(bx - ax));
			float b1r = b0 + (b2 - b0) * ((j - ax) / (float)(bx - ax));

			int finalColor = ((int)r1r << 16) | ((int)g1r << 8) | (int)b1r;

			offset = (y * SCREEN_WIDTH) + j;
			if (zpuffer[offset] > z) {
				zpuffer[offset] = z;
				puffer[offset] = finalColor;
			}
		}
	}
}

__global__ void zoom_in(int maxitemcount, float* rawarrayX, float* rawarrayY, float* rawarrayZ)
{
	int i;
	int index = (blockIdx.x * blockDim.x) + (threadIdx.x * 1);
	int stride = blockDim.x * gridDim.x;
	for (i = index; i < maxitemcount; i += stride)
	{
		rawarrayX[i] *= 1.1f;
		rawarrayY[i] *= 1.1f;
		rawarrayZ[i] *= 1.1f;
	}
}

void CUDA_stepx_plus(void)
{	
	int blockSize = BLOCKSIZE, i;
	int numBlocks;
	muveletsor[muvelet_length++] = 0;

	for (i = 0; i < ACTIVE_DEVICE_COUNT; ++i)
	{
		numBlocks = (prev_raw_vertices_length[active_GPU_list[i]] + blockSize - 1) / blockSize;
		cudaSetDevice(active_GPU_list[i]);
		stepx_in << <numBlocks, blockSize >> > (prev_raw_vertices_length[active_GPU_list[i]], dev_raw_verticesX[active_GPU_list[i]],50.0);
	}
	cudaDeviceSynchronize();
}

void CUDA_stepx_minus(void)
{
	int blockSize = BLOCKSIZE, i;
	int numBlocks;
	muveletsor[muvelet_length++] = 1;
	for (i = 0; i < ACTIVE_DEVICE_COUNT; ++i)
	{
		numBlocks = (prev_raw_vertices_length[active_GPU_list[i]] + blockSize - 1) / blockSize;
		cudaSetDevice(active_GPU_list[i]);
		stepx_in << <numBlocks, blockSize >> > (prev_raw_vertices_length[active_GPU_list[i]], dev_raw_verticesX[active_GPU_list[i]], -50.0);
	}
	cudaDeviceSynchronize();
}

__global__ void stepx_in(int maxitemcount, float* rawarrayX, float xvalue)
{
	int i;
	int index = (blockIdx.x * blockDim.x) + (threadIdx.x * 1);
	int stride = blockDim.x * gridDim.x;
	for (i = index; i < maxitemcount; i += stride) rawarrayX[i] += xvalue;
}

void CUDA_stepy_plus(void)
{
	int blockSize = BLOCKSIZE, i;
	int numBlocks;
	
	for (i = 0; i < ACTIVE_DEVICE_COUNT; ++i)
	{
		numBlocks = (prev_raw_vertices_length[active_GPU_list[i]] + blockSize - 1) / blockSize;
		cudaSetDevice(active_GPU_list[i]);
		stepy_in << <numBlocks, blockSize >> > (prev_raw_vertices_length[active_GPU_list[i]], dev_raw_verticesY[active_GPU_list[i]], 50.0);
	}
	cudaDeviceSynchronize();
}

void CUDA_stepy_minus(void)
{
	int blockSize = BLOCKSIZE, i;
	int numBlocks;
	
	for (i = 0; i < ACTIVE_DEVICE_COUNT; ++i)
	{
		numBlocks = (prev_raw_vertices_length[active_GPU_list[i]] + blockSize - 1) / blockSize;
		cudaSetDevice(active_GPU_list[i]);
		stepy_in << <numBlocks, blockSize >> > (prev_raw_vertices_length[active_GPU_list[i]], dev_raw_verticesY[active_GPU_list[i]], -50.0);
	}
	cudaDeviceSynchronize();
}

__global__ void stepy_in(int maxitemcount, float* rawarrayY, float xvalue)
{
	int i;
	int index = (blockIdx.x * blockDim.x) + (threadIdx.x * 1);
	int stride = blockDim.x * gridDim.x;
	for (i = index; i < maxitemcount; i += stride) rawarrayY[i] += xvalue;
}

void CUDA_stepz_plus(void)
{
	int blockSize = BLOCKSIZE, i;
	int numBlocks;
	muveletsor[muvelet_length++] = 2;
	for (i = 0; i < ACTIVE_DEVICE_COUNT; ++i)
	{
		numBlocks = (prev_raw_vertices_length[active_GPU_list[i]] + blockSize - 1) / blockSize;
		cudaSetDevice(active_GPU_list[i]);
		stepz_in << <numBlocks, blockSize >> > (prev_raw_vertices_length[active_GPU_list[i]], dev_raw_verticesZ[active_GPU_list[i]], 50.0);
	}
	cudaDeviceSynchronize();
}

void CUDA_stepz_minus(void)
{
	int blockSize = BLOCKSIZE, i;
	int numBlocks;
	muveletsor[muvelet_length++] = 3;
	for (i = 0; i < ACTIVE_DEVICE_COUNT; ++i)
	{
		numBlocks = (prev_raw_vertices_length[active_GPU_list[i]] + blockSize - 1) / blockSize;
		cudaSetDevice(active_GPU_list[i]);
		stepz_in << <numBlocks, blockSize >> > (prev_raw_vertices_length[active_GPU_list[i]], dev_raw_verticesZ[active_GPU_list[i]], -50.0);
	}
	cudaDeviceSynchronize();
}

__global__ void stepz_in(int maxitemcount, float* rawarrayY, float xvalue)
{
	int i;
	int index = (blockIdx.x * blockDim.x) + (threadIdx.x * 1);
	int stride = blockDim.x * gridDim.x;
	for (i = index; i < maxitemcount; i += stride) rawarrayY[i] += xvalue;
}

__global__ void zoom_out(int maxitemcount, float* rawarrayX, float* rawarrayY, float* rawarrayZ)
{
	int i;
	int index = (blockIdx.x * blockDim.x) + (threadIdx.x * 1);
	int stride = blockDim.x * gridDim.x;
	for (i = index; i < maxitemcount; i += stride)
	{
		rawarrayX[i] /= 1.1;
		rawarrayY[i] /= 1.1;
		rawarrayZ[i] /= 1.1;
	}
}

__global__ void CUDA_Merge_Zbuffers(float* main_zpuffer, float* secondary_zpuffer, unsigned int *main_kepadat, unsigned int* secondary_kepadat)
{
	int i;
	int index = (blockIdx.x * blockDim.x) + threadIdx.x;
	int stride = blockDim.x * gridDim.x;

	for (i = index; i < SCREEN_HEIGHT * SCREEN_WIDTH; i += stride)
	{
		if (main_zpuffer[i] > secondary_zpuffer[i])
		{
			main_kepadat[i] = secondary_kepadat[i];
		}
	}
}

__global__ void CUDA_render_TURBO(int maxitemcount, float* rawarrayX, float* rawarrayY, float* rawarrayZ, float degree_cosx, float degree_sinx, float degree_cosy, float degree_siny, float degree_cosz, float degree_sinz, unsigned int* puffer, float* zpuffer, VEKTOR fenyvektor, UINT32* szinek, char *objlista)
{
	long long i,reteg_index,reteg_start_index,reteg_stop_index,seged_index,j;
	int index = (blockIdx.x * blockDim.x) + (threadIdx.x * 3);
	int stride = blockDim.x * gridDim.x;
	float t0, t1 = SCREEN_WIDTH / 4.0, t2 = SCREEN_HEIGHT / 6.0;
	float rvX[3], rvY[3], rvZ[3];

	//perspective projection
	int s1;
	int viewpoint = -3000;
	int x_pontositas = 600;
	float sx = SCREEN_WIDTH / 2;
	float sultra = SCREEN_HEIGHT / 2, sultra2 = SCREEN_HEIGHT / 3;
	int x_minusz_edge = 0, y_minusz_edge = 0, x_max_edge = SCREEN_WIDTH - 1, y_max_edge = SCREEN_HEIGHT - 1;
	float distance;

	//****rendering
	int px, py, tesztcolor;
	float Light_intensity, Vector_length;
	VEKTOR Vector1, Vector2, vNormal, vNormalized;//for visibility check

	//rotation
	for (i = index; i < maxitemcount-2; i += stride)
	{
		rvY[0] = (rawarrayY[i] * degree_cosx) - (rawarrayZ[i] * degree_sinx);
		rvZ[0] = rawarrayY[i] * degree_sinx + rawarrayZ[i] * degree_cosx;

		rvX[0] = rawarrayX[i] * degree_cosy + rvZ[0] * degree_siny;
		rvZ[0] = -rawarrayX[i] * degree_siny + rvZ[0] * degree_cosy;// +

		t0 = rvX[0];
		rvX[0] = t0 * degree_cosz - rvY[0] * degree_sinz + t1;
		rvY[0] = t0 * degree_sinz + rvY[0] * degree_cosz + t2;

		
		rvY[1] = (rawarrayY[i+1] * degree_cosx) - (rawarrayZ[i+1] * degree_sinx);
		rvZ[1] = rawarrayY[i+1] * degree_sinx + rawarrayZ[i+1] * degree_cosx;

		rvX[1] = rawarrayX[i+1] * degree_cosy + rvZ[1] * degree_siny;
		rvZ[1] = -rawarrayX[i+1] * degree_siny + rvZ[1] * degree_cosy;// +

		t0 = rvX[1];
		rvX[1] = t0 * degree_cosz - rvY[1] * degree_sinz + t1;
		rvY[1] = t0 * degree_sinz + rvY[1] * degree_cosz + t2;


		rvY[2] = (rawarrayY[i+2] * degree_cosx) - (rawarrayZ[i+2] * degree_sinx);
		rvZ[2] = rawarrayY[i+2] * degree_sinx + rawarrayZ[i+2] * degree_cosx;

		rvX[2] = rawarrayX[i+2] * degree_cosy + rvZ[2] * degree_siny;
		rvZ[2] = -rawarrayX[i+2] * degree_siny + rvZ[2] * degree_cosy;// +

		t0 = rvX[2];
		rvX[2] = t0 * degree_cosz - rvY[2] * degree_sinz + t1;
		rvY[2] = t0 * degree_sinz + rvY[2] * degree_cosz + t2;

		//****perspective projection

		distance = 999999;

		//**1. vertex
		if (rvZ[0] < distance) distance = rvZ[0];
		if (distance < viewpoint) { rvZ[0] = -9999999; continue;}
		else
		{
			sultra = viewpoint / (viewpoint - rvZ[0]);
			rvX[0] = rvX[0] * sultra + x_pontositas;
			rvY[0] = (rvY[0] * sultra) + sultra2;
			if (rvX[0] < x_minusz_edge || rvX[0] > x_max_edge) { rvZ[0] = -9999999; continue;}
			else if (rvY[0] < y_minusz_edge || rvY[0] > y_max_edge) { rvZ[0] = -9999999; continue; }
			else
			{//***2. vertex
				if (rvZ[1] < distance) distance = rvZ[1];
				if (distance < viewpoint) { rvZ[1] = -9999999; continue;}
				else
				{
					sultra = viewpoint / (viewpoint - rvZ[1]);
					rvX[1] = rvX[1] * sultra + x_pontositas;
					rvY[1] = (rvY[1] * sultra) + sultra2;
					if (rvX[1] < x_minusz_edge || rvX[1] > x_max_edge) { rvZ[1] = -9999999; continue;}
					else if (rvY[1] < y_minusz_edge || rvY[1] > y_max_edge) { rvZ[1] = -9999999; continue;}
					else
					{//**3. vertex
						if (rvZ[2] < distance) distance = rvZ[2];
						if (distance < viewpoint) { rvZ[2] = -9999999; continue;}
						else
						{
							sultra = viewpoint / (viewpoint - rvZ[2]);
							rvX[2] = rvX[2] * sultra + x_pontositas;
							rvY[2] = (rvY[2] * sultra) + sultra2;
							if (rvX[2] < x_minusz_edge || rvX[2] > x_max_edge) { rvZ[2] = -9999999; continue;}
							else if (rvY[2] < y_minusz_edge || rvY[2] > y_max_edge) { rvZ[2] = -9999999; continue;}
						}
					}
				}
			}
		}

		//if (rvY[0] > 500 || rvY[1] > 500 || rvY[2] > 500) continue;

		//***rendering
		//if ((rvZ[0] < -9000000) || (rvZ[1] < -9000000) || (rvZ[2] < -9000000)) continue;

		// for visibility check
		Vector1.x = rvX[1] - rvX[0];
		Vector1.y = rvY[1] - rvY[0];
		Vector1.z = rvZ[1] - rvZ[0];
		Vector2.x = rvX[2] - rvX[0];
		Vector2.y = rvY[2] - rvY[0];
		Vector2.z = rvZ[2] - rvZ[0];

		vNormal.x = ((Vector1.y * Vector2.z) - (Vector1.z * Vector2.y));
		vNormal.y = ((Vector1.z * Vector2.x) - (Vector1.x * Vector2.z));
		vNormal.z = ((Vector1.x * Vector2.y) - (Vector1.y * Vector2.x));

		//if (vNormal.z < 0) continue;//l�thatatlan oldalak elt�vol�t�sa
		
		seged_index = i / 3;

		if (objlista[seged_index] == 0)//domborzat
		{
			Vector_length = sqrtf((vNormal.x * vNormal.x) + (vNormal.y * vNormal.y) + (vNormal.z * vNormal.z));
			vNormalized.x = vNormal.x / Vector_length;
			vNormalized.y = vNormal.y / Vector_length;
			vNormalized.z = vNormal.z / Vector_length;
			Light_intensity = ((vNormalized.x * fenyvektor.x) + (vNormalized.y * fenyvektor.y) + (vNormalized.z * fenyvektor.z));
			if (Light_intensity > 1) Light_intensity = 1;
			else if (Light_intensity < 0) Light_intensity = 0;

			float szazalek, magassag = (float)szinek[seged_index];
			if (magassag <= 0)
			{
				tesztcolor = RGB(200 * Light_intensity, 50 * Light_intensity, 50 * Light_intensity);
			}
			else if (magassag <= 250)
			{
				szazalek = magassag / (float)250;
				tesztcolor = RGB((2 * (1.0 - szazalek) + 113 * szazalek) * Light_intensity, (142 * (1.0 - szazalek) + 236 * szazalek) * Light_intensity, (16 * (1.0 - szazalek) + 119 * szazalek) * Light_intensity);
			}
			else if (magassag > 250 && magassag <= 1500)
			{
				szazalek = (magassag - 250) / (float)1250; //200;
				tesztcolor = RGB((165 * (1.0 - szazalek) + 13 * szazalek) * Light_intensity, (224 * (1.0 - szazalek) + 165 * szazalek) * Light_intensity, (250 * (1.0 - szazalek) + 230 * szazalek) * Light_intensity);
			}
			else if (magassag > 9000)
			{
				szazalek = (magassag - 9000) / (float)7500; //200;
				tesztcolor = RGB((13 * (1.0 - szazalek) + 255 * szazalek) * Light_intensity, (165 * (1.0 - szazalek) + 255 * szazalek) * Light_intensity, (230 * (1.0 - szazalek) + 255 * szazalek) * Light_intensity);
			}
			else
			{
				tesztcolor = RGB(255 * Light_intensity, 255 * Light_intensity, 255 * Light_intensity);
			}
			CUDA_FillTriangle_Zbuffer(rvX[0], rvY[0], rvZ[0], rvX[1], rvY[1], rvZ[1], rvX[2], rvY[2], rvZ[2], tesztcolor, puffer, zpuffer);
			//CUDA_FillTriangle(rvX[0], rvY[0], rvX[1], rvY[1], rvX[2], rvY[2], tesztcolor, puffer);
			//CUDA_DrawTriangle_Zbuffer(rvX[0], rvY[0], rvZ[0], rvX[1], rvY[1], rvZ[1], rvX[2], rvY[2], rvZ[2], tesztcolor, puffer, zpuffer);
			//CUDA_DrawTriangle(rvX[0], rvY[0], rvX[1], rvY[1], rvX[2], rvY[2], tesztcolor, puffer);
			//CUDA_DrawLine_Zbuffer(rvX[0], rvY[0], rvZ[0], rvX[1], rvY[1], rvZ[1], tesztcolor, puffer, zpuffer);
			continue;
		}
		else if (objlista[seged_index] == 21)//primary road
		{
			tesztcolor = szinek[seged_index];
			CUDA_DrawLine_Zbuffer(rvX[0], rvY[0], rvZ[0], rvX[1], rvY[1], rvZ[1], tesztcolor, puffer, zpuffer);
			//CUDA_DrawLine(rvX[0], rvY[0], rvX[1], rvY[1], tesztcolor, puffer);
			continue;
		}
		else if (objlista[seged_index] == 22)//motorway
		{
			tesztcolor = szinek[seged_index];
			CUDA_DrawLine_Zbuffer(rvX[0], rvY[0], rvZ[0], rvX[1], rvY[1], rvZ[1], tesztcolor, puffer, zpuffer);
			//CUDA_DrawLine(rvX[0], rvY[0], rvX[1], rvY[1], tesztcolor, puffer);
			continue;
		}
		else if (objlista[seged_index] == 2)//road
		{
			tesztcolor = RGB(0, 0, 0);
			CUDA_DrawLine_Zbuffer(rvX[0], rvY[0], rvZ[0], rvX[1], rvY[1], rvZ[1], tesztcolor, puffer, zpuffer);
			//CUDA_DrawLine(rvX[0], rvY[0], rvX[1], rvY[1], tesztcolor, puffer);
			continue;
		}
		else if (objlista[seged_index] == 3)//railway
		{
			tesztcolor = RGB(0, 0, 250);
			CUDA_DrawLine_Zbuffer(rvX[0], rvY[0], rvZ[0], rvX[1], rvY[1], rvZ[1], tesztcolor, puffer, zpuffer);
			//CUDA_DrawLine(rvX[0], rvY[0], rvX[1], rvY[1], tesztcolor, puffer);
			continue;
		}
		else if (objlista[seged_index] == 30)//park
		{
			tesztcolor = szinek[seged_index];
			//CUDA_FillTriangle_Zbuffer(rvX[0], rvY[0], rvZ[0], rvX[1], rvY[1], rvZ[1], rvX[2], rvY[2], rvZ[2], tesztcolor, puffer, zpuffer);
			CUDA_DrawLine_Zbuffer(rvX[0], rvY[0], rvZ[0], rvX[1], rvY[1], rvZ[1], tesztcolor, puffer, zpuffer);
			//CUDA_DrawLine(rvX[0], rvY[0], rvX[1], rvY[1], tesztcolor, puffer);
			//CUDA_SetPixel(rvX[0], rvY[0], tesztcolor, puffer);
			//CUDA_SetPixel(rvX[1], rvY[1], tesztcolor, puffer);
			//CUDA_SetPixel(rvX[2], rvY[2], tesztcolor, puffer);
			continue;
		}
		else if (objlista[seged_index] == 32)//stream
		{
			tesztcolor = szinek[seged_index];
			CUDA_DrawLine_Zbuffer(rvX[0], rvY[0], rvZ[0], rvX[1], rvY[1], rvZ[1], tesztcolor, puffer, zpuffer);
			//CUDA_DrawLine(rvX[0], rvY[0], rvX[1], rvY[1], tesztcolor, puffer);
			continue;
		}
		else if (objlista[seged_index] == 33)//river
		{
			tesztcolor = szinek[seged_index];
			CUDA_DrawLine_Zbuffer(rvX[0], rvY[0], rvZ[0], rvX[1], rvY[1], rvZ[1], tesztcolor, puffer, zpuffer);
			//CUDA_DrawLine(rvX[0], rvY[0], rvX[1], rvY[1], tesztcolor, puffer);
			continue;
		}
		else if (objlista[seged_index] == 34)//river
		{
			tesztcolor = szinek[seged_index];
			CUDA_DrawLine_Zbuffer(rvX[0], rvY[0], rvZ[0], rvX[1], rvY[1], rvZ[1], tesztcolor, puffer, zpuffer);
			//CUDA_DrawLine(rvX[0], rvY[0], rvX[1], rvY[1], tesztcolor, puffer);
			continue;
		}
		else if (objlista[seged_index] == 4)//water
		{
			tesztcolor = szinek[seged_index];
			//CUDA_FillTriangle_Zbuffer(rvX[0], rvY[0], rvZ[0], rvX[1], rvY[1], rvZ[1], rvX[2], rvY[2], rvZ[2], tesztcolor, puffer, zpuffer);
			CUDA_DrawLine_Zbuffer(rvX[0], rvY[0], rvZ[0], rvX[1], rvY[1], rvZ[1], tesztcolor, puffer, zpuffer);
			//CUDA_DrawLine(rvX[0], rvY[0], rvX[1], rvY[1], tesztcolor, puffer);
			/*CUDA_SetPixel(rvX[0], rvY[0], tesztcolor, puffer);
			CUDA_SetPixel(rvX[1], rvY[1], tesztcolor, puffer);
			CUDA_SetPixel(rvX[2], rvY[2], tesztcolor, puffer);*/
			continue;
		}
		else if (objlista[seged_index] == 1)//building
		{
			tesztcolor = szinek[seged_index];
			//CUDA_DrawLine_Zbuffer(rvX[0], rvY[0], rvZ[0], rvX[1], rvY[1], rvZ[1], tesztcolor, puffer, zpuffer);
			//CUDA_DrawLine(rvX[0], rvY[0], rvX[1], rvY[1], tesztcolor, puffer);
			
			CUDA_FillTriangle_Zbuffer(rvX[0], rvY[0], rvZ[0], rvX[1], rvY[1], rvZ[1], rvX[2], rvY[2], rvZ[2], tesztcolor, puffer, zpuffer);
			//CUDA_FillTriangle(rvX[0], rvY[0], rvX[1], rvY[1], rvX[2], rvY[2], tesztcolor, puffer);
			//tesztcolor = 0;
			//CUDA_DrawLine_Zbuffer(rvX[0], rvY[0], rvZ[0], rvX[1], rvY[1], rvZ[1], tesztcolor, puffer, zpuffer);
			continue;
		}
		else if (objlista[seged_index] == 90)//imported GPX
		{
			tesztcolor = 0;
			CUDA_DrawLine_Zbuffer(rvX[0], rvY[0], rvZ[0], rvX[1], rvY[1], rvZ[1], tesztcolor, puffer, zpuffer);
			continue;
		}
	}
}

__global__ void CUDA_render_TURBO_POINT(int maxitemcount, float* rawarrayX, float* rawarrayY, float* rawarrayZ, float degree_cosx, float degree_sinx, float degree_cosy, float degree_siny, float degree_cosz, float degree_sinz, unsigned int* puffer, float* zpuffer, VEKTOR fenyvektor, UINT32* szinek)
{
	int i;
	int index = (blockIdx.x * blockDim.x) + (threadIdx.x * 3);
	int stride = blockDim.x * gridDim.x;
	float t0, t1 = SCREEN_WIDTH / 4.0, t2 = SCREEN_HEIGHT / 6.0;
	float rvX[3], rvY[3], rvZ[3];

	//perspective projection
	int s1;
	int viewpoint = -3000;
	float sx = SCREEN_WIDTH / 2;
	float sultra = SCREEN_HEIGHT / 2, sultra2 = SCREEN_HEIGHT / 3;
	int x_minusz_edge = 0, y_minusz_edge = 0, x_max_edge = SCREEN_WIDTH - 1, y_max_edge = SCREEN_HEIGHT - 1;
	float distance;

	//****rendering
	int px, py, tesztcolor;
	float Light_intensity, Vector_length;
	VEKTOR Vector1, Vector2, vNormal, vNormalized;//for visibility check

	//rotation
	for (i = index; i < maxitemcount - 2; i += stride)
	{
		rvY[0] = (rawarrayY[i] * degree_cosx) - (rawarrayZ[i] * degree_sinx);
		rvZ[0] = rawarrayY[i] * degree_sinx + rawarrayZ[i] * degree_cosx;

		rvX[0] = rawarrayX[i] * degree_cosy + rvZ[0] * degree_siny;
		rvZ[0] = -rawarrayX[i] * degree_siny + rvZ[0] * degree_cosy;// +

		t0 = rvX[0];
		rvX[0] = t0 * degree_cosz - rvY[0] * degree_sinz + t1;
		rvY[0] = t0 * degree_sinz + rvY[0] * degree_cosz + t2;


		rvY[1] = (rawarrayY[i + 1] * degree_cosx) - (rawarrayZ[i + 1] * degree_sinx);
		rvZ[1] = rawarrayY[i + 1] * degree_sinx + rawarrayZ[i + 1] * degree_cosx;

		rvX[1] = rawarrayX[i + 1] * degree_cosy + rvZ[1] * degree_siny;
		rvZ[1] = -rawarrayX[i + 1] * degree_siny + rvZ[1] * degree_cosy;// +

		t0 = rvX[1];
		rvX[1] = t0 * degree_cosz - rvY[1] * degree_sinz + t1;
		rvY[1] = t0 * degree_sinz + rvY[1] * degree_cosz + t2;


		rvY[2] = (rawarrayY[i + 2] * degree_cosx) - (rawarrayZ[i + 2] * degree_sinx);
		rvZ[2] = rawarrayY[i + 2] * degree_sinx + rawarrayZ[i + 2] * degree_cosx;

		rvX[2] = rawarrayX[i + 2] * degree_cosy + rvZ[2] * degree_siny;
		rvZ[2] = -rawarrayX[i + 2] * degree_siny + rvZ[2] * degree_cosy;// +

		t0 = rvX[2];
		rvX[2] = t0 * degree_cosz - rvY[2] * degree_sinz + t1;
		rvY[2] = t0 * degree_sinz + rvY[2] * degree_cosz + t2;

		//****perspective projection

		distance = 999999;

		//**1. vertex
		if (rvZ[0] < distance) distance = rvZ[0];
		if (distance < viewpoint) { rvZ[0] = -9999999; }
		else
		{
			sultra = viewpoint / (viewpoint - rvZ[0]);
			rvX[0] = rvX[0] * sultra + 400;
			rvY[0] = (rvY[0] * sultra) + sultra2;
			if (rvX[0] < x_minusz_edge || rvX[0] > x_max_edge) { rvZ[0] = -9999999; }
			else if (rvY[0] < y_minusz_edge || rvY[0] > y_max_edge) { rvZ[0] = -9999999; }
			else
			{//***2. vertex
				if (rvZ[1] < distance) distance = rvZ[1];
				if (distance < viewpoint) { rvZ[1] = -9999999; }
				else
				{
					sultra = viewpoint / (viewpoint - rvZ[1]);
					rvX[1] = rvX[1] * sultra + 400;
					rvY[1] = (rvY[1] * sultra) + sultra2;
					if (rvX[1] < x_minusz_edge || rvX[1] > x_max_edge) { rvZ[1] = -9999999; }
					else if (rvY[1] < y_minusz_edge || rvY[1] > y_max_edge) { rvZ[1] = -9999999; }
					else
					{//**3. vertex
						if (rvZ[2] < distance) distance = rvZ[2];
						if (distance < viewpoint) { rvZ[2] = -9999999; }
						else
						{
							sultra = viewpoint / (viewpoint - rvZ[2]);
							rvX[2] = rvX[2] * sultra + 400;
							rvY[2] = (rvY[2] * sultra) + sultra2;
							if (rvX[2] < x_minusz_edge || rvX[2] > x_max_edge) { rvZ[2] = -9999999; }
							else if (rvY[2] < y_minusz_edge || rvY[2] > y_max_edge) { rvZ[2] = -9999999; }
						}
					}
				}
			}
		}

		//if (rvY[0] > 500 || rvY[1] > 500 || rvY[2] > 500) continue;

		//***rendering
		if ((rvZ[0] < -9000000) || (rvZ[1] < -9000000) || (rvZ[2] < -9000000)) continue;

		//// for visibility check
		//Vector1.x = rvX[1] - rvX[0];
		//Vector1.y = rvY[1] - rvY[0];
		//Vector1.z = rvZ[1] - rvZ[0];
		//Vector2.x = rvX[2] - rvX[0];
		//Vector2.y = rvY[2] - rvY[0];
		//Vector2.z = rvZ[2] - rvZ[0];

		//vNormal.x = ((Vector1.y * Vector2.z) - (Vector1.z * Vector2.y));
		//vNormal.y = ((Vector1.z * Vector2.x) - (Vector1.x * Vector2.z));
		//vNormal.z = ((Vector1.x * Vector2.y) - (Vector1.y * Vector2.x));

		////if (vNormal.z > 0) continue;//l�thatatlan oldalak elt�vol�t�sa

		//Vector_length = sqrtf((vNormal.x * vNormal.x) + (vNormal.y * vNormal.y) + (vNormal.z * vNormal.z));
		//vNormalized.x = vNormal.x / Vector_length;
		//vNormalized.y = vNormal.y / Vector_length;
		//vNormalized.z = vNormal.z / Vector_length;
		//Light_intensity = ((vNormalized.x * fenyvektor.x) + (vNormalized.y * fenyvektor.y) + (vNormalized.z * fenyvektor.z));
		//if (Light_intensity > 1) Light_intensity = 1;
		//else if (Light_intensity < 0) Light_intensity = 0;

		Light_intensity = 1;
		float szazalek, magassag = (float)szinek[i];
		if (magassag <= 0)
		{
			tesztcolor = RGB(200 * Light_intensity, 50 * Light_intensity, 50 * Light_intensity);
		}
		else if (magassag <= 250)
		{
			szazalek = magassag / (float)250;
			tesztcolor = RGB((2 * (1.0 - szazalek) + 113 * szazalek) * Light_intensity, (142 * (1.0 - szazalek) + 236 * szazalek) * Light_intensity, (16 * (1.0 - szazalek) + 119 * szazalek) * Light_intensity);
		}
		else if (magassag > 250 && magassag <= 1500)
		{
			szazalek = (magassag - 250) / (float)1250; //200;
			tesztcolor = RGB((165 * (1.0 - szazalek) + 13 * szazalek) * Light_intensity, (224 * (1.0 - szazalek) + 165 * szazalek) * Light_intensity, (250 * (1.0 - szazalek) + 230 * szazalek) * Light_intensity);
		}
		else if (magassag > 9000)
		{
			szazalek = (magassag - 9000) / (float)7500; //200;
			tesztcolor = RGB((13 * (1.0 - szazalek) + 255 * szazalek) * Light_intensity, (165 * (1.0 - szazalek) + 255 * szazalek) * Light_intensity, (230 * (1.0 - szazalek) + 255 * szazalek) * Light_intensity);
		}
		else
		{
			tesztcolor = RGB(255 * Light_intensity, 255 * Light_intensity, 255 * Light_intensity);
		}

		//CUDA_SetPixel(rvX[0], rvY[0], tesztcolor, puffer);
		CUDA_SetPixel_Zbuffer(rvX[0], rvY[0], rvZ[0], tesztcolor, puffer, zpuffer);


		magassag = (float)szinek[i + 1];
		if (magassag <= 0)
		{
			tesztcolor = RGB(200 * Light_intensity, 50 * Light_intensity, 50 * Light_intensity);
		}
		else if (magassag <= 250)
		{
			szazalek = magassag / (float)250;
			tesztcolor = RGB((2 * (1.0 - szazalek) + 113 * szazalek) * Light_intensity, (142 * (1.0 - szazalek) + 236 * szazalek) * Light_intensity, (16 * (1.0 - szazalek) + 119 * szazalek) * Light_intensity);
		}
		else if (magassag > 250 && magassag <= 1500)
		{
			szazalek = (magassag - 250) / (float)1250; //200;
			tesztcolor = RGB((165 * (1.0 - szazalek) + 13 * szazalek) * Light_intensity, (224 * (1.0 - szazalek) + 165 * szazalek) * Light_intensity, (250 * (1.0 - szazalek) + 230 * szazalek) * Light_intensity);
		}
		else if (magassag > 9000)
		{
			szazalek = (magassag - 9000) / (float)7500; //200;
			tesztcolor = RGB((13 * (1.0 - szazalek) + 255 * szazalek) * Light_intensity, (165 * (1.0 - szazalek) + 255 * szazalek) * Light_intensity, (230 * (1.0 - szazalek) + 255 * szazalek) * Light_intensity);
		}
		else
		{
			tesztcolor = RGB(255 * Light_intensity, 255 * Light_intensity, 255 * Light_intensity);
		}

		//CUDA_SetPixel(rvX[1], rvY[1], tesztcolor, puffer);
		CUDA_SetPixel_Zbuffer(rvX[1], rvY[1], rvZ[1], tesztcolor, puffer, zpuffer);


		magassag = (float)szinek[i + 2];
		if (magassag <= 0)
		{
			tesztcolor = RGB(200 * Light_intensity, 50 * Light_intensity, 50 * Light_intensity);
		}
		else if (magassag <= 250)
		{
			szazalek = magassag / (float)250;
			tesztcolor = RGB((2 * (1.0 - szazalek) + 113 * szazalek) * Light_intensity, (142 * (1.0 - szazalek) + 236 * szazalek) * Light_intensity, (16 * (1.0 - szazalek) + 119 * szazalek) * Light_intensity);
		}
		else if (magassag > 250 && magassag <= 1500)
		{
			szazalek = (magassag - 250) / (float)1250; //200;
			tesztcolor = RGB((165 * (1.0 - szazalek) + 13 * szazalek) * Light_intensity, (224 * (1.0 - szazalek) + 165 * szazalek) * Light_intensity, (250 * (1.0 - szazalek) + 230 * szazalek) * Light_intensity);
		}
		else if (magassag > 9000)
		{
			szazalek = (magassag - 9000) / (float)7500; //200;
			tesztcolor = RGB((13 * (1.0 - szazalek) + 255 * szazalek) * Light_intensity, (165 * (1.0 - szazalek) + 255 * szazalek) * Light_intensity, (230 * (1.0 - szazalek) + 255 * szazalek) * Light_intensity);
		}
		else
		{
			tesztcolor = RGB(255 * Light_intensity, 255 * Light_intensity, 255 * Light_intensity);
		}

		//CUDA_SetPixel(rvX[2], rvY[2], tesztcolor, puffer);
		CUDA_SetPixel_Zbuffer(rvX[2], rvY[2], rvZ[2], tesztcolor, puffer, zpuffer);

	}
}

__global__ void CUDA_render_TURBO_single_point(float rawarrayX, float rawarrayY, float rawarrayZ, float degree_cosx, float degree_sinx, float degree_cosy, float degree_siny, float degree_cosz, float degree_sinz, unsigned int* puffer, float* zpuffer)
{
	float t0, t1 = SCREEN_WIDTH / 4.0, t2 = SCREEN_HEIGHT / 6.0;
	float rvX, rvY, rvZ;

	//perspective projection
	int viewpoint = -3000;
	float sx = SCREEN_WIDTH / 2;
	float sultra = SCREEN_HEIGHT / 2, sultra2 = SCREEN_HEIGHT / 3;
	int x_minusz_edge = 0, y_minusz_edge = 0, x_max_edge = SCREEN_WIDTH - 1, y_max_edge = SCREEN_HEIGHT - 1;
	float distance;

	//****rendering
	int tesztcolor;

	//rotation
		rvY = (rawarrayY * degree_cosx) - (rawarrayZ * degree_sinx);
		rvZ = rawarrayY * degree_sinx + rawarrayZ * degree_cosx;

		rvX = rawarrayX * degree_cosy + rvZ * degree_siny;
		rvZ = -rawarrayX * degree_siny + rvZ * degree_cosy;// +

		t0 = rvX;
		rvX = t0 * degree_cosz - rvY * degree_sinz + t1;
		rvY = t0 * degree_sinz + rvY * degree_cosz + t2;

		//****perspective projection

		distance = 999999;

		//**1. vertex
		if (rvZ < distance) distance = rvZ;
		if (distance < viewpoint) { rvZ = -9999999; }
		else
		{
			sultra = viewpoint / (viewpoint - rvZ);
			rvX = rvX * sultra + 600;
			rvY = (rvY * sultra) + sultra2;
			if (rvX < x_minusz_edge || rvX > x_max_edge) { rvZ = -9999999; }
			else if (rvY < y_minusz_edge || rvY > y_max_edge) { rvZ = -9999999; }
		}

		//***rendering
		if (rvZ < -9000000) return;

		tesztcolor = RGB(0, 0, 255);

		if ((rvX + 20) >= SCREEN_WIDTH || (rvX - 20) < 0 || (rvY + 100) >= SCREEN_HEIGHT || (rvY - 100) < 0) return;
		CUDA_FillTriangle_Zbuffer(rvX-8 , rvY-40, rvZ, rvX+8, rvY-40, rvZ, rvX, rvY, rvZ, tesztcolor, puffer, zpuffer);
}

//************************************************************
//*******************CPU ONLY RENDEREL�SHEZ*******************
//************************************************************
void CPU_render_TURBO_POINT(int maxitemcount, float* rawarrayX, float* rawarrayY, float* rawarrayZ, float degree_cosx, float degree_sinx, float degree_cosy, float degree_siny, float degree_cosz, float degree_sinz, unsigned int* puffer, float* zpuffer, VEKTOR fenyvektor, UINT32* szinek)
{
	int i;
	float t0, t1 = SCREEN_WIDTH / 4.0, t2 = SCREEN_HEIGHT / 6.0;
	float rvX[3], rvY[3], rvZ[3];

	//perspective projection
	int s1;
	int viewpoint = -3000;
	float sx = SCREEN_WIDTH / 2;
	float sultra = SCREEN_HEIGHT / 2, sultra2 = SCREEN_HEIGHT / 3;
	int x_minusz_edge = 0, y_minusz_edge = 0, x_max_edge = SCREEN_WIDTH - 1, y_max_edge = SCREEN_HEIGHT - 1;
	float distance;

	//****rendering
	int px, py, tesztcolor;
	float Light_intensity, Vector_length;
	VEKTOR Vector1, Vector2, vNormal, vNormalized;//for visibility check

	//rotation
	for (i = 0; i < maxitemcount - 2; ++i)
	{
		rvY[0] = (rawarrayY[i] * degree_cosx) - (rawarrayZ[i] * degree_sinx);
		rvZ[0] = rawarrayY[i] * degree_sinx + rawarrayZ[i] * degree_cosx;

		rvX[0] = rawarrayX[i] * degree_cosy + rvZ[0] * degree_siny;
		rvZ[0] = -rawarrayX[i] * degree_siny + rvZ[0] * degree_cosy;// +

		t0 = rvX[0];
		rvX[0] = t0 * degree_cosz - rvY[0] * degree_sinz + t1;
		rvY[0] = t0 * degree_sinz + rvY[0] * degree_cosz + t2;


		rvY[1] = (rawarrayY[i + 1] * degree_cosx) - (rawarrayZ[i + 1] * degree_sinx);
		rvZ[1] = rawarrayY[i + 1] * degree_sinx + rawarrayZ[i + 1] * degree_cosx;

		rvX[1] = rawarrayX[i + 1] * degree_cosy + rvZ[1] * degree_siny;
		rvZ[1] = -rawarrayX[i + 1] * degree_siny + rvZ[1] * degree_cosy;// +

		t0 = rvX[1];
		rvX[1] = t0 * degree_cosz - rvY[1] * degree_sinz + t1;
		rvY[1] = t0 * degree_sinz + rvY[1] * degree_cosz + t2;


		rvY[2] = (rawarrayY[i + 2] * degree_cosx) - (rawarrayZ[i + 2] * degree_sinx);
		rvZ[2] = rawarrayY[i + 2] * degree_sinx + rawarrayZ[i + 2] * degree_cosx;

		rvX[2] = rawarrayX[i + 2] * degree_cosy + rvZ[2] * degree_siny;
		rvZ[2] = -rawarrayX[i + 2] * degree_siny + rvZ[2] * degree_cosy;// +

		t0 = rvX[2];
		rvX[2] = t0 * degree_cosz - rvY[2] * degree_sinz + t1;
		rvY[2] = t0 * degree_sinz + rvY[2] * degree_cosz + t2;

		//****perspective projection

		distance = 999999;

		//**1. vertex
		if (rvZ[0] < distance) distance = rvZ[0];
		if (distance < viewpoint) { rvZ[0] = -9999999; }
		else
		{
			sultra = viewpoint / (viewpoint - rvZ[0]);
			rvX[0] = rvX[0] * sultra + 400;
			rvY[0] = (rvY[0] * sultra) + sultra2;
			if (rvX[0] < x_minusz_edge || rvX[0] > x_max_edge) { rvZ[0] = -9999999; }
			else if (rvY[0] < y_minusz_edge || rvY[0] > y_max_edge) { rvZ[0] = -9999999; }
			else
			{//***2. vertex
				if (rvZ[1] < distance) distance = rvZ[1];
				if (distance < viewpoint) { rvZ[1] = -9999999; }
				else
				{
					sultra = viewpoint / (viewpoint - rvZ[1]);
					rvX[1] = rvX[1] * sultra + 400;
					rvY[1] = (rvY[1] * sultra) + sultra2;
					if (rvX[1] < x_minusz_edge || rvX[1] > x_max_edge) { rvZ[1] = -9999999; }
					else if (rvY[1] < y_minusz_edge || rvY[1] > y_max_edge) { rvZ[1] = -9999999; }
					else
					{//**3. vertex
						if (rvZ[2] < distance) distance = rvZ[2];
						if (distance < viewpoint) { rvZ[2] = -9999999; }
						else
						{
							sultra = viewpoint / (viewpoint - rvZ[2]);
							rvX[2] = rvX[2] * sultra + 400;
							rvY[2] = (rvY[2] * sultra) + sultra2;
							if (rvX[2] < x_minusz_edge || rvX[2] > x_max_edge) { rvZ[2] = -9999999; }
							else if (rvY[2] < y_minusz_edge || rvY[2] > y_max_edge) { rvZ[2] = -9999999; }
						}
					}
				}
			}
		}

		//if (rvY[0] > 500 || rvY[1] > 500 || rvY[2] > 500) continue;

		//***rendering
		if ((rvZ[0] < -9000000) || (rvZ[1] < -9000000) || (rvZ[2] < -9000000)) continue;

		//// for visibility check
		//Vector1.x = rvX[1] - rvX[0];
		//Vector1.y = rvY[1] - rvY[0];
		//Vector1.z = rvZ[1] - rvZ[0];
		//Vector2.x = rvX[2] - rvX[0];
		//Vector2.y = rvY[2] - rvY[0];
		//Vector2.z = rvZ[2] - rvZ[0];

		//vNormal.x = ((Vector1.y * Vector2.z) - (Vector1.z * Vector2.y));
		//vNormal.y = ((Vector1.z * Vector2.x) - (Vector1.x * Vector2.z));
		//vNormal.z = ((Vector1.x * Vector2.y) - (Vector1.y * Vector2.x));

		////if (vNormal.z > 0) continue;//l�thatatlan oldalak elt�vol�t�sa

		//Vector_length = sqrtf((vNormal.x * vNormal.x) + (vNormal.y * vNormal.y) + (vNormal.z * vNormal.z));
		//vNormalized.x = vNormal.x / Vector_length;
		//vNormalized.y = vNormal.y / Vector_length;
		//vNormalized.z = vNormal.z / Vector_length;
		//Light_intensity = ((vNormalized.x * fenyvektor.x) + (vNormalized.y * fenyvektor.y) + (vNormalized.z * fenyvektor.z));
		//if (Light_intensity > 1) Light_intensity = 1;
		//else if (Light_intensity < 0) Light_intensity = 0;

		Light_intensity = 1;
		float szazalek, magassag = (float)szinek[i];
		if (magassag <= 0)
		{
			tesztcolor = RGB(200 * Light_intensity, 50 * Light_intensity, 50 * Light_intensity);
		}
		else if (magassag <= 250)
		{
			szazalek = magassag / (float)250;
			tesztcolor = RGB((2 * (1.0 - szazalek) + 113 * szazalek) * Light_intensity, (142 * (1.0 - szazalek) + 236 * szazalek) * Light_intensity, (16 * (1.0 - szazalek) + 119 * szazalek) * Light_intensity);
		}
		else if (magassag > 250 && magassag <= 1500)
		{
			szazalek = (magassag - 250) / (float)1250; //200;
			tesztcolor = RGB((165 * (1.0 - szazalek) + 13 * szazalek) * Light_intensity, (224 * (1.0 - szazalek) + 165 * szazalek) * Light_intensity, (250 * (1.0 - szazalek) + 230 * szazalek) * Light_intensity);
		}
		else if (magassag > 9000)
		{
			szazalek = (magassag - 9000) / (float)7500; //200;
			tesztcolor = RGB((13 * (1.0 - szazalek) + 255 * szazalek) * Light_intensity, (165 * (1.0 - szazalek) + 255 * szazalek) * Light_intensity, (230 * (1.0 - szazalek) + 255 * szazalek) * Light_intensity);
		}
		else
		{
			tesztcolor = RGB(255 * Light_intensity, 255 * Light_intensity, 255 * Light_intensity);
		}

		//CPU_SetPixel(rvX[0], rvY[0], tesztcolor, puffer);
		CPU_SetPixel_Zbuffer(rvX[0], rvY[0], rvZ[0], tesztcolor, puffer, zpuffer);


		magassag = (float)szinek[i + 1];
		if (magassag <= 0)
		{
			tesztcolor = RGB(200 * Light_intensity, 50 * Light_intensity, 50 * Light_intensity);
		}
		else if (magassag <= 250)
		{
			szazalek = magassag / (float)250;
			tesztcolor = RGB((2 * (1.0 - szazalek) + 113 * szazalek) * Light_intensity, (142 * (1.0 - szazalek) + 236 * szazalek) * Light_intensity, (16 * (1.0 - szazalek) + 119 * szazalek) * Light_intensity);
		}
		else if (magassag > 250 && magassag <= 1500)
		{
			szazalek = (magassag - 250) / (float)1250; //200;
			tesztcolor = RGB((165 * (1.0 - szazalek) + 13 * szazalek) * Light_intensity, (224 * (1.0 - szazalek) + 165 * szazalek) * Light_intensity, (250 * (1.0 - szazalek) + 230 * szazalek) * Light_intensity);
		}
		else if (magassag > 9000)
		{
			szazalek = (magassag - 9000) / (float)7500; //200;
			tesztcolor = RGB((13 * (1.0 - szazalek) + 255 * szazalek) * Light_intensity, (165 * (1.0 - szazalek) + 255 * szazalek) * Light_intensity, (230 * (1.0 - szazalek) + 255 * szazalek) * Light_intensity);
		}
		else
		{
			tesztcolor = RGB(255 * Light_intensity, 255 * Light_intensity, 255 * Light_intensity);
		}

		//CPU_SetPixel(rvX[1], rvY[1], tesztcolor, puffer);
		CPU_SetPixel_Zbuffer(rvX[1], rvY[1], rvZ[1], tesztcolor, puffer, zpuffer);


		magassag = (float)szinek[i + 2];
		if (magassag <= 0)
		{
			tesztcolor = RGB(200 * Light_intensity, 50 * Light_intensity, 50 * Light_intensity);
		}
		else if (magassag <= 250)
		{
			szazalek = magassag / (float)250;
			tesztcolor = RGB((2 * (1.0 - szazalek) + 113 * szazalek) * Light_intensity, (142 * (1.0 - szazalek) + 236 * szazalek) * Light_intensity, (16 * (1.0 - szazalek) + 119 * szazalek) * Light_intensity);
		}
		else if (magassag > 250 && magassag <= 1500)
		{
			szazalek = (magassag - 250) / (float)1250; //200;
			tesztcolor = RGB((165 * (1.0 - szazalek) + 13 * szazalek) * Light_intensity, (224 * (1.0 - szazalek) + 165 * szazalek) * Light_intensity, (250 * (1.0 - szazalek) + 230 * szazalek) * Light_intensity);
		}
		else if (magassag > 9000)
		{
			szazalek = (magassag - 9000) / (float)7500; //200;
			tesztcolor = RGB((13 * (1.0 - szazalek) + 255 * szazalek) * Light_intensity, (165 * (1.0 - szazalek) + 255 * szazalek) * Light_intensity, (230 * (1.0 - szazalek) + 255 * szazalek) * Light_intensity);
		}
		else
		{
			tesztcolor = RGB(255 * Light_intensity, 255 * Light_intensity, 255 * Light_intensity);
		}

		//CPU_SetPixel(rvX[2], rvY[2], tesztcolor, puffer);
		CPU_SetPixel_Zbuffer(rvX[2], rvY[2], rvZ[2], tesztcolor, puffer, zpuffer);

	}
}

void CPU_render_TURBO(int startitemcount, int enditemcount, float* rawarrayX, float* rawarrayY, float* rawarrayZ, float degree_cosx, float degree_sinx, float degree_cosy, float degree_siny, float degree_cosz, float degree_sinz, unsigned int* puffer, float* zpuffer, VEKTOR fenyvektor, UINT32* szinek, char* objlista)
{
	long long i, reteg_index, reteg_start_index, reteg_stop_index, seged_index, j;
	float t0, t1 = SCREEN_WIDTH / 4.0, t2 = SCREEN_HEIGHT / 6.0;
	float rvX[3], rvY[3], rvZ[3];

	//perspective projection
	int s1;
	int viewpoint = -3000;
	int x_pontositas = 600;
	float sx = SCREEN_WIDTH / 2;
	float sultra = SCREEN_HEIGHT / 2, sultra2 = SCREEN_HEIGHT / 3;
	int x_minusz_edge = 0, y_minusz_edge = 0, x_max_edge = SCREEN_WIDTH - 1, y_max_edge = SCREEN_HEIGHT - 1;
	float distance;

	//****rendering
	int px, py, tesztcolor;
	float Light_intensity, Vector_length;
	VEKTOR Vector1, Vector2, vNormal, vNormalized;//for visibility check

	//rotation
	for (i = startitemcount; i < enditemcount - 2; i+=3)
	{
		rvY[0] = (rawarrayY[i] * degree_cosx) - (rawarrayZ[i] * degree_sinx);
		rvZ[0] = rawarrayY[i] * degree_sinx + rawarrayZ[i] * degree_cosx;

		rvX[0] = rawarrayX[i] * degree_cosy + rvZ[0] * degree_siny;
		rvZ[0] = -rawarrayX[i] * degree_siny + rvZ[0] * degree_cosy;// +

		t0 = rvX[0];
		rvX[0] = t0 * degree_cosz - rvY[0] * degree_sinz + t1;
		rvY[0] = t0 * degree_sinz + rvY[0] * degree_cosz + t2;


		rvY[1] = (rawarrayY[i + 1] * degree_cosx) - (rawarrayZ[i + 1] * degree_sinx);
		rvZ[1] = rawarrayY[i + 1] * degree_sinx + rawarrayZ[i + 1] * degree_cosx;

		rvX[1] = rawarrayX[i + 1] * degree_cosy + rvZ[1] * degree_siny;
		rvZ[1] = -rawarrayX[i + 1] * degree_siny + rvZ[1] * degree_cosy;// +

		t0 = rvX[1];
		rvX[1] = t0 * degree_cosz - rvY[1] * degree_sinz + t1;
		rvY[1] = t0 * degree_sinz + rvY[1] * degree_cosz + t2;


		rvY[2] = (rawarrayY[i + 2] * degree_cosx) - (rawarrayZ[i + 2] * degree_sinx);
		rvZ[2] = rawarrayY[i + 2] * degree_sinx + rawarrayZ[i + 2] * degree_cosx;

		rvX[2] = rawarrayX[i + 2] * degree_cosy + rvZ[2] * degree_siny;
		rvZ[2] = -rawarrayX[i + 2] * degree_siny + rvZ[2] * degree_cosy;// +

		t0 = rvX[2];
		rvX[2] = t0 * degree_cosz - rvY[2] * degree_sinz + t1;
		rvY[2] = t0 * degree_sinz + rvY[2] * degree_cosz + t2;

		//****perspective projection

		distance = 999999;

		//**1. vertex
		if (rvZ[0] < distance) distance = rvZ[0];
		if (distance < viewpoint) { rvZ[0] = -9999999; }
		else
		{
			sultra = viewpoint / (viewpoint - rvZ[0]);
			rvX[0] = rvX[0] * sultra + x_pontositas;
			rvY[0] = (rvY[0] * sultra) + sultra2;
			if (rvX[0] < x_minusz_edge || rvX[0] > x_max_edge) { rvZ[0] = -9999999; }
			else if (rvY[0] < y_minusz_edge || rvY[0] > y_max_edge) { rvZ[0] = -9999999; }
			else
			{//***2. vertex
				if (rvZ[1] < distance) distance = rvZ[1];
				if (distance < viewpoint) { rvZ[1] = -9999999; }
				else
				{
					sultra = viewpoint / (viewpoint - rvZ[1]);
					rvX[1] = rvX[1] * sultra + x_pontositas;
					rvY[1] = (rvY[1] * sultra) + sultra2;
					if (rvX[1] < x_minusz_edge || rvX[1] > x_max_edge) { rvZ[1] = -9999999; }
					else if (rvY[1] < y_minusz_edge || rvY[1] > y_max_edge) { rvZ[1] = -9999999; }
					else
					{//**3. vertex
						if (rvZ[2] < distance) distance = rvZ[2];
						if (distance < viewpoint) { rvZ[2] = -9999999; }
						else
						{
							sultra = viewpoint / (viewpoint - rvZ[2]);
							rvX[2] = rvX[2] * sultra + x_pontositas;
							rvY[2] = (rvY[2] * sultra) + sultra2;
							if (rvX[2] < x_minusz_edge || rvX[2] > x_max_edge) { rvZ[2] = -9999999; }
							else if (rvY[2] < y_minusz_edge || rvY[2] > y_max_edge) { rvZ[2] = -9999999; }
						}
					}
				}
			}
		}

		//if (rvY[0] > 500 || rvY[1] > 500 || rvY[2] > 500) continue;

		//***rendering
		if ((rvZ[0] < -9000000) || (rvZ[1] < -9000000) || (rvZ[2] < -9000000)) continue;

		// for visibility check
		Vector1.x = rvX[1] - rvX[0];
		Vector1.y = rvY[1] - rvY[0];
		Vector1.z = rvZ[1] - rvZ[0];
		Vector2.x = rvX[2] - rvX[0];
		Vector2.y = rvY[2] - rvY[0];
		Vector2.z = rvZ[2] - rvZ[0];

		vNormal.x = ((Vector1.y * Vector2.z) - (Vector1.z * Vector2.y));
		vNormal.y = ((Vector1.z * Vector2.x) - (Vector1.x * Vector2.z));
		vNormal.z = ((Vector1.x * Vector2.y) - (Vector1.y * Vector2.x));

		//if (vNormal.z > 0) continue;//l�thatatlan oldalak elt�vol�t�sa

		seged_index = i / 3;

		if (objlista[seged_index] == 0)//domborzat
		{
			Vector_length = sqrtf((vNormal.x * vNormal.x) + (vNormal.y * vNormal.y) + (vNormal.z * vNormal.z));
			vNormalized.x = vNormal.x / Vector_length;
			vNormalized.y = vNormal.y / Vector_length;
			vNormalized.z = vNormal.z / Vector_length;
			Light_intensity = ((vNormalized.x * fenyvektor.x) + (vNormalized.y * fenyvektor.y) + (vNormalized.z * fenyvektor.z));
			if (Light_intensity > 1) Light_intensity = 1;
			else if (Light_intensity < 0) Light_intensity = 0;

			float szazalek, magassag = (float)szinek[seged_index];
			//if (magassag <= 0)
			//{
			//	tesztcolor = RGB(200 * Light_intensity, 50 * Light_intensity, 50 * Light_intensity);
			//}
			//else if (magassag <= 250)
			//{
			//	szazalek = magassag / (float)250;
			//	tesztcolor = RGB((2 * (1.0 - szazalek) + 113 * szazalek) * Light_intensity, (142 * (1.0 - szazalek) + 236 * szazalek) * Light_intensity, (16 * (1.0 - szazalek) + 119 * szazalek) * Light_intensity);
			//}
			//else if (magassag > 250 && magassag <= 1500)
			//{
			//	szazalek = (magassag - 250) / (float)1250; //200;
			//	tesztcolor = RGB((165 * (1.0 - szazalek) + 13 * szazalek) * Light_intensity, (224 * (1.0 - szazalek) + 165 * szazalek) * Light_intensity, (250 * (1.0 - szazalek) + 230 * szazalek) * Light_intensity);
			//}
			//else if (magassag > 9000)
			//{
			//	szazalek = (magassag - 9000) / (float)7500; //200;
			//	tesztcolor = RGB((13 * (1.0 - szazalek) + 255 * szazalek) * Light_intensity, (165 * (1.0 - szazalek) + 255 * szazalek) * Light_intensity, (230 * (1.0 - szazalek) + 255 * szazalek) * Light_intensity);
			//}
			//else
			//{
			//	tesztcolor = RGB(255 * Light_intensity, 255 * Light_intensity, 255 * Light_intensity);
			//}
			// 
			
			int tesztcolor1, tesztcolor2, tesztcolor3;
			magassag = (float)szinek[i / 3];
			szazalek = magassag / (float)600;
			tesztcolor1 = RGB((2 * (1.0 - szazalek) + 113 * szazalek) * Light_intensity, (142 * (1.0 - szazalek) + 236 * szazalek) * Light_intensity, (16 * (1.0 - szazalek) + 119 * szazalek) * Light_intensity);
			magassag = (float)szinek[i / 3 + 1];
			szazalek = magassag / (float)600;
			tesztcolor2 = RGB((2 * (1.0 - szazalek) + 113 * szazalek) * Light_intensity, (142 * (1.0 - szazalek) + 236 * szazalek) * Light_intensity, (16 * (1.0 - szazalek) + 119 * szazalek) * Light_intensity);
			magassag = (float)szinek[i / 3 + 2];
			szazalek = magassag / (float)600;
			tesztcolor3 = RGB((2 * (1.0 - szazalek) + 113 * szazalek) * Light_intensity, (142 * (1.0 - szazalek) + 236 * szazalek) * Light_intensity, (16 * (1.0 - szazalek) + 119 * szazalek) * Light_intensity);

			//CPU_FillTriangle(rvX[0], rvY[0], rvX[1], rvY[1], rvX[2], rvY[2], tesztcolor, puffer);
			CPU_FillTriangle_Zbuffer_Goraud(rvX[0], rvY[0], rvZ[0], tesztcolor1,rvX[1], rvY[1], rvZ[1], tesztcolor2,rvX[2], rvY[2], rvZ[2], tesztcolor3, puffer, zpuffer);
			//CPU_DrawLine_Zbuffer(rvX[0], rvY[0], rvZ[0], rvX[1], rvY[1], rvZ[1], tesztcolor, puffer, zpuffer);
			continue;
		}
		else if (objlista[seged_index] == 21)//primary road
		{
			tesztcolor = szinek[seged_index];
			CPU_DrawLine_Zbuffer(rvX[0], rvY[0], rvZ[0], rvX[1], rvY[1], rvZ[1], tesztcolor, puffer, zpuffer);
			//CPU_DrawLine(rvX[0], rvY[0], rvX[1], rvY[1], tesztcolor, puffer);
			continue;
		}
		else if (objlista[seged_index] == 22)//motorway
		{
			tesztcolor = szinek[seged_index];
			CPU_DrawLine_Zbuffer(rvX[0], rvY[0], rvZ[0], rvX[1], rvY[1], rvZ[1], tesztcolor, puffer, zpuffer);
			//CPU_DrawLine(rvX[0], rvY[0], rvX[1], rvY[1], tesztcolor, puffer);
			continue;
		}
		else if (objlista[seged_index] == 2)//road
		{
			tesztcolor = RGB(0, 0, 0);
			CPU_DrawLine_Zbuffer(rvX[0], rvY[0], rvZ[0], rvX[1], rvY[1], rvZ[1], tesztcolor, puffer, zpuffer);
			//CPU_DrawLine(rvX[0], rvY[0], rvX[1], rvY[1], tesztcolor, puffer);
			continue;
		}
		else if (objlista[seged_index] == 3)//railway
		{
			tesztcolor = RGB(0, 0, 250);
			CPU_DrawLine_Zbuffer(rvX[0], rvY[0], rvZ[0], rvX[1], rvY[1], rvZ[1], tesztcolor, puffer, zpuffer);
			//CPU_DrawLine(rvX[0], rvY[0], rvX[1], rvY[1], tesztcolor, puffer);
			continue;
		}
		else if (objlista[seged_index] == 30)//park
		{
			tesztcolor = szinek[seged_index];
			CPU_FillTriangle_Zbuffer(rvX[0], rvY[0], rvZ[0], rvX[1], rvY[1], rvZ[1], rvX[2], rvY[2], rvZ[2], tesztcolor, puffer, zpuffer);
			//CPU_DrawLine_Zbuffer(rvX[0], rvY[0], rvZ[0], rvX[1], rvY[1], rvZ[1], tesztcolor, puffer, zpuffer);
			//CPU_DrawLine(rvX[0], rvY[0], rvX[1], rvY[1], tesztcolor, puffer);
			/*CPU_SetPixel(rvX[0], rvY[0], tesztcolor, puffer);
			CPU_SetPixel(rvX[1], rvY[1], tesztcolor, puffer);
			CPU_SetPixel(rvX[2], rvY[2], tesztcolor, puffer);*/
			continue;
		}
		else if (objlista[seged_index] == 33)//lake
		{
			tesztcolor = szinek[seged_index];
			//CPU_FillTriangle_Zbuffer(rvX[0], rvY[0], rvZ[0], rvX[1], rvY[1], rvZ[1], rvX[2], rvY[2], rvZ[2], tesztcolor, puffer, zpuffer);
			//CPU_DrawLine_Zbuffer(rvX[0], rvY[0], rvZ[0], rvX[1], rvY[1], rvZ[1], tesztcolor, puffer, zpuffer);
			//CPU_DrawLine(rvX[0], rvY[0], rvX[1], rvY[1], tesztcolor, puffer);
			CPU_SetPixel(rvX[0], rvY[0], tesztcolor, puffer);
			CPU_SetPixel(rvX[1], rvY[1], tesztcolor, puffer);
			CPU_SetPixel(rvX[2], rvY[2], tesztcolor, puffer);
			continue;
		}
		else if (objlista[seged_index] == 1)//building
		{
			tesztcolor = szinek[seged_index];
			//CPU_DrawLine_Zbuffer(rvX[0], rvY[0], rvZ[0], rvX[1], rvY[1], rvZ[1], tesztcolor, puffer, zpuffer);
			//CPU_DrawLine(rvX[0], rvY[0], rvX[1], rvY[1], tesztcolor, puffer);

			//CPU_FillTriangle(rvX[0], rvY[0], rvX[1], rvY[1], rvX[2], rvY[2], tesztcolor, puffer);
			CPU_FillTriangle_Zbuffer(rvX[0], rvY[0], rvZ[0], rvX[1], rvY[1], rvZ[1], rvX[2], rvY[2], rvZ[2], tesztcolor, puffer, zpuffer);
			// 
			//tesztcolor = 0;
			//CPU_FillTriangle(rvX[0], rvY[0], rvX[1], rvY[1], rvX[2], rvY[2], tesztcolor, puffer);
			//CPU_DrawLine_Zbuffer(rvX[0], rvY[0], rvZ[0], rvX[1], rvY[1], rvZ[1], tesztcolor, puffer, zpuffer);
			continue;
		}
		else if (objlista[seged_index] == 90)//imported GPX
		{
			tesztcolor = 0;
			CPU_DrawLine_Zbuffer(rvX[0], rvY[0], rvZ[0], rvX[1], rvY[1], rvZ[1], tesztcolor, puffer, zpuffer);
			continue;
		}
	}
}

void CPU_render_TURBO_single_point(float rawarrayX, float rawarrayY, float rawarrayZ, float degree_cosx, float degree_sinx, float degree_cosy, float degree_siny, float degree_cosz, float degree_sinz, unsigned int* puffer, float* zpuffer)
{
	float t0, t1 = SCREEN_WIDTH / 4.0, t2 = SCREEN_HEIGHT / 6.0;
	float rvX, rvY, rvZ;

	//perspective projection
	int viewpoint = -3000;
	float sx = SCREEN_WIDTH / 2;
	float sultra = SCREEN_HEIGHT / 2, sultra2 = SCREEN_HEIGHT / 3;
	int x_minusz_edge = 0, y_minusz_edge = 0, x_max_edge = SCREEN_WIDTH - 1, y_max_edge = SCREEN_HEIGHT - 1;
	float distance;

	//****rendering
	int tesztcolor;

	//rotation
	rvY = (rawarrayY * degree_cosx) - (rawarrayZ * degree_sinx);
	rvZ = rawarrayY * degree_sinx + rawarrayZ * degree_cosx;

	rvX = rawarrayX * degree_cosy + rvZ * degree_siny;
	rvZ = -rawarrayX * degree_siny + rvZ * degree_cosy;// +

	t0 = rvX;
	rvX = t0 * degree_cosz - rvY * degree_sinz + t1;
	rvY = t0 * degree_sinz + rvY * degree_cosz + t2;

	//****perspective projection

	distance = 999999;

	//**1. vertex
	if (rvZ < distance) distance = rvZ;
	if (distance < viewpoint) { rvZ = -9999999; }
	else
	{
		sultra = viewpoint / (viewpoint - rvZ);
		rvX = rvX * sultra + 600;
		rvY = (rvY * sultra) + sultra2;
		if (rvX < x_minusz_edge || rvX > x_max_edge) { rvZ = -9999999; }
		else if (rvY < y_minusz_edge || rvY > y_max_edge) { rvZ = -9999999; }
	}

	//***rendering
	if (rvZ < -9000000) return;

	tesztcolor = RGB(0, 0, 255);

	if ((rvX + 20) >= SCREEN_WIDTH || (rvX - 20) < 0 || (rvY + 100) >= SCREEN_HEIGHT || (rvY - 100) < 0) return;
	CPU_FillTriangle_Zbuffer(rvX - 8, rvY - 40, rvZ, rvX + 8, rvY - 40, rvZ, rvX, rvY, rvZ, tesztcolor, puffer, zpuffer);
}

void CPU_SetPixel(int x1, int y1, int color, unsigned int* puffer)
{
	puffer[(y1 * SCREEN_WIDTH) + x1] = color;
}

void CPU_SetPixel_Zbuffer(int x1, int y1, int z1, int color, unsigned int* puffer, float* zpuffer)
{
	int offset = (y1 * SCREEN_WIDTH) + x1;
	if (zpuffer[offset] > z1)
	{
		zpuffer[offset] = z1;
		puffer[offset] = color;
	}
}

void CPU_DrawLine(int x1, int y1, int x2, int y2, int color, unsigned int* puffer)
{
	int dx = abs(x2 - x1);
	int dy = abs(y2 - y1);
	int sx = (x1 < x2) ? 1 : -1;
	int sy = (y1 < y2) ? 1 : -1;
	int err = dx - dy;

	while (1) {
		puffer[(y1 * SCREEN_WIDTH) + x1] = color;
		if (x1 == x2 && y1 == y2) break;
		int e2 = err * 2;
		if (e2 > -dy) {
			err -= dy;
			x1 += sx;
		}
		if (e2 < dx) {
			err += dx;
			y1 += sy;
		}
	}
}

void CPU_DrawLine_Zbuffer(int x1, int y1, int z1, int x2, int y2, int z2, int color, unsigned int* puffer, float* zpuffer)
{
	int dx = abs(x2 - x1);
	int dy = abs(y2 - y1);
	int sx = (x1 < x2) ? 1 : -1;
	int sy = (y1 < y2) ? 1 : -1;
	int err = dx - dy, e2;
	float dz = z2 - z1;
	float z = z1;
	int offset;

	if (abs(x2 - x1) < 2 && abs(y2 - y1) < 2) {
		puffer[(y2 * SCREEN_WIDTH) + x2] = color; return;
	}

	while (1) {
		// Friss�tj�k a Z-buffer �rt�k�t
		offset = (y1 * SCREEN_WIDTH) + x1;
		if (zpuffer[offset] > z)
		{
			zpuffer[offset] = z;
			puffer[offset] = color;
		}

		// Ellen�rizz�k, hogy el�rt�k-e a vonal v�g�t
		if (x1 == x2 && y1 == y2) break;
		
		e2 = err * 2;
		if (e2 > -dy) {
			err -= dy;
			x1 += sx;
		}
		if (e2 < dx) {
			err += dx;
			y1 += sy;
		}
		z += dz / (dx > dy ? dx : dy); // Friss�tj�k a Z-�rt�ket
	}
}

void CPU_FillTriangle(int x1, int y1, int x2, int y2, int x3, int y3, int color, unsigned int* puffer)
{
	if (y1 == y2 && y1 == y3) return;
	// Compute bounding box
	int minX = x1 < x2 ? (x1 < x3 ? x1 : x3) : (x2 < x3 ? x2 : x3);
	int maxX = x1 > x2 ? (x1 > x3 ? x1 : x3) : (x2 > x3 ? x2 : x3);
	int minY = y1 < y2 ? (y1 < y3 ? y1 : y3) : (y2 < y3 ? y2 : y3);
	int maxY = y1 > y2 ? (y1 > y3 ? y1 : y3) : (y2 > y3 ? y2 : y3);

	// Calculate edge functions
	int s1 = x2 - x1,s2= x3 - x2,s3= x1 - x3,s4= y2 - y1,s5= y3 - y2,s6= y1 - y3;
	int edge1 = s1 * (y1 - minY) - (x1 - minX) * s4;
	int edge2 = s2 * (y2 - minY) - (x2 - minX) * s5;
	int edge3 = s3 * (y3 - minY) - (x3 - minX) * s6;
	int y, x ,c1,c2,c3;

	// Loop through bounding box
	for (y = minY; y <= maxY; y++) {
		for (x = minX; x <= maxX; x++) {
			c1 = s1 * (y - y1) - (x - x1) * s4;
			c2 = s2 * (y - y2) - (x - x2) * s5;
			c3 = s3 * (y - y3) - (x - x3) * s6;

			if ((c1 >= 0 && c2 >= 0 && c3 >= 0) || (c1 <= 0 && c2 <= 0 && c3 <= 0)) {
				puffer[(y * SCREEN_WIDTH) + x] = color;
			}
		}
	}
}

void CPU_FillTriangle_Zbuffer(int x1, int y1, int z1, int x2, int y2, int z2, int x3, int y3, int z3, int color, unsigned int* puffer, float* zpuffer)
{
	if (y1 == y2 && y1 == y3) return;
	int temp;

	// �lek rendez�se magass�g szerint
	if (y2 < y1) {
		temp = x1; x1 = x2; x2 = temp;
		temp = y1; y1 = y2; y2 = temp;
		temp = z1; z1 = z2; z2 = temp;
	}
	if (y3 < y1) {
		temp = x1; x1 = x3; x3 = temp;
		temp = y1; y1 = y3; y3 = temp;
		temp = z1; z1 = z3; z3 = temp;
	}
	if (y3 < y2) {
		temp = x2; x2 = x3; x3 = temp;
		temp = y2; y2 = y3; y3 = temp;
		temp = z2; z2 = z3; z3 = temp;
	}

	int totalHeight = y3 - y1;
	int i, j, ax, bx, az, bz, y, phi, z, offset, secondHalf, segmentHeight;

	for (i = 0; i < totalHeight; i++) {
		secondHalf = i > y2 - y1 || y2 == y1;
		segmentHeight = secondHalf ? (y3 - y2) : (y2 - y1);

		ax = x1 + (x3 - x1) * i / totalHeight;
		az = z1 + (z3 - z1) * i / totalHeight;

		bx = secondHalf ? (x2 + (x3 - x2) * (i - (y2 - y1)) / segmentHeight)
			: (x1 + (x2 - x1) * i / segmentHeight);
		bz = secondHalf ? (z2 + (z3 - z2) * (i - (y2 - y1)) / segmentHeight)
			: (z1 + (z2 - z1) * i / segmentHeight);

		if (ax > bx) {
			temp = ax; ax = bx; bx = temp;
			temp = az; az = bz; bz = temp;
		}

		y = y1 + i;
		for (j = ax; j <= bx; j++) {
			phi = bx == ax ? 0 : (j - ax) * 1000 / (bx - ax); // Fixpontos aritmetika helyett egyszer� sk�l�z�s
			z = az + (bz - az) * phi / 1000;

			offset = (y * SCREEN_WIDTH) + j;
			if (zpuffer[offset] > z)
			{
				zpuffer[offset] = z;
				puffer[offset] = color;
			}
		}
	}
}

void CPU_FillTriangle_Zbuffer_Goraud(int x1, int y1, int z1, int color1,
	int x2, int y2, int z2, int color2,
	int x3, int y3, int z3, int color3,
	unsigned int* puffer, float* zpuffer)
{
	if (y1 == y2 && y1 == y3) return;
	int temp;

	// �lek rendez�se magass�g szerint
	if (y2 < y1) {
		temp = x1; x1 = x2; x2 = temp;
		temp = y1; y1 = y2; y2 = temp;
		temp = z1; z1 = z2; z2 = temp;
		temp = color1; color1 = color2; color2 = temp;
	}
	if (y3 < y1) {
		temp = x1; x1 = x3; x3 = temp;
		temp = y1; y1 = y3; y3 = temp;
		temp = z1; z1 = z3; z3 = temp;
		temp = color1; color1 = color3; color3 = temp;
	}
	if (y3 < y2) {
		temp = x2; x2 = x3; x3 = temp;
		temp = y2; y2 = y3; y3 = temp;
		temp = z2; z2 = z3; z3 = temp;
		temp = color2; color2 = color3; color3 = temp;
	}

	int totalHeight = y3 - y1;
	int i, j, ax, bx, az, bz, y, phi, z, offset, secondHalf, segmentHeight;
	float r, g, b;
	float r1, g1, b1, r2, g2, b2, r3, g3, b3;

	// Cs�csok sz�n�nek komponensei (RGB)
	r1 = (color1 >> 16) & 0xFF;
	g1 = (color1 >> 8) & 0xFF;
	b1 = color1 & 0xFF;
	r2 = (color2 >> 16) & 0xFF;
	g2 = (color2 >> 8) & 0xFF;
	b2 = color2 & 0xFF;
	r3 = (color3 >> 16) & 0xFF;
	g3 = (color3 >> 8) & 0xFF;
	b3 = color3 & 0xFF;

	for (i = 0; i < totalHeight; i++) {
		secondHalf = i > y2 - y1 || y2 == y1;
		segmentHeight = secondHalf ? (y3 - y2) : (y2 - y1);

		ax = x1 + (x3 - x1) * i / totalHeight;
		az = z1 + (z3 - z1) * i / totalHeight;

		bx = secondHalf ? (x2 + (x3 - x2) * (i - (y2 - y1)) / segmentHeight)
			: (x1 + (x2 - x1) * i / segmentHeight);
		bz = secondHalf ? (z2 + (z3 - z2) * (i - (y2 - y1)) / segmentHeight)
			: (z1 + (z2 - z1) * i / segmentHeight);

		if (ax > bx) {
			temp = ax; ax = bx; bx = temp;
			temp = az; az = bz; bz = temp;
		}

		y = y1 + i;
		for (j = ax; j <= bx; j++) {
			phi = bx == ax ? 0 : (j - ax) * 1000 / (bx - ax); // Fixpontos aritmetika helyett egyszer� sk�l�z�s
			z = az + (bz - az) * phi / 1000;

			float r0 = r1 + (r3 - r1) * (i / (float)totalHeight);
			float g0 = g1 + (g3 - g1) * (i / (float)totalHeight);
			float b0 = b1 + (b3 - b1) * (i / (float)totalHeight);

			float r1r = r0 + (r2 - r0) * ((j - ax) / (float)(bx - ax));
			float g1r = g0 + (g2 - g0) * ((j - ax) / (float)(bx - ax));
			float b1r = b0 + (b2 - b0) * ((j - ax) / (float)(bx - ax));

			int finalColor = ((int)r1r << 16) | ((int)g1r << 8) | (int)b1r;

			offset = (y * SCREEN_WIDTH) + j;
			if (zpuffer[offset] > z) {
				zpuffer[offset] = z;
				puffer[offset] = finalColor;
			}
		}
	}
}


void CPU_zoom_in(void)
{
	muveletsor[muvelet_length++] = 4;
	CPU_zoom_in2(raw_vertices_length[0], raw_verticesX, raw_verticesY, raw_verticesZ);
}

void CPU_zoom_out(void)
{
	muveletsor[muvelet_length++] = 5;
	CPU_zoom_out2(raw_vertices_length[0], raw_verticesX, raw_verticesY, raw_verticesZ);
}

void CPU_zoom_in2(int maxitemcount, float* rawarrayX, float* rawarrayY, float* rawarrayZ)
{
	int i;
	for (i = 0; i < maxitemcount; ++i)
	{
		rawarrayX[i] *= 1.1;
		rawarrayY[i] *= 1.1;
		rawarrayZ[i] *= 1.1;
	}
}

void CPU_stepx_plus(void)
{
	muveletsor[muvelet_length++] = 0;
	CPU_stepx_in(raw_vertices_length[0], raw_verticesX, 50.0);
}

void CPU_stepx_minus(void)
{
	muveletsor[muvelet_length++] = 1;
	CPU_stepx_in(raw_vertices_length[0], raw_verticesX, -50.0);
}

void CPU_stepx_in(int maxitemcount, float* rawarrayX, float xvalue)
{
	int i;
	for (i = 0; i < maxitemcount; ++i) rawarrayX[i] += xvalue;
}

void CPU_stepy_plus(void)
{
	CPU_stepy_in(raw_vertices_length[0], raw_verticesY, 50.0);
}

void CPU_stepy_minus(void)
{
	CPU_stepy_in(raw_vertices_length[0], raw_verticesY, -50.0);
}

void CPU_stepy_in(int maxitemcount, float* rawarrayY, float xvalue)
{
	int i;
	for (i = 0; i < maxitemcount; ++i) rawarrayY[i] += xvalue;
}

void CPU_stepz_plus(void)
{
	muveletsor[muvelet_length++] = 2;
	CPU_stepz_in(raw_vertices_length[0], raw_verticesZ, 50.0);
}

void CPU_stepz_minus(void)
{
	muveletsor[muvelet_length++] = 3;
	CPU_stepz_in(raw_vertices_length[0], raw_verticesZ, -50.0);
}

void CPU_stepz_in(int maxitemcount, float* rawarrayY, float xvalue)
{
	int i;
	for (i = 0; i < maxitemcount; ++i) rawarrayY[i] += xvalue;
}

void CPU_zoom_out2(int maxitemcount, float* rawarrayX, float* rawarrayY, float* rawarrayZ)
{
	int i;
	for (i = 0; i < maxitemcount; ++i)
	{
		rawarrayX[i] /= 1.1;
		rawarrayY[i] /= 1.1;
		rawarrayZ[i] /= 1.1;
	}
}