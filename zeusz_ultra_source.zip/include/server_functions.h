/******************************************************************************************************
Copyright(c) < 2024 > <copyright holder : Kriszti�n Dezs� Feh�r, Hungary>
Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files(the "Software"),
to deal in the Software without restriction, except the commercial usage, including without limitation the rights to use, copy, modify, merge, publish, distribute copies of the Software,
and to permit persons to whom the Software is furnished to do so, subject to the following conditions :

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
******************************************************************************************************/
#pragma once
#include <Winsock2.h>
#include <ws2tcpip.h>
#include <WinInet.h>
#include <process.h>
#include <mstcpip.h>
#pragma comment(lib, "wininet.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "ws2_32.lib")
#include <stdlib.h>

HANDLE THANDLER;
int nLength = sizeof(SOCKADDR);
#define RECBUFLEN 1032
int request_count = 0;
#define MAX_RESP_LENGTH 10*1024
#define MIN_RESP_LENGTH 1024
#define MAX_EGYSEG_SZAM 100
WSADATA wsaData;
WORD wVersionRequested = MAKEWORD(2, 2);
ADDRINFO Hints, * AddrInfo, * AI;
BOOL serverisopen;
SOCKET clientsocket, serversocket;
//sockaddr_in6 serveraddr;
SOCKADDR_STORAGE clientaddr;
int vege = 0, server_started = 0;
int network_busy_status = 0;//0-szabad,1-adatkommunik�ci� folyamatban

int van_bejovo_uzenet = 0;//0-nincs,1-van legalabb 1
double bejovo_uzenet_cal_x, bejovo_uzenet_cal_y, bejovo_uzenet_cal_altitude;

char incoming_data[10 * 1024];
HWND RESULT_TEXTBOX;
int server_GPS_new=0;//0-nincs uj egyseg,1-uj egyseg hozzaadva

int kivalasztott_unit_num = -1;//-1 nincs kiv�lasztva semmi, >-1 az elem t�mbindexe az egyseglistaban
int server_com_type;//0-ipv4,1-ipv4enc,2-ipv6,3-ipv6enc,4-php,5-phpenc

void update_unit_showtext(int unitnum, HWND ablakszam);

typedef struct
{
    char pcname[32];
    float orig_longitude;
    float orig_latitude;
    float orig_magassag;
    double longitude;
    double latitude;
    double magassag;
    double sebesseg;
    char portnum[16];
    char ip_address[128];
    char uzenet[1032];
} uzenet_minta;

uzenet_minta kimeno_uzenet,bejovo_uzenet,egyseglista[MAX_EGYSEG_SZAM];
int egysegek_szama;

void validate_IP_1(void);
void client_mode_switch(void);

void open_server_IP4(char *myip_address, char *myportnum);
void open_server_IP6(char* myip_address, char* myportnum);
void start_send_GPS_IP4(void);
void start_send_GPS_IP6(void);
void start_send_GPS_PHP(void);
void threading_send_GPS_IP4(void* pParams);
void threading_send_GPS_IP6(void* pParams);
void threading_send_GPS_PHP(void* pParams);
void close_server(void);

void parse_geomessage(char* srcstr, char sepchar, char* kuldo1, double* long1, double* lat1, double* mag1, double* seb1);
void add_egyseglista(uzenet_minta egysegadat, HWND ablaknum);
void calculate_bejovo_uzenet_values(int sorszam);
void recalculate_bejovo_uzenet_values(int sorszam);

void validate_IP_1(void)
{
    ;
}

void client_mode_switch(void)
{
    ;
}

void open_server_IP4(char* myip_address, char* myportnum)
{
    int portnum = 0;

    serverisopen = false;
    serversocket = INVALID_SOCKET;

    //memset(&serveraddr, 0, sizeof(serveraddr));
    portnum = atoi(myportnum);

    if (WSAStartup(wVersionRequested, &wsaData) != 0)
    {
        WSACleanup();
        return;
    }

    //***************
    int RetVal;

    memset(&Hints, 0, sizeof(Hints));
    Hints.ai_family = AF_INET;
    Hints.ai_socktype = SOCK_STREAM;
    Hints.ai_flags = AI_NUMERICHOST | AI_PASSIVE;
    RetVal = getaddrinfo(myip_address, myportnum, &Hints, &AddrInfo);
    if (RetVal != 0) {
        WSACleanup();
        return;
    }
    //***************

    serversocket = socket(AddrInfo->ai_family, AddrInfo->ai_socktype, AddrInfo->ai_protocol);
    if (serversocket == INVALID_SOCKET) {
        return;
    }

    if (bind(serversocket, AddrInfo->ai_addr, (int)AddrInfo->ai_addrlen) == SOCKET_ERROR) {
        closesocket(serversocket);
        return;
    }

}

void open_server_IP6(char *myip_address,char *myportnum)
{
    //char myip_address[50], myportnum[6];
    int portnum = 0;
    fd_set SockSet;

    serverisopen = false;
    serversocket = INVALID_SOCKET;

    //memset(&serveraddr, 0, sizeof(serveraddr));

    //GetWindowTextA(Edit_IP_1, myip_address, 50);
    //GetWindowTextA(80, myportnum, 5);
    //strcpy_s(myportnum,"80");

    portnum = atoi(myportnum);
    if (WSAStartup(wVersionRequested, &wsaData) != 0)
    {
        WSACleanup();
        return;
    }

    //***************
    int RetVal;

    memset(&Hints, 0, sizeof(Hints));
    Hints.ai_family = PF_INET6;
    Hints.ai_socktype = SOCK_STREAM;
    Hints.ai_flags = AI_NUMERICHOST | AI_PASSIVE;
    RetVal = getaddrinfo(myip_address, myportnum, &Hints, &AddrInfo);
    if (RetVal != 0) {
        WSACleanup();
        return;
    }
    //***************

    serversocket = socket(AddrInfo->ai_family, AddrInfo->ai_socktype, AddrInfo->ai_protocol);
    if (serversocket == INVALID_SOCKET) {
        return;
    }

    if (bind(serversocket, AddrInfo->ai_addr, (int)AddrInfo->ai_addrlen) == SOCKET_ERROR) {
        closesocket(serversocket);
        return;
    }

}

//ugyanaz IP4 �s IP6 eset�n is
void close_server(void)
{
    shutdown(clientsocket, SD_SEND);
    if (serverisopen == true) closesocket(serversocket);
    if (clientsocket != INVALID_SOCKET) closesocket(clientsocket);
    //closesocket(serversocket);
    shutdown(serversocket, SD_SEND);
    shutdown(serversocket, SD_RECEIVE);
    WSACleanup();
    serverisopen = false;
}

void start_send_GPS_IP4(void)
{
    network_busy_status = 1;
    _beginthread(threading_send_GPS_IP4, 0, NULL);
}

void start_send_GPS_IP6(void)
{
    network_busy_status = 1;
    _beginthread(threading_send_GPS_IP6, 0, NULL);
}

void start_send_GPS_PHP(void)
{
    network_busy_status = 1;
    _beginthread(threading_send_GPS_PHP, 0, NULL); 
}

void threading_send_GPS_IP4(void* pParams)
{
    char recvbuf[RECBUFLEN] = "";
    char sendbuf[RECBUFLEN] = "";
    char myip_address[50], myportnum[6];
    int portnum = 0, hibakod;
    SOCKET ConnectSocket = INVALID_SOCKET;
    int Result_error;
    sockaddr_in clientService;

    memset(&clientService, 0, sizeof(clientService));
    strcpy_s(myip_address, kimeno_uzenet.ip_address);
    portnum = atoi(kimeno_uzenet.portnum);

    // Winsock inicializalasa
    Result_error = WSAStartup(MAKEWORD(2, 2), &wsaData);
    if (Result_error != 0) {
        //printf("Inicializalasi hiba: %d\n", Result_error);
        network_busy_status = 0;
        return;
    }

    //***************
    int RetVal;
    ADDRINFO Hints, * AddrInfo;
    char* Address = NULL;

    memset(&Hints, 0, sizeof(Hints));
    Hints.ai_family = PF_INET;
    Hints.ai_socktype = SOCK_STREAM;
    Hints.ai_flags = AI_NUMERICHOST | AI_PASSIVE;
    RetVal = getaddrinfo(Address, kimeno_uzenet.portnum, &Hints, &AddrInfo);
    if (RetVal != 0) {
        /*fprintf(stderr, "getaddrinfo failed with error %d: %s\n",
            RetVal, gai_strerror(RetVal));*/
        WSACleanup();
        network_busy_status = 0;
        return;
    }
    //***************

    //Kapcsolat felepitese
    ConnectSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

    clientService.sin_family = AF_INET;
    //clientService.sin_addr.s_addr = inet_addr("127.0.0.1");
    inet_pton(AF_INET, myip_address, &clientService.sin_addr.s_addr);//127.0.0.1
    clientService.sin_port = htons(portnum);
    Result_error = connect(ConnectSocket, (SOCKADDR*)&clientService, sizeof(clientService));

    if (ConnectSocket == INVALID_SOCKET) {
        //printf("Kapcsolat nem jott letre!\n");
        WSACleanup();
        network_busy_status = 0;
        return;
    }

    // Adatkuldes
    strcpy_s(sendbuf, kimeno_uzenet.uzenet);
    Result_error = send(ConnectSocket, sendbuf, (int)strlen(sendbuf) + 1, 0);
    if (Result_error == SOCKET_ERROR) {
        hibakod = WSAGetLastError();
        //printf("Adatkuldesi hiba: %d\n", WSAGetLastError());
        closesocket(ConnectSocket);
        //WSACleanup();
        network_busy_status = 0;
        return;
    }
    //printf("Elkuldott bajtok szama: %ld\n", Result_error);

    // Adatkuldes befejezese
    Result_error = shutdown(ConnectSocket, SD_SEND);
    if (Result_error == SOCKET_ERROR) {
        //printf("Lezarasi hiba: %d\n", WSAGetLastError());
        closesocket(ConnectSocket);
        //WSACleanup();
        network_busy_status = 0;
        return;
    }

    // Valasz osszeszedese
    do {
        Result_error = recv(ConnectSocket, recvbuf, RECBUFLEN, 0);
    } while (Result_error > 0);

    if (strcmp(recvbuf, "ok") == 0)
    {
        //SetWindowTextA(Network_Setup_Window, "Network configuration - Sending successful...");
        strcat_s(incoming_data, _countof(incoming_data), "\r\nYOU: ");
        strcat_s(incoming_data, _countof(incoming_data), sendbuf);
        strcat_s(incoming_data, _countof(incoming_data), "\r\n");
        SetWindowTextA(RESULT_TEXTBOX, incoming_data);
    }

    // Befejezes
    closesocket(ConnectSocket);
    //WSACleanup();

    network_busy_status = 0;

    return;
}

void threading_send_GPS_IP6(void* pParams)
{
    char recvbuf[RECBUFLEN] = "";
    char sendbuf[RECBUFLEN] = "";
    char myip_address[50], myportnum[6];
    int portnum = 0, hibakod;
    SOCKET ConnectSocket = INVALID_SOCKET;
    int Result_error;
    sockaddr_in6 clientService;

    memset(&clientService, 0, sizeof(clientService));

    //GetWindowTextA(Edit_IP_1, myip_address, 50);
    //GetWindowTextA(Edit_PORT_1, myportnum, 6);
    //strcpy_s(myportnum, "80");
    strcpy_s(myip_address, kimeno_uzenet.ip_address);
    portnum = atoi(kimeno_uzenet.portnum);
    //GetWindowTextA(Edit_PCNAME, mypcname, 40);
    //strcpy_s(mymessage, "MSG|19.41|48.43|");

    // Winsock inicializalasa
    Result_error = WSAStartup(MAKEWORD(2, 2), &wsaData);
    if (Result_error != 0) {
        //printf("Inicializalasi hiba: %d\n", Result_error);
        network_busy_status = 0;
        return;
    }

    //***************
    int RetVal;
    ADDRINFO Hints, * AddrInfo;
    char* Address = NULL;

    memset(&Hints, 0, sizeof(Hints));
    Hints.ai_family = PF_INET6;
    Hints.ai_socktype = SOCK_STREAM;
    Hints.ai_flags = AI_NUMERICHOST | AI_PASSIVE;
    RetVal = getaddrinfo(Address, kimeno_uzenet.portnum, &Hints, &AddrInfo);
    if (RetVal != 0) {
        /*fprintf(stderr, "getaddrinfo failed with error %d: %s\n",
            RetVal, gai_strerror(RetVal));*/
        WSACleanup();
        network_busy_status = 0;
        return;
    }
    //***************

    //Kapcsolat felepitese
    ConnectSocket = socket(AF_INET6, SOCK_STREAM, IPPROTO_TCP);

    clientService.sin6_family = AF_INET6;
    //clientService.sin_addr.s_addr = inet_addr("127.0.0.1");
    inet_pton(AF_INET6, myip_address, &clientService.sin6_addr.s6_addr);//127.0.0.1
    clientService.sin6_port = htons(portnum);
    Result_error = connect(ConnectSocket, (SOCKADDR*)&clientService, sizeof(clientService));

    if (ConnectSocket == INVALID_SOCKET) {
        //printf("Kapcsolat nem jott letre!\n");
        WSACleanup();
        network_busy_status = 0;
        return;
    }

    // Adatkuldes
    strcpy_s(sendbuf, kimeno_uzenet.uzenet);
    Result_error = send(ConnectSocket, sendbuf, (int)strlen(sendbuf) + 1, 0);
    if (Result_error == SOCKET_ERROR) {
        hibakod = WSAGetLastError();
        //printf("Adatkuldesi hiba: %d\n", WSAGetLastError());
        closesocket(ConnectSocket);
        //WSACleanup();
        network_busy_status = 0;
        return;
    }
    //printf("Elkuldott bajtok szama: %ld\n", Result_error);

    // Adatkuldes befejezese
    Result_error = shutdown(ConnectSocket, SD_SEND);
    if (Result_error == SOCKET_ERROR) {
        //printf("Lezarasi hiba: %d\n", WSAGetLastError());
        closesocket(ConnectSocket);
        //WSACleanup();
        network_busy_status = 0;
        return;
    }

    // Valasz osszeszedese
    do {

        Result_error = recv(ConnectSocket, recvbuf, RECBUFLEN, 0);
        /*if (Result_error > 0)
        {
            printf("Fogadott bajtok szama: %d\n", Result_error);
            printf("%s\n", recvbuf);
        }
        else if (Result_error == 0)
            printf("Kapcsolat lezarva\n");
        else
            printf("Adatfogadasi hiba: %d\n", WSAGetLastError());*/

    } while (Result_error > 0);

    if (strcmp(recvbuf, "ok") == 0)
    {
        //SetWindowTextA(Network_Setup_Window, "Network configuration - Sending successful...");
        strcat_s(incoming_data, _countof(incoming_data), "\r\nYOU: ");
        strcat_s(incoming_data, _countof(incoming_data), sendbuf);
        strcat_s(incoming_data, _countof(incoming_data), "\r\n");
        SetWindowTextA(RESULT_TEXTBOX, incoming_data);
    }

    // Befejezes
    closesocket(ConnectSocket);
    //WSACleanup();

    network_busy_status = 0;
    return;
}

void parse_geomessage(char *srcstr, char sepchar, char *kuldo1, double* long1, double* lat1, double* mag1, double* seb1)
{
    int i = 0,poz=0,talalat=1,j=0;
    char tempstr[1024];

    strcpy_s(kuldo1, sizeof(kuldo1), "invalid");
    *long1 = *lat1 = -999;
    *mag1 = *seb1 = -999;

    for (i = 1; i < strlen(srcstr); ++i)
    {
        for (j = i, poz = 0; j < strlen(srcstr); ++j) //pcname
        {
            kuldo1[poz++] = srcstr[j];
            if (srcstr[j + 1] == '|')
            {
                kuldo1[poz] = '\0';
                //strcpy_s(kuldo1, _countof(kimeno_uzenet.kuldo), tempcel);
                //++talalat;
                i = j + 2;
                break;
            }
        }

        for (j = i, poz = 0; j < strlen(srcstr); ++j)  //longitude
        {
            tempstr[poz++] = srcstr[j];
            if (srcstr[j + 1] == '|')
            {
                tempstr[poz] = '\0';
                i = j + 2;
                *long1 = atof(tempstr);
                break;
            }
        }

        for (j = i, poz = 0; j < strlen(srcstr); ++j)  //latitude
        {
            tempstr[poz++] = srcstr[j];
            if (srcstr[j + 1] == '|')
            {
                tempstr[poz] = '\0';
                i = j + 2;
                *lat1 = atof(tempstr);
                break;
            }
        }

        for (j = i, poz = 0; j < strlen(srcstr); ++j)  //magassag
        {
            tempstr[poz++] = srcstr[j];
            if (srcstr[j + 1] == '|')
            {
                tempstr[poz] = '\0';
                i = j + 2;
                *mag1 = atof(tempstr);
                break;
            }
        }

        for (j = i, poz = 0; j < strlen(srcstr); ++j)  //sebesseg
        {
            tempstr[poz++] = srcstr[j];
            if (srcstr[j + 1] == '|')
            {
                tempstr[poz] = '\0';
                i = j + 2;
                *seb1 = atoi(tempstr);
                break;
            }
        }

        break;
    }
}

void add_egyseglista(uzenet_minta egysegadat,HWND ablaknum)
{
    int i, van_talalat = 0;
    if (egysegek_szama >= MAX_EGYSEG_SZAM-1) return;

    if (egysegek_szama > 0)
    {
        for (i = 1; i < egysegek_szama; ++i) //a 0 start index mindig a gps vev�
        {
            if (strcmp(egysegadat.pcname, egyseglista[i].pcname) == 0)
            {
                naplo("M�r l�tezik");
                naplo(egysegadat.pcname);
                naplo_num(i);
                egyseglista[i] = egysegadat;
                calculate_bejovo_uzenet_values(i);
                if(kivalasztott_unit_num == i) update_unit_showtext(kivalasztott_unit_num,ablaknum);
                van_talalat = 1;
                break;
            }
        }
        if (van_talalat == 0) //�j adat, hozz�adand� a list�hoz
        {
            naplo("�j adat");
            naplo(egysegadat.pcname);
            naplo_num(egysegek_szama);
            egyseglista[egysegek_szama++] = egysegadat;
            calculate_bejovo_uzenet_values(egysegek_szama-1);
            server_GPS_new = 1;
        }
    }
    else
    {
        //�j adat, hozz�adand� a list�hoz
        naplo("�j adat");
        naplo(egysegadat.pcname);
        naplo_num(egysegek_szama);
        egyseglista[egysegek_szama++] = egysegadat;
        calculate_bejovo_uzenet_values(egysegek_szama - 1);
        server_GPS_new = 1;
    }
}

void calculate_bejovo_uzenet_values(int sorszam)
{
    int i;
    double X= egyseglista[sorszam].longitude, Y= egyseglista[sorszam].latitude, Z= egyseglista[sorszam].magassag;

    egyseglista[sorszam].longitude = TERKEP_NAGYITAS * (X - terkepx);
    egyseglista[sorszam].latitude = TERKEP_NAGYITAS * 2 * (terkepy - Y);
    //egyseglista[sorszam].magassag = Z / altitude_ratio;
    egyseglista[sorszam].magassag = 1;

    naplo("GPS ADAT");
    naplo_float(egyseglista[sorszam].longitude);
    naplo_float(egyseglista[sorszam].magassag);
    naplo_float(egyseglista[sorszam].latitude);

    for (i = 0; i < muvelet_length; ++i)
    {
        if (muveletsor[i] == 0) egyseglista[sorszam].longitude += 50;
        else if (muveletsor[i] == 1) egyseglista[sorszam].longitude -= 50;
        else if (muveletsor[i] == 2) egyseglista[sorszam].latitude += 50;
        else if (muveletsor[i] == 3) egyseglista[sorszam].latitude -= 50;
        else if (muveletsor[i] == 4)
        {
            egyseglista[sorszam].longitude *= 1.1f;
            egyseglista[sorszam].latitude *= 1.1f;
            egyseglista[sorszam].magassag *= 1.1f;            
        }
        else if (muveletsor[i] == 5)
        {
            egyseglista[sorszam].longitude /= 1.1f;
            egyseglista[sorszam].latitude /= 1.1f;
            egyseglista[sorszam].magassag /= 1.1f;
        }

    }
}

void recalculate_bejovo_uzenet_values(int sorszam)
{
    int i;
    double X = egyseglista[sorszam].orig_longitude, Y = egyseglista[sorszam].orig_latitude, Z = egyseglista[sorszam].orig_magassag;

    egyseglista[sorszam].longitude = TERKEP_NAGYITAS * (X - terkepx);
    egyseglista[sorszam].latitude = TERKEP_NAGYITAS * 2 * (terkepy - Y);
    egyseglista[sorszam].magassag = 1;// Z / altitude_ratio;

    naplo("GPS ADAT");
    naplo_float(egyseglista[sorszam].longitude);
    naplo_float(egyseglista[sorszam].magassag);
    naplo_float(egyseglista[sorszam].latitude);

    for (i = 0; i < muvelet_length; ++i)
    {
        if (muveletsor[i] == 0) egyseglista[sorszam].longitude += 50;
        else if (muveletsor[i] == 1) egyseglista[sorszam].longitude -= 50;
        else if (muveletsor[i] == 2) egyseglista[sorszam].latitude += 50;
        else if (muveletsor[i] == 3) egyseglista[sorszam].latitude -= 50;
        else if (muveletsor[i] == 4)
        {
            egyseglista[sorszam].longitude *= 1.1f;
            egyseglista[sorszam].latitude *= 1.1f;
            egyseglista[sorszam].magassag *= 1.1f;
        }
        else if (muveletsor[i] == 5)
        {
            egyseglista[sorszam].longitude /= 1.1f;
            egyseglista[sorszam].latitude /= 1.1f;
            egyseglista[sorszam].magassag /= 1.1f;
        }

    }
}

void update_unit_showtext(int unitnum,HWND ablakszam)
{
    int int_seb = 0;
    char szoveg[1024], convstr[64];

    strcpy_s(szoveg, "Kiv�lasztott egys�g adatai:\r\n");
    strcat_s(szoveg, "---------------------------\r\n");
    strcat_s(szoveg, "N�v: ");
    strcat_s(szoveg, egyseglista[unitnum].pcname);
    strcat_s(szoveg, "\r\n");
    sprintf(convstr, "%f", egyseglista[unitnum].orig_longitude);
    strcat_s(szoveg, "Longitude: ");
    strcat_s(szoveg, convstr);
    strcat_s(szoveg, "\r\n");
    sprintf(convstr, "%f", egyseglista[unitnum].orig_latitude);
    strcat_s(szoveg, "Latitude: ");
    strcat_s(szoveg, convstr);
    strcat_s(szoveg, "\r\n");
    sprintf(convstr, "%f", egyseglista[unitnum].orig_magassag);
    strcat_s(szoveg, "Altitude: ");
    strcat_s(szoveg, convstr);
    strcat_s(szoveg, " m\r\n");
    int_seb = egyseglista[unitnum].sebesseg * 3.6f;
    itoa(int_seb, convstr, 10);
    strcat_s(szoveg, "Speed: ");
    strcat_s(szoveg, convstr);
    strcat_s(szoveg, " km/h\r\n");
    SetWindowTextA(ablakszam, szoveg);
}

void threading_send_GPS_PHP(void* pParams)
{
    char buffer[2048],teljes_url[4096];

    strcpy(teljes_url, kimeno_uzenet.ip_address);
    strcat_s(teljes_url,sizeof(kimeno_uzenet.uzenet), kimeno_uzenet.uzenet);
    //A kapcsolat letrehozasa
    HINTERNET internet = InternetOpenA("Letolto", INTERNET_OPEN_TYPE_DIRECT, NULL, NULL, NULL);
    if (internet)
    {
        HINTERNET file_handle = InternetOpenUrlA(internet, teljes_url, NULL, 0, INTERNET_FLAG_RAW_DATA, 0);
        if (file_handle)
        {
            DWORD bytes_read = 0;

            //A tavoli eroforras letoltese
            InternetReadFile(file_handle, buffer, 2048, &bytes_read);
            buffer[bytes_read] = 0;
        }

        InternetCloseHandle(internet);
    }
    network_busy_status = 0;
}