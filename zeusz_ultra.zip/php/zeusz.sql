--
-- DATABASE: `zeusz`
--

-- --------------------------------------------------------

--
-- TABLE `device`
--

CREATE DATABASE 'zeusz';

CREATE TABLE IF NOT EXISTS `device` (
  `value` varchar(4096) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `device` (`value`) VALUES
('|PCNAME|0.0|0.0|0|0|');