The scripts included in this folder are for demo purposes on a local network and must be further preparated for real-wold usage, especially because of security considerations.
