<?php
$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "zeusz";
$mytext = "";
$result = false;

// create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// check connection
if (!$conn) {die("Connection failed: " . mysqli_connect_error());}

// building query
$sql = "SELECT value FROM device";

// executing query
$result = mysqli_query($conn, $sql);

// list results
if (mysqli_num_rows($result) > 0)
 {
    while($row = mysqli_fetch_assoc($result))
	{
	 $mytext=$row["value"];
	 echo $mytext;
	}
}
else
{
    $mytext="Database is empty!";
    echo $mytext;
}

// closing connection
mysqli_close($conn);
?>