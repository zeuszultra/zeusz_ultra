<?php
$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "zeusz";
$result = false;
$param1 = $_GET["p1"];

// create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// check connection
if (!$conn) {die("Connection failed: " . mysqli_connect_error());}

// building query
$sql = "UPDATE device SET value='".$param1."'";

// executing query
$result = mysqli_query($conn, $sql);

echo $sql;

// closing connection
mysqli_close($conn);
?>